# readcard - 读取SIM卡信息

读取指定卡槽SIM卡详细信息。数据来源：设备存储（流量/通话统计）+ SIM卡读取（ICCID、IMSI）。
前置条件：卡槽必须已完成初始化并准备就绪，否则返回code=200。

## 接口
- HTTP: GET `/ctrl?token=...&cmd=readcard&p1=...`
- TCP: `{"cmd":"readcard","p1":...,"tid":"..."}\x11\x12`（末尾结束符0x11 0x12）

## 参数
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| token | string | 是(HTTP) | 管理员Token，HTTP接口必填；TCP接口无需token |
| cmd | string | 是 | 固定值`readcard` |
| p1 | int | 是 | 卡槽号，有效值1~2（设备最大支持2个卡槽） |
| tid | string | 否 | 事务追踪ID，响应中原样返回，用于关联请求与响应 |

## 执行流程
1. 验证p1(1~2) → 无效: code=101 "Invalid slot ID: X. Valid range: 1-2"
2. 检查卡槽就绪 → 未就绪/未插卡: code=200 "slot no service!"
3. 成功 → code=0，返回完整信息
4. 信息不完整 → SIM卡读取失败（检查SIM卡是否正常插入，尝试重启卡槽）

## 返回格式
成功type=402（命令执行完成并返回结果），错误type=401（设备已收到命令但在处理前发现错误）。subType固定39。

**成功示例**（code=0）：
```json
{"subType":39,"code":0,"type":402,"netCh":0,"slot":1,"msIsdn":"13800138000","iccId":"89860000000000000000","imsi":"460000000000000","scName":"工作卡","simNet":true,"trafficTotalMB":1024,"trafficConsumedKB":512000,"ratioMin":70,"ratioMax":85,"ratioRndTarget":78,"callInCount":10,"callInMinutes":30,"callOutCount":5,"callOutMinutes":15,"updateTs":1704067200,"devId":"c3dd382801","msgTs":1773647136}
```

**错误示例**：
- code=101: `{"subType":39,"code":101,"val":"","note":"Invalid slot ID: 3. Valid range: 1-2","devId":"c3dd382801","type":401,"netCh":0,"msgTs":1773647179}`
- code=200: `{"subType":39,"code":200,"val":"","note":"slot no service!","devId":"c3dd382801","type":401,"netCh":0,"msgTs":1773647137}`

## 返回字段
| 字段 | 类型 | 单位 | 说明 |
|------|------|------|------|
| subType | int | - | 固定值39，读取卡信息响应 |
| code | int | - | 0=成功，非0=失败 |
| type | int | - | 402=成功结果，401=处理前错误 |
| netCh | int | - | 推送通道号（0=WiFi, 1=SIM1, 2=SIM2） |
| slot | int | - | 卡槽号1~2 |
| msIsdn | string | - | 电话号码（writecard设置，不一定与SIM卡真实号码一致） |
| iccId | string | - | SIM卡唯一标识号（从SIM卡读取，20位） |
| imsi | string | - | 国际移动用户识别码（从SIM卡读取，15位） |
| scName | string | - | 卡槽名称/备注（用户自定义） |
| simNet | bool | - | 联网开关（true=开启，false=关闭） |
| trafficTotalMB | int | MB | 每月套餐总流量 |
| trafficConsumedKB | int | KB | 本月已消耗流量 |
| ratioMin | int | % | 流量比例参数下限（范围1~99） |
| ratioMax | int | % | 流量比例参数上限（范围1~99） |
| ratioRndTarget | int | % | 目标流量比例 |
| callInCount | int | 次 | 呼入电话接通次数 |
| callInMinutes | int | 分钟 | 呼入电话累计分钟数 |
| callOutCount | int | 次 | 呼出电话接通次数 |
| callOutMinutes | int | 分钟 | 呼出电话累计分钟数 |
| updateTs | int | - | 信息最后更新时间（Unix时间戳，秒） |
| devId | string | - | 设备唯一标识符 |
| msgTs | int | - | 消息发送时间戳（Unix时间戳，秒） |

## 补充说明
- **流量统计**：需通过writecard命令首次设置基础值，设备根据实际使用自动累加consumedKB
- **相关命令**：writecard - 写入SIM卡信息（设置卡槽电话号码、名称、流量信息等）
- **使用建议**：定期调用监控流量和卡槽状态；writecard后用readcard验证写入结果；故障诊断时优先用readcard获取状态；定期保存返回信息作为配置备份；设置卡槽信息前先读取当前值
- **ICCID**：SIM卡唯一标识号，20位，从SIM卡直接读取
- **IMSI**：国际移动用户识别码，15位，从SIM卡直接读取
- 返回信息可用于监控卡槽状态和流量使用情况
