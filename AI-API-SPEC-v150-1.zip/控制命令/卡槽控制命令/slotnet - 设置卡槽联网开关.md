# slotnet - 设置/查询卡槽联网开关

设置或查询各卡槽联网开关。开启→允许移动数据通信（含收发短信）；关闭→禁止移动数据和短信。

## 行为规则

- 无p1 → 查询所有卡槽联网状态(同步, type=402)
- 仅p1 → 查询指定卡槽联网状态(同步, type=402)
- p1+p2 → 设置指定卡槽联网状态(异步, type=401, 内部调用writecard命令)
- p1非法(非1~2) → code=101, type=401
- p2解析(不区分大小写)：on/true/1→开启；其他任意值→关闭(推荐off/false/0)

## 约束

- 禁止关闭唯一联网通道，否则拒绝(code=200, type=401)
- 通道计数规则：WiFi已连接=1 + 每个已就绪且联网开启的卡槽=1；总数≤1时禁止关闭当前卡槽联网

## 命令格式

**HTTP**: `http://<IP>/ctrl?token=<token>&cmd=slotnet&p1=<slot>&p2=<state>`

**TCP**(末尾必须附加0x11 0x12): `{"cmd":"slotnet","p1":1,"p2":"on","tid":"1234"}\x11\x12`

**SMS**(仅支持设置，不支持查询): `*#slot<slot>net#<密码>#<on/off>`
```
SMS回复示例：
设备(DEV001) 卡槽1 的联网功能 已关闭。
当前：
卡槽1：关闭
卡槽2：开启
```

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| token | 字符型 | 是(HTTP) | 管理员Token，HTTP接口必填；TCP接口无需token |
| cmd | 字符型 | 是 | "slotnet" |
| p1 | 数值型 | 否 | 卡槽号1~2；省略→查询所有卡槽 |
| p2 | 字符型 | 否 | on/true/1=开启(不区分大小写)，其他=关闭；省略→查询模式 |
| tid | 字符型 | 否 | 事务追踪ID，携带时响应中原样返回 |

## 反馈

所有响应subType固定=17，netCh固定=0。完整结构示例：
```json
{"subType":17,"code":0,"type":402,"val":"on;on","note":"slot1 net:on;slot2 net:on","netCh":0,"devId":"c3dd382801","msgTs":1773647825}
```

**各场景响应**：

| 场景 | code | type | val | note |
|------|------|------|-----|------|
| 查询所有卡槽 | 0 | 402 | "on;off"(以`;`分隔) | "slot1 net:on;slot2 net:off" |
| 查询指定卡槽 | 0 | 402 | "on" | "slot1 net:on" |
| 设置成功 | 0 | 401 | "1:ON" | "Network settings for slot 1 are being processed asynchronously. Result will be reported later." |
| 关闭唯一联网通道 | 200 | 401 | "" | "The only valid networking channel, it is not allowed to close." |
| 参数错误(p1非法) | 101 | 401 | "" | "Invalid slot: must be 1-2" |
| Token无效 | 100 | 401 | - | Token验证失败 |

val格式规则：查询所有=`状态1;状态2`；查询单个=`状态`；设置=`卡槽号:状态`

## 反馈字段

| 字段 | 类型 | 说明 |
|------|------|------|
| subType | 数值 | slotnet固定=17 |
| code | 数值 | 0=成功；100=Token无效；101=参数错误(p1非1~2)；200=一般错误(关闭唯一通道等) |
| type | 数值 | 401=异步处理中/错误；402=同步执行完成 |
| val | 字符串 | 联网状态数据，格式见上表 |
| note | 字符串 | 操作结果描述 |
| netCh | 数值 | slotnet响应中固定=0 |
| devId | 字符串 | 设备唯一ID(十六进制) |
| msgTs | 数值 | Unix时间戳(秒) |

## 注意

- 设置非立即生效，异步通过writecard执行(几秒内完成)，卡槽未就绪时writecard可能返回code=200 "slot no service!"，需检查SIM卡是否正确插入，通过后续状态上报消息或观察LED状态确认结果
- 关闭前用stat命令确认WiFi或其他卡槽联网可用
- 状态未变化时尝试slotrst重启卡槽
