# slotpwr - 开关卡槽电源

控制指定卡槽的电源开关状态，或查询当前卡槽的电源状态。

## 行为规则

- 无p2 → 查询模式，返回所有卡槽电源状态
- p1+p2 → 控制模式，改变指定卡槽电源状态
- p2值解析（不区分大小写）：on/true/1 → 开启电源；其他任意值 → 关闭电源（推荐off/false/0）
- p1无效（非1或2）→ 查询模式（无p2）：容错返回所有卡槽状态（code=0）；控制模式（有p2）：返回参数错误（code=101）
- 查询指定卡槽时，实际返回所有卡槽状态

## 约束条件

- 关机后执行运营商基站完整"注销"流程，拨入已关机卡槽提示"已关机"或"暂时无法接通"
- 禁止关闭：卡槽是唯一可用联网通道（含WiFi）时，拒绝关闭操作（code=200）
- 无SIM卡：命令成功返回（code=0），note提示"No SIM card in slot X"，电源状态不会改变
- 已是目标状态：命令成功返回（code=0），note提示"already powered ON/OFF"
- 查询返回"off"时，无SIM卡和关机状态都显示"off"，通过note区分："already powered OFF"=关机；"No SIM card in slot X"=无SIM卡

## 状态转换

- 无卡→正常：插入SIM卡
- 正常→关机：slotpwr off
- 关机→正常：slotpwr on / 设备重启 / 重新插入SIM卡
- 正常→在线：启动完成
- 无卡和关机状态均显示电源为"off"

## 唤醒条件

- 重新插入SIM卡 → 自动唤醒
- 设备重启（含每日自动重启）→ 所有已关机卡槽被唤醒

## 命令格式

**HTTP**: `http://<IP>/ctrl?token=<token>&cmd=slotpwr&p1=<slot>&p2=<state>`

**TCP**（末尾须附加0x11 0x12）: `{"cmd":"slotpwr", "p1":"1", "p2":"off", "tid":"1234"}\x11\x12`

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| token | 字符型 | 是 | 管理员Token |
| cmd | 字符型 | 是 | "slotpwr" |
| p1 | 数值型 | 否 | 卡槽号：1=卡槽1，2=卡槽2；省略或无效时返回所有卡槽状态 |
| p2 | 字符型 | 否 | 电源状态（不区分大小写）：on/true/1=开启，其他值=关闭（推荐off/false/0）；省略时为查询模式 |
| tid | 字符型 | 否 | 事务追踪ID，携带时原样返回，用于关联请求与响应 |

## 反馈结果

subType固定=18。val格式：查询时为`状态1;状态2`；控制时为`卡槽号:状态`。

| 场景 | type | code | val | note |
|------|------|------|-----|------|
| 查询所有/指定卡槽 | 402 | 0 | "on;on" | "slot1 power:on;slot2 power:on" |
| 开启成功 | 402 | 0 | "1:ON" | "The slot POWER 1 is turned ON" |
| 关闭成功 | 402 | 0 | "1:OFF" | "The slot POWER 1 is turned OFF" |
| 已是目标状态 | 402 | 0 | "1:ON/OFF" | "The slot 1 was already powered ON/OFF" |
| 无SIM卡 | 402 | 0 | "X:ON/X:OFF" | "No SIM card in slot X" |
| 不允许关闭 | 401 | 200 | - | "The only valid networking channel, it is not allowed to POWER OFF." |
| 参数错误 | 401 | 101 | - | "Invalid p1 (slotId): must be 1 or 2" |

> 无SIM卡时val反映命令目标状态（p2=on→"X:ON"，p2=off→"X:OFF"），非实际电源状态。

## 反馈字段

| 字段 | 说明 |
|------|------|
| type | 401=命令收到处理中/错误；402=命令执行完成 |
| subType | slotpwr固定=18 |
| code | 0=成功；101=参数错误(p1非1或2)；200=一般错误(如关闭唯一联网通道) |
| val | 电源状态：查询时`状态1;状态2`，控制时`卡槽号:状态` |
| note | 操作结果描述 |
| devId | 设备唯一ID（十六进制） |
| netCh | 推送通道：0=WiFi，1=SIM1，2=SIM2 |
| msgTs | Unix时间戳（秒） |

## 与slotnet区别

- slotpwr off = 模块关机（深度关闭，类似手机关机）
- slotnet off = 仅禁止联网，模块仍在线

## 注意事项

- 关闭前确保有其他联网通道可用（用stat确认），且目标卡槽非活跃通话通道；如有重要业务先切换到其他通道
- 关闭后等30秒确认完全关机；关闭不影响其他卡槽
- 设备重启（含每日自动重启）后所有卡槽恢复开机，如需保持关闭需重启后重新发送slotpwr off；建议调整每日重启时间（参见dailyrst命令）或关闭每日自动重启
- 状态未变化时尝试slotrst重启卡槽
