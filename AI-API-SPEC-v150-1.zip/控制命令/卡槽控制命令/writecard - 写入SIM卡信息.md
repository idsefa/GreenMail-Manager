# writecard - 写入SIM卡信息

向指定卡槽写入SIM卡信息（号码/名称/联网开关/流量/通话统计），同步到4G模块并持久化到配置文件。前置：卡槽须已完成初始化（插入SIM卡并等待模块就绪），否则返回code=200。除p1外所有参数可选，未指定保持原值。

## 接口
- HTTP: GET `/ctrl?token=...&cmd=writecard&p1=...`
- TCP: `{"cmd":"writecard","p1":...}` + 结束符`0x11 0x12`

## 执行流程与错误
1. 验证p1(1~2) → 无效: code=101 "Invalid slot ID: X. Valid range: 1-2"
2. 检查卡槽状态 → 未就绪: code=200 "slot no service!"
3. 验证比例: p9须1~99, p10须1~99, p9<p10（p9/p10可单独设置） → 违反: code=101("p9 must be 1-99"/"p10 must be 1-99"/"P9 shall not exceed P10")
4. 立即返回type=401 code=0 "writing..." → 执行写入(3~5秒)
   - 成功: 异步推送type=402 code=0 "Write card successfully."
   - 失败: 返回type=401 code=200 "Failed to write card."

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| token | string | 是(HTTP) | 管理员Token，HTTP接口必填；TCP接口无需token |
| cmd | string | 是 | 固定`writecard` |
| p1 | int | 是 | 卡槽号 1~2 |
| tid | string | 否 | 事务ID，原样回传 |
| p2 | string | 否 | 电话号码（11位手机号，也允许任意字符串或空） |
| p3 | string | 否 | 卡槽名称/备注 |
| p4 | int/string | 否 | 联网开关: 1/on/true=开, 其他任意值=关, 设置后立即同步到4G模块 |
| p5 | int | 否 | 月套餐总量MB 0~65535, 需手动更新 |
| p7 | int | 否 | 已消耗流量KB 0~4294967295, 设备自动累加 |
| p9 | int | 否 | 消耗比例下限 1~99 默认70%(ratioMin), 可单独设置 |
| p10 | int | 否 | 消耗比例上限 1~99 默认85%(ratioMax), 须>p9, 可单独设置 |
| p11 | int | 否 | 呼入接通次数 0~65535 |
| p12 | int | 否 | 呼入累计分钟 0~65535 |
| p13 | int | 否 | 呼出接通次数 0~65535 |
| p14 | int | 否 | 呼出累计分钟 0~65535 |

## 返回

**type=401**(命令已收到/处理中/处理前错误):
```json
{"subType":38,"code":0,"val":"","note":"writing...","type":401,"netCh":0,"msgTs":...}
```

**type=402**(3~5秒后异步推送，命令处理完成):
```json
{"subType":38,"code":0,"val":"","note":"Write card successfully.","type":402,"netCh":0,"msgTs":...}
```

公共字段: subType固定38, code(0成功/101参数错/200状态错), val保留, netCh通道号, msgTs时间戳(秒)。

## 流量比例机制
ratioMin(p9)~ratioMax(p10)范围内随机生成ratioRndTarget(默认77%), 用于智能流量管理。

## 使用示例
- 设置基本信息: `p1=1&p2=13800138000&p3=工作卡`
- 流量配置: `p1=1&p4=1&p5=2048&p7=1024000&p9=70&p10=85`
- 通话统计: `p1=1&p11=10&p12=30&p13=5&p14=15`
- 关闭联网: `p1=1&p4=0`
- 仅改名称: `p1=2&p3=备用卡`

## 补充
- 配置持久化，重启有效
- 故障排除: code=200检查卡槽初始化; 写入失败检查4G模块/重启卡槽; 未保存检查存储空间/重启设备
- 相关命令: readcard读取卡槽信息验证写入
- 建议: 初始化时设p2/p3/p5/p9/p10; 每月初重置流量; 一次命令设多参数减少通信
