# slotrst - 重启指定卡槽

## 功能
重启指定SIM卡槽，等效手动弹出再插入SIM卡。全程约60秒（延迟+SIM重识+网络注册），因运营商网络略有差异。两卡槽独立互不影响。

## 处理流程
1. 校验p1 → 无效/缺失 → code=101
2. 检查有SIM卡 → 无卡 → code=200 "No SIM card in slot, restart meaningless."
3. 检查是否正在重启 → 是 → code=200 "Slot is already in reboot process."
4. 检查是否已关机 → 是 → code=200 "Slot is already power off."
5. 取消之前的待执行重启（如有）→ 按新参数设N秒延迟 → 返回成功
6. 等待N秒 → 关机（推送402/18 OFF + 205）→ 等3秒 → 开机（推送402/18 ON + 202 + 203 + 204）

**延迟机制**：设计目的是重启前完成必要清理，同时提供取消机会。
- **延迟等待期**：新slotrst会重置延迟（等效取消旧请求重新计时）
- **重启执行期**：延迟到期后执行关机→等3秒→开机→SIM初始化，不可取消/中断（仅断电可停止）。短暂时间窗口内：关机未完成时新命令被当作新请求接受(code=0)；关机已完成时返回"Slot is already power off."

## 命令格式
HTTP: `http://<IP>/ctrl?token=<token>&cmd=slotrst&p1=<slot>[&p2=<delay>]`
TCP（末尾须附加0x11 0x12）: `{"cmd":"slotrst","p1":1,"p2":10,"tid":"1234"}\x11\x12`

## 参数
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| token | 字符 | 是 | 管理员Token |
| cmd | 字符 | 是 | "slotrst" |
| p1 | 数值 | 是 | 卡槽号，仅1或2 |
| p2 | 数值 | 否 | 延迟秒数，默认5，范围1~30，超范围自动修正（≤0→1，>30→30） |
| tid | 字符 | 否 | 事务追踪ID，原样返回用于关联请求与响应 |

## 反馈结果
响应公共结构：`{"type":T,"subType":19,"code":C,"val":"","note":"N","devId":"...","netCh":0,"msgTs":...}`

| 场景 | type | code | note |
|------|------|------|------|
| 成功 | 402 | 0 | "Slot <N> restarting in <sec> seconds..." |
| 参数错误 | 401 | 101 | ""（空；原因：p1缺失/非数字/不在1-2范围） |
| 无卡 | 401 | 200 | "No SIM card in slot, restart meaningless." |
| 正在重启中 | 401 | 200 | "Slot is already in reboot process." |
| 已关机 | 401 | 200 | "Slot is already power off." |

字段语义：type=401(收到命令，处理中或处理前错误)/402(命令已执行完返回结果)；subType固定=19；code=0(成功)/101(参数格式错误)/200(一般性错误)；val保留为空；note含边界修正后的实际延迟秒数；devId设备唯一标识；netCh=0(WiFi)/1(SIM1)/2(SIM2)；msgTs=Unix秒级时间戳

## 重启过程推送消息（按执行顺序）
| 消息 | 含义 |
|------|------|
| 402/subType=18 | 电源OFF（"The slot POWER X is turned OFF"） |
| 205 | SIM卡弹出及详情(含IMSI/ICCID/手机号/运营商/PLMN) |
| 402/subType=18 | 电源ON（"The slot POWER X is turned ON"） |
| 202 | SIM卡初始化中（已被识别，正在初始化） |
| 203 | SIM卡信息读取中（读取IMSI/ICCID/手机号等） |
| 204 | SIM卡已就绪（初始化完成，可正常通信） |

## 使用场景
适用：SIM卡网络异常/频繁掉线、更换SIM卡后重新识别、运营商网络切换后重新注册
推荐延迟：紧急5秒(默认)；计划维护15~30秒(缓冲期可发新命令取消)
不建议：频繁重启；无SIM卡时发送；对已关机卡槽发送

## 故障排除
- code=101：p1格式错误，确保为1或2
- code=200"无卡"：检查SIM卡是否正确插入
- code=200"已在重启中"：等待当前重启完成
- code=200"已关机"：若因slotrst导致则等待完成；否则需先slotpwr开机
- 重启执行期间发新命令返回code=0：关机未完成时新命令被当新请求接受，属正常行为，按新参数重新调度
- 重启后仍不可用：SIM卡可能损坏或欠费，更换测试
- 未收到推送：检查设备与云端通信状态
- 卡槽一直重启中：SIM卡故障或硬件问题，更换SIM卡测试，持续则检修
