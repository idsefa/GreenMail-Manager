# settokenstrategy - 设置token提取表达式

设置设备token提取表达式（tokenStrategy），tokenStrategy是设备动态计算当前管理员token的模板表达式。**采用"双参+预验证"模式**：必须同时提供新表达式（p1）和在新表达式下算出的新token（p2），设备用p1在本地计算期望token与p2比对，**匹配才保存**，不匹配不影响当前token使用。此设计防止表达式错误导致用户被锁死。

## Token计算算法（决定p2如何计算）

| 步骤 | 操作 | 说明 |
|------|------|------|
| 1 | 模板替换 | 对tokenStrategy表达式做模板变量替换（如 `{{devId}}`、`{{adminName&#124;$concat('&#124;', '{{adminPwd}}')&#124;$md5()}}` 等） |
| 2 | 长度判断 | 替换后字符串长度是否>32 |
| 3a | 长度≤32 | 直接使用替换后的完整字符串作为token |
| 3b | 长度>32 | 取**中间32个字符**：从长度中点向前后各取16位 |

p2必须用**完全相同的算法**（getAccessToken：calcString + 长度>32截中间32）和正确的adminName/adminPwd本地计算，否则设备拒绝。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `settokenstrategy` |
| token | string | HTTP必填 | **当前**管理员Token；TCP接口无需token |
| p1 | string | 是 | 新的token提取表达式（trim后非空、无换行、语法合法） |
| p2 | string | 是 | 用p1表达式在本地算出的新token（算法必须与设备一致） |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

**两参都必填**，缺任何一个返回code=101。

## 接口格式

- **HTTP**: `GET http://<设备IP>/ctrl?token=<当前token>&cmd=settokenstrategy&p1=<新表达式>&p2=<新token>`
- **TCP**: `{"cmd":"settokenstrategy","p1":"<新表达式>","p2":"<新token>","tid":"<ID>"}\x11\x12`

## 校验顺序

1. p1和p2都存在？→ 缺都：`p1 (new strategy) and p2 (new token under new strategy) are both required. You must compute p2 locally first using the same algorithm as the device.`；仅缺p1：`Missing p1 (new strategy)`；仅缺p2：`Missing p2 (new token). You must compute the new token locally first (using new strategy + current adminName/adminPwd), then pass it as p2.`
2. trim后p1非空？→ `p1 (new strategy) must not be empty`
3. p1无换行？→ `p1 must not contain newline characters`（val回显原入参）
4. trim后p2非空？→ `p2 (new token) must not be empty`
5. ★用p1计算期望token（**不修改任何状态**），与p2比对
6. 匹配→保存p1；不匹配→ `p2 does not match the token computed by new strategy. Please verify: (1) p2 is computed using the same algorithm as the device (getAccessToken: calcString + length>32 truncate to mid-32); (2) adminName/adminPwd are correct; (3) p1 syntax is valid.`（**不泄露期望值**）
7. 保存成功→code=0；保存失败→code=999，note=`Failed to write config file!`

## 响应

subType=63。设置成功返回type=402/code=0；参数/验证错误返回type=401/code=101；Token错误返回type=401/code=100；配置保存失败返回type=402/code=999。成功val固定为 `"ok"`。

成功：
```json
{"subType":63,"code":0,"val":"ok","note":"tokenStrategy updated. Use the new token (p2) for subsequent commands.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645914}
```

## 安全保证

- **不会被锁死**：验证阶段纯计算不修改任何状态，无论验证成功/失败当前token始终有效
- **防暴力枚举**：p2不匹配时错误响应**绝不返回设备计算的期望token**，攻击者无法通过枚举p2探测正确值
- **验证通过立即生效**：保存成功后设备后续验证token都用新表达式计算，必须用p2作为新token

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | 设置成功（验证通过且已保存） | 402 |
| 100 | Token错误（当前token无效） | 401 |
| 101 | 参数/验证错误(缺p1/p2；p1空/含换行；p2空/不匹配) | 401 |
| 999 | 配置写入失败（文件系统异常） | 402 |

## 备注

- 双参预验证模式原因：若只传p1一旦表达式错误将无法计算正确token被锁死；双参确保p2(本地计算)与设备一致才保存
- p1含换行符会破坏配置文件，直接返回code=101
- 保存好新token：设置成功后旧token立即失效，后续命令必须用p2
- 修改adminPwd后token会变（若tokenStrategy表达式引用了adminName/adminPwd）
- tokenStrategy支持的模板变量取决于设备的模板替换规则（如devId、devName、admin凭据等）
- 先在本地充分验证算法与设备一致再发命令；设置后用 `asktokenstrategy` 确认表达式
- p2不匹配排查三要素：①算法是否=模板替换+截中间32 ②adminName/adminPwd是否正确 ③p1语法是否合法
- 相关命令：setdevidstrategy/setdevnamestrategy（devId/devName变化会间接影响引用它们的tokenStrategy）、chpwdadmin（修改密码导致token变化）
- 详见 `安全模型与token机制.md`
