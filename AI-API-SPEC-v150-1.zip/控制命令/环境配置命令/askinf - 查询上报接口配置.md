# askinf - 查询上报接口配置

查询设备与云端/平台通信的接口配置，含URL、HTTP方法、Content-Type三个维度。`setinf`的查询配套命令。**安全特性**：URL中`smtp://`行的`pwd=`值会掩码为`****`（防止密码泄露），多URL主备接口时每行分别掩码处理。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `askinf` |
| token | string | HTTP必填 | 管理员Token；TCP接口无需token |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

## 接口格式

- **HTTP**: `GET http://<设备IP>/ctrl?token=<token>&cmd=askinf`
- **TCP**: `{"cmd":"askinf","tid":"<ID>"}\x11\x12`（末尾必须附加2字节二进制结束符`0x11 0x12`）

## 响应

subType=62。查询成功返回type=402/code=0；Token错误返回type=401/code=100。

成功（普通HTTP）：
```json
{"subType":62,"code":0,"val":"{\"url\":\"https://api.example.com/report\",\"method\":1,\"ctype\":1}","note":"inf queried. (val is JSON string)","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645914}
```

成功（含SMTP密码掩码）：
```json
{"subType":62,"code":0,"val":"{\"url\":\"smtp://smtp.qq.com:25?user=dev001&pwd=****&from=dev001@qq.com&to=admin@example.com\",\"method\":0,\"ctype\":0}","note":"inf queried. (smtp password masked) (val is JSON string)","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645920}
```

成功（URL为空）：`val="{\"url\":\"\",\"method\":0,\"ctype\":0}"`
成功（多URL主备）：url中两个URL以`\r\n`分隔。

Token错误(code=100)：`note="Invalid token."`, type=401, 无val字段。

**note字段规则**：普通URL=`inf queried. (val is JSON string)`；含smtp://且发生掩码=`inf queried. (smtp password masked) (val is JSON string)`。

## val字段结构

val为JSON字符串（需二次JSON.parse），结构 `{"url":"...","method":N,"ctype":N}`：

| 字段 | 类型 | 说明 |
|------|------|------|
| url | string | 接口URL原始配置串。多URL含`\r\n`分隔，smtp://行的pwd=值已掩码为**** |
| method | number | HTTP方法：0=GET，1=POST |
| ctype | number | Content-Type：0=FORM，1=JSON |

**SMTP密码掩码规则**：按`\r\n`拆分URL多行，对以`smtp://`开头且含`pwd=`的行，将`pwd=`后到下一个`&`或行尾的值替换为`****`；非smtp行保持原样。pwd在行尾时也正确掩码。

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | 查询成功 | 402 |
| 100 | Token错误 | 401 |

## 备注

- val是字符串非JSON对象，需先JSON.parse再访问url/method/ctype
- SMTP密码`****`是正常安全掩码，非错误；如需修改SMTP密码用`setinf`重设完整URL
- url为空表示从未配置或已被清空，用`setinf`设置
- 标准流程：setinf设置后立即用askinf验证配置已写入Flash
- 相关命令：setinf(统一设置URL+method+ctype)
