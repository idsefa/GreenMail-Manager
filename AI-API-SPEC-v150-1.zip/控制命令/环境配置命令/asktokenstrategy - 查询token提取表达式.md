# asktokenstrategy - 查询token提取表达式

查询设备当前的token提取表达式（tokenStrategy），tokenStrategy是设备动态计算管理员token的模板表达式。无业务参数，只读。修改用 `settokenstrategy`。

**默认算法**：未设置tokenStrategy时token=`MD5("admin|密码")`。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `asktokenstrategy` |
| token | string | HTTP必填 | 管理员Token；TCP接口无需token |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

## 接口格式

- **HTTP**: `GET http://<设备IP>/ctrl?token=<token>&cmd=asktokenstrategy`
- **TCP**: `{"cmd":"asktokenstrategy","tid":"<ID>"}\x11\x12`

## 响应

subType=64。查询成功返回type=402/code=0；Token错误返回type=401/code=100。

val为当前token提取表达式字符串，**可能为空串**（表示未设置自定义表达式，使用默认算法 `MD5("admin|密码")`）。note固定为 `"tokenStrategy queried."`。

```json
{"subType":64,"code":0,"val":"你的表达式内容","note":"tokenStrategy queried.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645914}
```

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | 查询成功 | 402 |
| 100 | Token错误 | 401 |

## 备注

- val为空串=未设置自定义表达式，使用默认算法 `MD5("admin|密码")`（正常现象）
- settokenstrategy设置后用本命令二次查询可验证表达式已正确写入
- 详见 `安全模型与token机制.md`
