# askallmsgcode - 查询全部消息号上报开关

一次性查询设备**31个标准消息号**当前的"已启用/未启用"上报开关状态，以分组列表返回。`setallmsgcode`的查询配套命令。无业务参数。**仅覆盖标准消息号**，自定义消息号不在范围内。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `askallmsgcode` |
| token | string | HTTP必填 | 管理员Token；TCP接口无需token |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

## 接口格式

- **HTTP**: `GET http://<设备IP>/ctrl?token=<token>&cmd=askallmsgcode`
- **TCP**: `{"cmd":"askallmsgcode","tid":"<ID>"}\x11\x12`（末尾必须附加2字节二进制结束符`0x11 0x12`）

## 响应

subType=58。查询成功返回type=402/code=0；Token错误返回type=401/code=100；设备接口未就绪返回type=402/code=999（极少见，仅设备启动早期或异常状态）。无code=101路径（无业务参数）。

成功（部分启用）：
```json
{"subType":58,"code":0,"val":"{\"en\":[100,101,401,402,501,502,601,602,603,998],\"dis\":[102,201,202,203,204,205,209,301,503,620,621,622,623,641,642,683,685,687,689,695,696]}","note":"All msg codes queried. (val is JSON string: {\"en\":[...],\"dis\":[...]})","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645914}
```

全部启用：`val`的`dis`为空数组`[]`；全部禁用：`val`的`en`为空数组`[]`（此时连心跳998都不上报，客户端可能误判设备离线）。

Token错误(code=100)：`note="Invalid token."`, type=401, 无val字段。
内部接口无效(code=999)：`val=""`, `note="g_userPub.infs invalid"`, type=402。

## val字段结构

val为JSON字符串（需二次JSON.parse），结构 `{"en":[...],"dis":[...]}`：

| 字段 | 类型 | 说明 |
|------|------|------|
| en | number[] | **已启用**消息号列表，**升序**排列 |
| dis | number[] | **未启用**消息号列表，**升序**排列 |

en与dis无交集无遗漏，两者元素总数=31（旧固件版本数量可能不同）。

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | 查询成功（en/dis可能为空数组） | 402 |
| 100 | Token错误 | 401 |
| 999 | 内部接口无效（设备接口未初始化） | 402 |

## 备注

- val是JSON字符串，直接访问val.en会返回undefined，必须先JSON.parse
- 关键消息号建议保持启用：501(新短信)、601(来电)、998(心跳)
- 纯读取不消耗Flash写入次数，可频繁调用
- en为空通常因误用`SET+p2=on+p1=少数号`把allowTypes覆盖为空，需用`setallmsgcode`恢复
- code=999持续报错时尝试重启设备
- 标准流程：askallmsgcode查询→setallmsgcode修改→askallmsgcode验证
- 相关命令：setallmsgcode(批量设置开关，REPLACE/SET两种模式)
