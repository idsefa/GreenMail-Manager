# askusrargname - 按参数名查询用户参数详情

按参数名（un）查询用户参数详情，返回该参数的`un`/`uv`/`en`字段。**永不返回`us`字段**（接口层透明保留的内部字段）。属于用户参数CRUD四命令之一（其余：getallusrargname列表、setusrargname新增/更新、delusrargname删除）。

用户参数4字段：`un`(参数名,用户可见)、`uv`(参数值,用户可见)、`en`(启用开关,"0"=禁用/"1"=启用,**字段缺失视为启用**)、`us`(适用范围,内部字段,所有命令均不暴露)。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `askusrargname` |
| token | string | HTTP必填 | 管理员Token；TCP接口无需token |
| p1 | string | 是 | 参数名（un）。内部trim处理，trim后不能为空。查找时**精确匹配区分大小写**（`"apn"`与`"APN"`不同） |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

## 接口格式

- **HTTP**: `GET http://<设备IP>/ctrl?token=<token>&cmd=askusrargname&p1=<参数名>`
- **TCP**: `{"cmd":"askusrargname","p1":"<参数名>","tid":"<ID>"}\x11\x12`（末尾必须附加2字节二进制结束符`0x11 0x12`）

## 响应

subType=79。命中返回type=402/code=0；参数格式错误返回type=401/code=101；参数未找到返回type=402/code=200；Token错误返回type=401/code=100；内部接口异常返回type=402/code=999（极罕见）。

**关键区分**：参数**格式错误**(缺参/空值)→code=101+type=401(命令未执行)；参数**找不到**(格式正确但目标不存在)→code=200+type=402(命令已执行但未命中)。

成功（参数完整）：
```json
{"subType":79,"code":0,"val":"{\"un\":\"apn\",\"uv\":\"cmnet\",\"en\":\"1\"}","note":"usrArg queried. (val is JSON string)","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645914}
```

成功（uv/en字段缺失，按启用对待）：
```json
{"subType":79,"code":0,"val":"{\"un\":\"server_url\",\"uv\":\"http://example.com\"}","note":"usrArg queried. (val is JSON string)","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645914}
```

错误响应：
- 缺p1(code=101,type=401): `note="Missing required parameter: p1 (name)"`
- p1 trim后空(code=101,type=401): `note="p1 (name) must not be empty"`
- 未找到(code=200,type=402): `note="usrArg name not found"`, val=""
- Token错(code=100,type=401): `note="Invalid token."`, 无val

## val字段结构

val为JSON字符串（需二次JSON.parse），含以下字段（**永不包含us**）：

| 字段 | 类型 | 说明 |
|------|------|------|
| un | string | 参数名，始终返回 |
| uv | string | 参数值。**字段缺失时不返回**（按空值对待） |
| en | string | 启用开关，`"0"`=禁用/`"1"`=显式启用。**字段缺失时不返回，按启用对待** |

判断启用逻辑必须用 `en !== "0"`，**不能**用 `en === "1"`（因字段缺失也是启用）。底层按"字段缺失=启用"原则存储：仅在显式禁用时写入`en="0"`，启用时不写入en字段。

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | 查询成功（找到匹配项） | 402 |
| 100 | Token错误 | 401 |
| 101 | 参数格式错误（缺p1 / p1 trim后空） | 401 |
| 200 | 参数未找到（p1格式正确但文件中无此un） | 402 |
| 999 | 内部接口未就绪（极罕见） | 402 |

## 备注

- val中含特殊字符（如`\`和`"`）会做JSON转义，用标准JSON解析器即可
- 不确定参数是否存在时先`getallusrargname`列名再查详情，避免code=200
- 每次只查一个参数，不支持批量
- p1中间的空格保留（仅前后trim）；URL传输时需对特殊字符URL编码
- 相关命令：getallusrargname、setusrargname、delusrargname
