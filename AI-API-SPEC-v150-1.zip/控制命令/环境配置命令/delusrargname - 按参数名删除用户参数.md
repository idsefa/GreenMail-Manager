# delusrargname - 按参数名删除用户参数

按参数名（un）删除用户参数。**幂等操作**：即使参数名不存在也返回code=0。删除后立即从本地参数文件移除并持久化到Flash。底层遍历usrArgs，**防御性删除所有**`un==p1`的项（理论上应只有1个，但处理多个同名异常情况）。属于用户参数CRUD四命令之一（详见askusrargname）。

**双模式命令**：校验失败返回type=401；成功（含幂等）返回type=402。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `delusrargname` |
| token | string | HTTP必填 | 管理员Token；TCP接口无需token |
| p1 | string | 是 | 参数名（un），内部trim，trim后不能为空。查找时**精确匹配区分大小写** |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

## 接口格式

- **HTTP**: `GET http://<设备IP>/ctrl?token=<token>&cmd=delusrargname&p1=<参数名>`
- **TCP**: `{"cmd":"delusrargname","p1":"<参数名>","tid":"<ID>"}\x11\x12`（末尾必须附加2字节二进制结束符`0x11 0x12`）

## 响应

subType=81。删除成功（含幂等）返回type=402/code=0；参数格式错误返回type=401/code=101；Token错误返回type=401/code=100；写盘失败返回type=402/code=999。

成功（参数存在已删除 / 参数不存在幂等，响应**完全相同**无法区分）：
```json
{"subType":81,"code":0,"val":"ok","note":"usrArg deleted (or not exist).","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645914}
```

错误响应：
- 缺p1(code=101,type=401): `note="Missing required parameter: p1 (name)"`, val=""
- p1空(code=101,type=401): `note="p1 (name) must not be empty"`, val=""
- 写盘失败(code=999,type=402): `note="Failed to write config file!"`, val=""（设备回滚到旧文档，参数未被删除）
- Token错(code=100,type=401): `note="Invalid token."`, 无val

| 字段 | 类型 | 说明 |
|------|------|------|
| val | string | 成功=`"ok"`；其他错误=空串 |
| note | string | 成功统一=`"usrArg deleted (or not exist)."` |

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | 删除成功（含幂等：参数本就不存在） | 402 |
| 100 | Token错误 | 401 |
| 101 | 参数格式错误（缺p1 / p1 trim后空） | 401 |
| 999 | 配置写盘失败（文件系统异常/OOM兜底） | 402 |

## 备注

- 幂等：参数不存在不报错，无需先查询；如需知道删除前是否存在，先调`askusrargname`(code=0存在/code=200不存在)
- 大小写敏感：删除返回code=0但参数仍在，可能是大小写不匹配删了"另一个"参数，用`getallusrargname`确认实际拼写
- 删除不可恢复，立即从Flash移除，需重新`setusrargname`才能恢复（如记得原值）
- 配置立即生效，无需重启设备
- 每次只删一个参数名（但底层会处理同名重复），不支持批量
- code=999时设备已回滚，参数仍存在
- 相关命令：askusrargname、getallusrargname、setusrargname
