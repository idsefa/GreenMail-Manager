# ackmax - 设置/查询 HTTP/TCP 应答超时时间

设备收到带 TID 字段消息后，返回应答消息的最大等待时间。超时后停止等待并释放资源。**此设置对所有 HTTP/TCP 接口通信生效**。设置立即保存到 Flash，重启有效。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| token | string | 是 | 管理员 Token |
| cmd | string | 是 | "ackmax" |
| p1 | int | 否 | 超时时间(ms)。范围 100~8000(防止过短导致通信失败或过长占用资源)，默认 8000。省略则为查询模式 |
| tid | string | 否 | 事务追踪ID，响应中原样返回，关联请求与响应 |

## 执行流程

1. **无 p1 → 查询**: 读取当前值 → `code=0, type=402`
2. **有 p1 → 设置**:
   - p1 非整数 → `code=101, type=401`, val="", note="p1 (ackMax) must be a valid number"
   - p1 不在 100~8000 → `code=101, type=401`, note="p1 must be an int value between 100 and 8000"
   - p1 有效 → 保存 Flash: 成功→`code=0, type=402`; 失败→`code=999, type=402`

## 响应 JSON 字段

| 字段 | 类型 | 说明 |
|------|------|------|
| subType | int | 通常为 0 |
| code | int | 0=成功; 101=参数格式错误或超出范围; 999=配置文件保存失败 |
| val | string | 当前或新设置的超时时间(ms)，参数格式错误时为空 |
| note | string | 操作结果描述 |
| devId | string | 设备唯一标识 |
| type | int | 401=参数验证阶段响应; 402=执行结果响应 |
| netCh | int | 网络通道号 |
| msgTs | int | 消息时间戳(Unix) |

## 请求格式

HTTP GET:
```
/ctrl?token={adminToken}&cmd=ackmax          # 查询
/ctrl?token={adminToken}&cmd=ackmax&p1=5000  # 设置
```

TCP(消息末尾必须附加 `\x11\x12`，否则设备无响应):
```json
{"cmd":"ackmax", "p1":5000, "tid":"1234"}
```

## 响应示例

查询成功(code=0, type=402):
```json
{"subType":0,"code":0,"val":"8000","note":"ackMax value is:8000","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773640684}
```

设置成功(code=0, type=402):
```json
{"subType":0,"code":0,"val":"5000","note":"ackMax has been changed.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773640701}
```

参数超出范围(code=101, type=401):
```json
{"subType":0,"code":101,"val":"10000","note":"p1 must be an int value between 100 and 8000","devId":"c3dd382801","type":401,"netCh":0,"msgTs":1773640749}
```

参数非整数(code=101, type=401):
```json
{"subType":0,"code":101,"val":"","note":"p1 (ackMax) must be a valid number","devId":"c3dd382801","type":401,"netCh":0,"msgTs":1773640749}
```

配置保存失败(code=999, type=402):
```json
{"subType":0,"code":999,"val":"5000","note":"Failed to write config file!","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773640800}
```

## 附注

- p1 必须为纯整数，不含空格或其他字符。非整数时 val 为空
- 参数范围建议: 100~500ms(极低延迟/本地优良网络), 500~2000ms(一般网络), **2000~5000ms(推荐/多数网络)**, 5000~8000ms(高延迟网络)。延迟较高时适当增加超时，过短可能误判正常响应为失败
- 恢复默认值: `p1=8000`
- 设置成功但查询值未变 → code=999 表示 Flash 写入失败，检查存储空间/写入权限，或重启后重试
- 相关命令: `stat`(返回结果含当前 ackMax 值)
