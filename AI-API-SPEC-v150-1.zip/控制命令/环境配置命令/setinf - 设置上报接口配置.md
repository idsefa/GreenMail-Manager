# setinf - 设置上报接口配置

一次性统一设置设备与云端/平台通信的主接口配置，含三维度：URL(p1)、HTTP方法(p2)、Content-Type(p3)。三参都可选，至少传一个；未传/留空的参数保留原值。任一传入参数非法则**整个请求被拒绝**（不会部分生效）。p1支持多URL（用`\r\n`分隔，主备接口按序尝试），支持协议白名单`http://`/`https://`/`tcp://`/`smtp://`（smtp有严格校验）。配置立即写入Flash，重启后仍有效。

**与setamrurl区别**：setinf支持`tcp://`和多URL（主备），但**不识别`clear`关键字**（清空URL的唯一方式是传trim后为空串）。setamrurl支持`clear`但不支持`tcp://`和多URL。setinf作用于主通信接口；setamrurl作用于通话录音上报接口。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `setinf` |
| token | string | HTTP必填 | 管理员Token；TCP接口无需token |
| p1 | string | 否 | 接口URL。trim后空串=清空；非空=按`\r\n`拆行后逐行严格校验。详见"p1 URL规则" |
| p2 | string | 否 | HTTP方法。`0`/`get`=GET，`1`/`post`=POST（忽略大小写）；未传/空串=保留原值；其他=非法 |
| p3 | string | 否 | Content-Type。`0`/`form`=x-www-form-urlencoded，`1`/`json`=application/json（忽略大小写）；未传/空串=保留原值；其他=非法 |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

## 接口格式

- **HTTP**: `GET http://<设备IP>/ctrl?token=<token>&cmd=setinf&p1=<URL>&p2=<0/get/1/post>&p3=<0/form/1/json>`
- **TCP**: `{"cmd":"setinf","p1":"<URL>","p2":"<method>","p3":"<ctype>","tid":"<ID>"}\x11\x12`

> TCP消息末尾必须附加2字节二进制结束符`0x11 0x12`（非字符串）。HTTP传多URL用`%0D%0A`编码换行；TCP的JSON中用`\r\n`转义。

## 参数校验顺序（关键）

1. **至少一个参数**：p1/p2/p3都未传 → code=101/note=`At least one of p1/p2/p3 must be provided`
2. **校验p2**：非空且非`0/1/get/post`（忽略大小写）→ code=101/note=`p2 invalid: must be 0/1/get/post (case insensitive)`/val回显原入参
3. **校验p3**：非空且非`0/1/form/json`（忽略大小写）→ code=101/note=`p3 invalid: must be 0/1/form/json (case insensitive)`/val回显原入参
4. **p1 URL处理**（p1存在时）：
   - trim后为空串 → 清空URL
   - 非空 → 按`\r\n`拆行，逐行校验：
     - 协议白名单（忽略大小写）：必须是`http://`/`https://`/`tcp://`/`smtp://`之一 → 失败：code=101/note=`URL must start with http://|https://|tcp://|smtp://`/val回显原入参
     - smtp严格校验：`smtp://`开头的行需满足`smtp://host:port?user=xxx&pwd=xxx&from=xxx&to=xxx`（host:port/user/pwd/from/to必填，cc/bcc/tls可选）→ 失败：code=101/note=`smtp URL invalid: <具体缺失字段>`/val回显原入参
5. **保存配置**：只改传入字段。保存失败 → code=999/note=`Failed to write config file!`

## 响应

subType=61。参数验证阶段错误→type=401（code=101）；执行成功或写盘失败→type=402（code=0或999）。Token错误返回type=401/code=100/note=`Invalid token.`。

成功（单URL）：
```json
{"subType":61,"code":0,"val":"{\"url\":\"https://api.example.com/report\",\"method\":1,\"ctype\":1}","note":"inf updated.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645914}
```

成功（多URL，`\r\n`被转义）：
```json
{"subType":61,"code":0,"val":"{\"url\":\"https://api.example.com/report\\r\\nhttps://backup.example.com/report\",\"method\":1,\"ctype\":1}","note":"inf updated.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645920}
```

成功（清空URL）：`val="{\"url\":\"\",\"method\":1,\"ctype\":1}"`

错误响应val字段说明：缺参/保存失败val=`""`；p2/p3/URL非法val=回显原始入参。

## val字段结构（成功响应，需二次JSON.parse）

| 字段 | 类型 | 说明 |
|------|------|------|
| url | string | 接口URL原始串。多URL含`\r\n`分隔（响应中转义为`\\r\\n`）；清空后为`""` |
| method | number | HTTP方法：0=GET，1=POST |
| ctype | number | Content-Type：0=FORM，1=JSON |

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | 设置/清空成功 | 402 |
| 100 | Token错误 | 401 |
| 101 | 缺参 / p2非法 / p3非法 / URL协议非白名单 / smtp校验失败 | 401 |
| 999 | 配置文件写盘失败 | 402 |

## 备注

- 清空URL**必须**用空串（如`p1=`），不能用`clear`关键字（与setamrurl相反）
- p1的多URL换行编码：HTTP用`%0D%0A`，TCP的JSON用`\r\n`转义
- 设置后建议用`askinf`验证（SMTP密码会被掩码）
- 设置成功但上报仍失败：URL服务端不可达，需检查防火墙/证书
- 相关命令：askinf（查询当前配置，SMTP密码掩码处理）、setamrurl（通话录音上报接口，不支持tcp和多URL但支持clear）
