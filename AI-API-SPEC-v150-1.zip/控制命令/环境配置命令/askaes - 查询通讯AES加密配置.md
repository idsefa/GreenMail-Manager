# askaes - 查询通讯AES加密配置

查询设备当前通讯AES加密配置（key/iv/mode）。`setaes`的查询配套命令。出于安全考虑，返回的key/iv**永远是掩码**（异步ack路径下val会上报到云端，明文有泄露风险），无法逆向还原。查询无失败路径（除Token错误），即使从未设置过key/iv也返回code=0。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `askaes` |
| token | string | HTTP必填 | 管理员Token；TCP接口无需token |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

## 接口格式

- **HTTP**: `GET http://<设备IP>/ctrl?token=<token>&cmd=askaes`
- **TCP**: `{"cmd":"askaes","tid":"<ID>"}\x11\x12`（末尾必须附加2字节二进制结束符`0x11 0x12`，非字符串）

## 响应

subType=60。查询成功返回type=402/code=0；Token错误返回type=401/code=100。查询无其他失败路径。

成功（mode=2双向加密）：
```json
{"subType":60,"code":0,"val":"{\"key\":\"0xaf****f,0xcb\",\"iv\":\"0xb4****d6,0xe7\",\"mode\":2}","note":"AES config queried. (key/iv masked) (val is JSON string)","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773646000}
```

成功（mode=0且key/iv从未设置）：
```json
{"subType":60,"code":0,"val":"{\"key\":\"not set\",\"iv\":\"not set\",\"mode\":0}","note":"AES config queried. (key/iv masked) (val is JSON string)","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773646000}
```

Token错误(code=100)：`note="Invalid token."`, type=401, 无val字段。

## val字段结构

val为JSON字符串（需二次JSON.parse），结构 `{"key":"<掩码>","iv":"<掩码>","mode":N}`：

| 字段 | 类型 | 说明 |
|------|------|------|
| key | string | AES Key掩码（非明文），掩码规则见下 |
| iv | string | AES IV掩码（非明文），掩码规则见下 |
| mode | number | 加密模式：0=NO_AES(不加密)，1=UPLOAD_ONLY(仅设备→接口加密)，2=BOTH(双向加密) |

**key/iv掩码规则**（基于原始字符串的字符长度，非字节数）：

| 原始长度 | 掩码结果 | 示例 |
|----------|----------|------|
| 0（未设置） | `not set` | → `not set` |
| 1~8 | `****` | `1234` → `****` |
| >8 | 前4字符+`****`+后4字符 | `0xaf,0xef,...,0xcb`(≈63字符) → `0xaf****f,0xcb` |

掩码只暴露前4和后4字符，长度≤8完全隐藏，不可逆向。若遗忘密钥只能用`setaes`重新设置。

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | 查询成功 | 402 |
| 100 | Token错误 | 401 |

## 备注

- 通过掩码推断状态：`not set`=从未设置(若同时mode=1/2则加密配置不完整)；`****`=长度1~8(短ASCII，非标准AES 16字节)；`前4****后4`=长度>8(标准16字节ASCII或16进制逗号分隔格式)
- val是字符串非JSON对象，需先JSON.parse再访问key/iv/mode
- 查询成功仅说明设备侧配置正确，云端收不到设备消息的常见原因：①设备mode=1/2但云端未配置对应解密 ②设备与云端key/iv不一致 ③网络问题
- 仅查询当前配置，无历史修改记录
- 相关命令：setaes(设置key/iv/mode任意组合)、setinf(接口服务器配置)
