# askcustmsg - 查询自定义接口消息模板

查询设备**自定义接口消息模板**（用于设备主动上报给用户接口的个性化消息内容）。**双模式命令**：不传p1为列表查询返回所有已配置模板的msgId数组；传p1为单条查询返回该msgId的模板body原文。

配置文件内部用`~~--==~~--==`作分隔符，模板内容**不能**包含此行。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `askcustmsg` |
| token | string | HTTP必填 | 管理员Token；TCP接口无需token |
| p1 | string | 否 | msgId，必须**纯正整数字符串**（无+/-前缀）。不传p1=列表查询，传p1=单条查询 |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

**p1校验**：允许`"100"`/`"501"`/`"9999"`；拒绝`"-1"`(带负号)/`"+5"`(带正号)/`"abc"`(非数字)/`"3.14"`(小数)。

## 接口格式

- **HTTP列表**: `GET http://<设备IP>/ctrl?token=<token>&cmd=askcustmsg`
- **HTTP单条**: `GET http://<设备IP>/ctrl?token=<token>&cmd=askcustmsg&p1=<msgId>`
- **TCP**: `{"cmd":"askcustmsg","p1":"<msgId或省略>","tid":"<ID>"}\x11\x12`（末尾必须附加2字节二进制结束符`0x11 0x12`）

## 响应

subType=76。查询成功（含模板不存在）返回type=402/code=0；p1格式错误返回type=401/code=101；Token错误返回type=401/code=100。

| 场景 | code | type | val | note |
|------|------|------|-----|------|
| 列表查询(有模板) | 0 | 402 | `[id1,id2,...]` JSON数组字符串 | `N custMsg IDs queried.` (N=实际数量,可能为0) |
| 列表查询(无模板) | 0 | 402 | `[]` | `0 custMsg IDs queried.` |
| 单条查询(命中) | 0 | 402 | 模板body原文(已trim去尾部换行,非JSON) | `custMsg body queried.` |
| 单条查询(未配置/空) | 0 | 402 | 空串`""` | `custMsg not configured.` |
| p1非法(含+/-或非数字) | 101 | 401 | 原入参p1 | `p1 (msgId) must be a positive number string` |
| Token错误 | 100 | 401 | 无val字段 | `Invalid token.` |

列表查询示例：
```json
{"subType":76,"code":0,"val":"[100,101,501]","note":"3 custMsg IDs queried.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773640684}
```

单条查询命中示例：
```json
{"subType":76,"code":0,"val":"{\"event\":\"call_in\",\"devId\":\"%devid%\",\"phone\":\"%phone%\"}","note":"custMsg body queried.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773640684}
```

## val字段结构

**两种模式val含义不同**：

- **列表查询（无p1）**：val为JSON数组字符串如`"[100,101,501]"`，需二次JSON.parse。元素按**数值升序**排序（非字典序），如`["99","100","20"]`→`[20,99,100]`，避免`"100"`排在`"20"`前的反直觉。
- **单条查询（有p1）**：val为模板body原文（已trim），可能是JSON/XML/纯文本任意格式，按业务约定解析，不强制JSON。

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | 成功（列表查询或单条查询，即使模板不存在） | 402 |
| 100 | Token错误 | 401 |
| 101 | p1格式错误（非纯数字/含+/-符号/含字母） | 401 |

## 备注

- 单条查询模板不存在也是code=0（非错误），仅val为空串、note=`custMsg not configured.`
- 当前版本**不再有550B截断限制**，但设备内存有限，超长模板可能因内存不足导致响应失败
- 区分"未配置"(code=0/val="")和"查询失败"(code=101)
- 客户端解析：列表val需JSON.parse；单条val按业务约定解析（不一定是JSON）
- 批量查询：先列表查询拿ID数组，再循环单条查询
- 删除后模板不再存在，查询返回`custMsg not configured.`
- 相关命令：setcustmsg(增删改模板)
