# setcustmsg - 设置自定义接口消息模板

新增、更新或删除设备的自定义接口消息模板（Custom Message Template）。一个命令同时承担三种语义，通过p2是否提供/非空自动判断：p2非空=新增/更新（覆盖式），p2缺失或trim后空=删除。**删除是幂等的**：删除不存在的msgId也返回code=0。模板内容可以是任意字符串（JSON/XML/纯文本均可）。

**特殊校验**：模板内容**不能包含分隔符行**`~~--==~~--==`（配置文件内部结构标识，混入会破坏文件格式）。命令按行拆分p2，**任一行trim后等于此分隔符**都会被拒绝。本命令**不会返回999/200**：即使底层写盘失败也无失败信号上报，统一视为成功，建议设置后用askcustmsg验证。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `setcustmsg` |
| token | string | HTTP必填 | 管理员Token；TCP接口无需token |
| p1 | string | 是 | msgId，必须为**纯正数字字符串**（无`+`/`-`前缀，无小数点） |
| p2 | string | 否 | 模板内容。缺失或trim后空=删除语义；非空=新增/更新 |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

**操作模式判断**：

| p1 | p2状态 | 模式 | note |
|----|--------|------|------|
| 合法正数字串 | 缺失 | 删除 | `custMsg deleted (or not exist).` |
| 合法正数字串 | trim后空（如`"   "`） | 删除 | 同上 |
| 合法正数字串 | 非空 | 新增/更新 | `custMsg saved.` |
| 非法（带±号/字母/小数） | 任意 | 拒绝code=101 | — |

**p1校验**：允许`"100"`/`"501"`；拒绝`"-1"`/`"+5"`/`"abc"`/`"3.14"`。失败：code=101/note=`p1 (msgId) must be a positive number string`/val回显原入参。

**p2校验**（仅新增/更新模式）：按`\n`拆行，任一行trim后等于`~~--==~~--==` → code=101/note=`p2 contains forbidden separator line`/val=`""`。

## 接口格式

- **HTTP**: `GET http://<设备IP>/ctrl?token=<token>&cmd=setcustmsg&p1=<msgId>&p2=<模板内容>`
- **TCP**: `{"cmd":"setcustmsg","p1":"<msgId>","p2":"<模板内容>","tid":"<ID>"}\x11\x12`

> TCP消息末尾必须附加2字节二进制结束符`0x11 0x12`（非字符串）。HTTP方式模板含`\n`需编码为`%0A`，或改用TCP JSON方式。

## 响应

subType=77。参数错误→type=401（code=101）；成功→type=402（code=0）。Token错误返回type=401/code=100/note=`Invalid token.`。无999/200返回码。

新增/更新成功：
```json
{"subType":77,"code":0,"val":"ok","note":"custMsg saved.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773640684}
```

删除成功（含幂等场景）：note=`custMsg deleted (or not exist).`/val=`"ok"`

错误响应val：p1非法=回显原入参；p2含分隔符=`""`；token错误无val字段。

成功响应val固定为`"ok"`（非JSON结构）。

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | 新增/更新/删除成功（含幂等删除） | 402 |
| 100 | Token错误 | 401 |
| 101 | p1非数字/含符号/小数；p2含禁止分隔符行 | 401 |

## 备注

- msgId=0规则上合法（是纯数字），但业务上建议从100开始编号避免歧义
- msgId必须是纯数字，不能用`failed`等字符串作为模板ID（与clearhttplog的`err`等字符串类型参数不同）
- 模板支持多行内容，按原文存储，但任何一行trim后都不能等于`~~--==~~--==`
- 占位符（如`%devid%`/`%phone%`/`%ts%`）是设备上报时自动替换，配置时写原文即可
- 修改模板用相同msgId直接setcustmsg覆盖即可，无需先删除
- 当前版本取消了HTTP body>1500字节的告警，但超长body可能因堆耗尽表现为连接失败，建议<2KB
- 批量配置每个msgId需独立调用本命令，无批量接口
- 相关命令：askcustmsg（查询，支持单查和列表查）
