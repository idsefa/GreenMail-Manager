# askdevidstrategy - 查询设备ID提取表达式

查询设备当前的devId提取表达式（devIdStrategy），devIdStrategy决定设备如何从通信数据中提取唯一标识符devId。无业务参数，只读。修改用 `setdevidstrategy`（修改后需重启生效）。若tokenStrategy引用devId，重启后token也会变。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `askdevidstrategy` |
| token | string | HTTP必填 | 管理员Token；TCP接口无需token |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

## 接口格式

- **HTTP**: `GET http://<设备IP>/ctrl?token=<token>&cmd=askdevidstrategy`
- **TCP**: `{"cmd":"askdevidstrategy","tid":"<ID>"}\x11\x12`

## 响应

subType=66。查询成功返回type=402/code=0；Token错误返回type=401/code=100。

val为当前devId提取表达式字符串，**可能为空串**（表示未设置自定义表达式，使用设备默认devId提取方式）。note固定为 `"devIdStrategy queried."`。

```json
{"subType":66,"code":0,"val":"你的devId表达式内容","note":"devIdStrategy queried.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645914}
```

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | 查询成功 | 402 |
| 100 | Token错误 | 401 |

## 备注

- val为空串=未设置自定义表达式，使用默认devId提取方式（正常现象）
- setdevidstrategy设置后用本命令二次查询可验证表达式已正确写入
