# setusrargname - 按参数名新增或更新用户参数

按参数名（un）**upsert**用户参数：un已存在→更新（仅修改提供的字段，其他保留）；un不存在→新增。`us`字段透明保留（更新时不动；新增时设为空=全局生效，接口层永不暴露）。属于用户参数CRUD四命令之一（详见askusrargname）。

**双模式命令**：校验失败返回type=401；成功返回type=402。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `setusrargname` |
| token | string | HTTP必填 | 管理员Token；TCP接口无需token |
| p1 | string | 是 | 参数名（un），内部trim，trim后不能为空 |
| p2 | string | 否 | 参数值（uv）。**不trim**（保留前后空格，有意设计如密码/Token可能含意义空格）。缺失=保留原值 |
| p3 | string | 否 | 启用开关（en）。多别名解析（忽略大小写），见下表。缺失=保留原en |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

**p3启用开关多别名解析**（trim后忽略大小写）：

| p3输入 | 解析 | en实际写入 |
|--------|------|-----------|
| `1`/`true`/`enabled`/`on` | 启用 | **不写入en字段**（缺失=启用） |
| `0`/`false`/`disabled`/`off` | 禁用 | 写入`en="0"` |
| 空串/不携带p3 | 不动 | 不修改原en |
| 其他任意值（如`yes`/`no`） | 非法 | - (返回code=101) |

底层"字段缺失=启用"原则：启用不写en字段，禁用写`en="0"`。所以`askusrargname`查询时未返回en=启用。

**p2不trim**：与p1不同，p2保留前后空格。如不需要空格，客户端应在发送前自行trim。

## 接口格式

- **HTTP最小新增**: `GET http://<设备IP>/ctrl?token=<token>&cmd=setusrargname&p1=<参数名>`
- **HTTP完整设置**: `GET http://<设备IP>/ctrl?token=<token>&cmd=setusrargname&p1=<参数名>&p2=<值>&p3=<开关>`
- **HTTP仅改启用**: `...&cmd=setusrargname&p1=<参数名>&p3=disabled`
- **TCP**: `{"cmd":"setusrargname","p1":"<参数名>","p2":"<值>","p3":"<开关>","tid":"<ID>"}\x11\x12`（末尾必须附加2字节二进制结束符`0x11 0x12`）

## 响应

subType=80。保存成功返回type=402/code=0；参数格式错误返回type=401/code=101；Token错误返回type=401/code=100；写盘失败返回type=402/code=999。

成功：
```json
{"subType":80,"code":0,"val":"ok","note":"usrArg saved.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645914}
```

错误响应：
- 缺p1(code=101,type=401): `note="Missing required parameter: p1 (name)"`, val=""
- p1空(code=101,type=401): `note="p1 (name) must not be empty"`, val=""
- p3非法(code=101,type=401): `note="p3 invalid: must be 0/1/true/false/enabled/disabled/on/off (case insensitive)"`, **val=原始p3值**
- 写盘失败(code=999,type=402): `note="Failed to write config file!"`, val=""（设备回滚到旧文档，参数未被修改）
- Token错(code=100,type=401): `note="Invalid token."`, 无val

| 字段 | 类型 | 说明 |
|------|------|------|
| val | string | 成功=`"ok"`；p3非法=原始p3值；其他错误=空串 |

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | 保存成功（新增或更新） | 402 |
| 100 | Token错误 | 401 |
| 101 | 参数格式错误（缺p1 / p1空 / p3非法别名） | 401 |
| 999 | 配置写盘失败（文件系统异常/OOM兜底） | 402 |

## 备注

- upsert语义：调用方无需先查询是否存在，直接set即可
- 仅修改提供的字段：只想改值→只带p1+p2；只想改启用→只带p1+p3
- 配置立即写入Flash并生效，无需重启设备，重启后参数仍保留
- 每次只设置一个参数，不支持批量
- p3使用`enabled`/`disabled`比`1`/`0`更可读，效果相同
- 设置后用`askusrargname`验证已正确写入（注意code=999时设备已回滚，参数未被修改）
- 相关命令：askusrargname、getallusrargname、delusrargname
