# setaes - 设置通讯AES加密配置

统一设置设备与云端接口服务器之间的通讯AES加密配置，含三参数：Key(p1)、IV(p2)、加密模式(p3)。是原`setaeskey`/`setaesiv`/`setaesmode`的合并版。三参都可选，至少传一个；未传/留空/trim后空的参数保留原值。任一传入参数格式非法则**整个请求被拒绝**（原子操作，防止"mode改成加密但key没改"的不一致状态）。

**特殊点**：p3设为1/2时，系统会校验**最终的key和iv都已设置且有效**（含原值或新值），失败则**三个字段都不修改**并返回code=999（type=402，已进入执行阶段）。响应中key/iv永远返回掩码（非明文），出于安全设计防止明文密钥通过异步ack路径上报到云端。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `setaes` |
| token | string | HTTP必填 | 管理员Token；TCP接口无需token |
| p1 | string | 否 | AES Key。必须能解析为**恰好16字节**；未传/trim后空=保留原值。详见"AES Key/IV格式" |
| p2 | string | 否 | AES IV。规则同p1 |
| p3 | string | 否 | 加密模式：`0`=NO_AES不加密，`1`=UPLOAD_ONLY仅上行加密，`2`=BOTH双向加密；未传/trim后空=保留原值；其他值非法 |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

## 接口格式

- **HTTP**: `GET http://<设备IP>/ctrl?token=<token>&cmd=setaes&p1=<key>&p2=<iv>&p3=<0/1/2>`
- **TCP**: `{"cmd":"setaes","p1":"<key>","p2":"<iv>","p3":"<0/1/2>","tid":"<ID>"}\x11\x12`

> TCP消息末尾必须附加2字节二进制结束符`0x11 0x12`（非字符串）。

## AES Key/IV格式（p1/p2）

p1/p2字符串必须能解析为**恰好16字节**，否则返回code=101。常用格式：

| 格式 | 示例 |
|------|------|
| 16进制逗号分隔 | `0xaf,0xef,0x12,0x34,...,0xcb`（16个`0x??`项） |
| 16个ASCII字符 | `1234567890123456` |

失败note：`Invalid AES Key: must parse to 16 bytes (e.g. '0xaf,0xef,...' or 16 ASCII chars)`（p1失败，p2为Invalid AES IV）。

## 参数校验顺序

1. **至少一个参数**：p1/p2/p3都未传 → code=101/note=`At least one of p1/p2/p3 must be provided`
2. **格式校验**：p1/p2非空但无法解析为16字节 → code=101；p3非空且非`0/1/2` → code=101/note=`p3 must be 0, 1 or 2 (0=NO_AES, 1=UPLOAD_ONLY, 2=BOTH)`/val回显原入参
3. **安全校验**（合并保存阶段，type=402）：mode=1/2但最终key/iv未设置或无效 → code=999/note=`Failed to update aes config. Check: if mode=1/2, key and iv must be set and valid (16 bytes each).`，三字段都不修改
4. **写盘保存**：失败 → code=999

## 响应

subType=59。参数格式校验失败→type=401（code=101）；安全校验失败/写盘失败/执行成功→type=402（code=999或0）。Token错误返回type=401/code=100/note=`Invalid token.`。

成功（三参数都设置）：
```json
{"subType":59,"code":0,"val":"{\"key\":\"0xaf****f,0xcb\",\"iv\":\"0xb4****d6,0xe7\",\"mode\":2}","note":"aes config updated.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773646000}
```

成功（mode=0且key/iv未设置）：`val="{\"key\":\"not set\",\"iv\":\"not set\",\"mode\":0}"`

失败时val：缺参/格式错=`""`，p3非法=回显原入参；安全校验失败=`""`。

## val字段结构（成功响应，需二次JSON.parse）

| 字段 | 类型 | 说明 |
|------|------|------|
| key | string | 当前AES Key的**掩码**（非明文） |
| iv | string | 当前AES IV的**掩码**（非明文） |
| mode | number | 当前加密模式：0/1/2 |

**掩码规则**（基于原始字符串字符长度，非字节数）：

| 原始长度 | 掩码结果 | 示例 |
|----------|----------|------|
| 0（未设置） | `not set` | — |
| 1~8 | `****` | `1234`→`****` |
| >8 | 前4字符+`****`+后4字符 | `0xaf,...,0xcb`→`0xaf****f,0xcb` |

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | AES配置已更新并写盘 | 402 |
| 100 | Token错误 | 401 |
| 101 | 三参都缺；p1/p2无法解析为16字节；p3非0/1/2 | 401 |
| 999 | mode=1/2但key/iv未设置或无效；配置文件写盘失败 | 402 |

## 备注

- **首次启用加密的正确步骤**（强烈建议分两步避免code=999）：①`setaes&p1=<key>&p2=<iv>`设置key和iv；②`askaes`查询确认看到掩码；③`setaes&p3=1或2`切换到加密模式；④通知云端接口同步配置
- **key/iv无法取回**：响应永远返回掩码，丢失后只能重新设置
- HTTP方式明文传输AES Key/IV有风险，建议仅在内网使用，或改用TCP方式
- 切换加密模式后**云端必须同步支持**对应加解密，否则云端收不到设备消息
- HTTP URL传16进制key时逗号在query中合法，但为兼容性建议用TCP或16 ASCII字符格式
- mode=0时不校验key/iv，即使未设置也能成功
- 相关命令：askaes（查询当前配置，key/iv掩码）、setinf（接口配置，与加密配合使用）
