# pingintvl - 设置/查询心跳间隔

设置/查询设备推送心跳消息(类型998)的周期间隔。无p1=查询当前值，有p1=设置新值。设置后立即生效，无需重启。心跳消息(998)包含设备ID、计数器等基本信息。

## 心跳机制

| 接口模式 | 心跳推送 | 说明 |
|------|------|------|
| TCP长连接 | 强制必须 | 维持连接活跃，防被服务器断开 |
| HTTP短连接 | 可选 | 可通过配置禁止 |

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值`pingintvl` |
| token | string | HTTP必填 | 管理员Token，HTTP接口必填；TCP接口无需token |
| p1 | int | 否 | 心跳间隔秒数。范围5~600，默认110。省略=查询模式。必须纯数字，前后空格自动忽略，中间不含其他字符 |
| tid | string | 否 | 事务追踪ID，原样返回用于关联请求与响应 |

## 接口格式

- HTTP查询: `GET http://<ip>/ctrl?token=<token>&cmd=pingintvl`
- HTTP设置: `GET http://<ip>/ctrl?token=<token>&cmd=pingintvl&p1=<秒数>`
- TCP: `{"cmd":"pingintvl","p1":<秒数>,"tid":"<id>"}\x11\x12` (末尾附0x11 0x12结束符)

## 响应

公共字段: `subType`=14, `devId`=设备唯一ID, `netCh`=网络通道号, `msgTs`=Unix秒级时间戳。type含义: 401=处理中或处理前错误, 402=执行完成。

| 场景 | type | code | val | note |
|------|------|------|-----|------|
| 查询成功 | 402 | 0 | 当前值字符串 | `pingInterval value is:<值>` |
| 设置成功 | 402 | 0 | 新值字符串 | `pingInterval has been changed.` |
| 参数超范围 | 401 | 101 | `""` | `p1 must be between 5 ~ 600 seconds!` |
| 参数非数字 | 401 | 101 | `""` | `p1 (ping interval) must be a valid number` |
| 配置保存失败 | 402 | 999 | 设置值字符串 | `Failed to write config file!` 根因:文件系统异常，可尝试恢复出厂设置 |

## 推荐间隔

- TCP长连接: 30~120秒(保持连接活跃)
- HTTP短连接: 300~600秒或禁用(减少流量)
- 网络不稳定: 60~120秒(快速检测断线)
- 流量敏感: 300~600秒(节省流量)

> 间隔过小(如5秒)会增加网络流量和服务器负担，但能更快检测到网络问题。
