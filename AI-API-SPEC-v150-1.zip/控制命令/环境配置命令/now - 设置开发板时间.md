# now - 设置/查询开发板时间

设置或查询开发板时间、时区(p3)、自动校时规则(p2)。无参数=查询当前时间，有参数=设置。需**管理员Token**。设置立即生效无需重启，时区变化时自动保存配置。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | `now` |
| token | string | HTTP必填 | 管理员Token，HTTP接口必填；TCP接口无需token |
| p1 | string | 否 | 设置时间，支持14/10/13位格式，详见"p1时间格式" |
| p2 | int | 否 | 校时规则位掩码，0~15，默认15，详见"p2校时规则" |
| p3 | int | 否 | 时区，-12~14，默认8(北京时间)，仅整数，详见"p3时区" |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

**处理顺序**: p3(时区)→p2(校时规则)→p1(时间)

## 接口格式

- HTTP查询: `GET /ctrl?token=<t>&cmd=now`
- HTTP设置: `GET /ctrl?token=<t>&cmd=now[&p1=<time>][&p2=<n>][&p3=<tz>]`
- TCP查询: `{"cmd":"now","tid":"<id>"}\x11\x12`
- TCP设置: `{"cmd":"now","p1":"<time>","p2":<n>,"p3":<tz>,"tid":"<id>"}\x11\x12`

TCP消息末尾必须附2字节结束符 `0x11 0x12`。

## p1时间格式

自动去除分隔符(`-`、`:`、`/`、`,`、空格)后按长度识别:

| 长度 | 格式 | 示例 | 说明 |
|------|------|------|------|
| 14 | YYYYMMDDHHmmss | 20221015103005 | 本地时间，按时区(p3)转UTC存储 |
| 10 | Unix时间戳(秒) | 1665796800 | UTC，直接设置 |
| 13 | Unix时间戳(毫秒) | 1665796800000 | UTC，÷1000后设置 |

非14/10/13位返回code=101。14位格式视为本地时间，根据当前时区(p3或默认)转UTC存储，同时更新时区为当前使用的时区值；Unix时间戳直接为UTC，无时区转换。

## p2校时规则(位掩码)

| 位 | Hex | 说明 |
|----|-----|------|
| Bit0 | 0x01 | SIM卡/移动网络校时(当前支持) |
| Bit1 | 0x02 | WiFi NTP校时(预留) |
| Bit2~3 | 0x04/0x08 | 系统预留 |

常用值: 0=禁用所有, 1=仅SIM, 2=仅NTP(预留), 3=SIM+NTP, **15=全部(默认)**

**自动校时触发规则**:
- 仅在**未成功同步过时间**时触发
- 任意方式成功同步后，其他方式被跳过
- `now`命令手动设置**不受此限制**，始终可执行
- 时间已同步时改p2不会重新触发校时，需重启清除同步状态

## p3时区

- 范围-12~14，默认8(北京时间)
- 仅整数时区(不支持+5:30、+5:45等半小时/45分钟偏移)
- **仅值变化时**保存到配置文件
- 影响: 14位时间格式的本地→UTC转换、时间显示、日志时间戳、dailyrst定时重启、数据上报时间标记、SMS时间记录

## 响应

type: 401=处理中或处理前错误, 402=执行完成。subType固定**11**。

**查询成功(type=402)**:
```json
{"code":0,"val":"220420184724","note":"Display the current time.","subType":11,"devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645442}
```

**设置成功(type=402)**:
```json
{"code":0,"val":"","note":"The time zone has been set to 8. The time has been set to 20221015103005.","subType":11,"devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645600}
```

**参数错误(type=401)**:
```json
{"code":101,"val":"","note":"P1 must be yyyymmddhhmmss or a 10 or 13 digit timestamp.","subType":11,"type":401,"netCh":0,"msgTs":1773646208}
```

**配置保存失败(type=401)**:
```json
{"code":999,"val":"","note":"Failed to write config file!","subType":11,"type":401,"netCh":0,"msgTs":1773646210}
```

## 响应字段

| 字段 | 说明 |
|------|------|
| code | 结果码，见返回码表 |
| val | 查询: YYMMDDHHmmss(12位,2位年份); 设置: 空 |
| note | 结果描述或错误提示 |
| subType | 固定11 |
| devId | 设备唯一ID |
| type | 401=处理中/错误, 402=执行完成 |
| netCh | 网络通道号 |
| msgTs | 消息时间戳(Unix秒) |

## 返回码

| code | 含义 | note示例 |
|------|------|----------|
| 0 | 成功 | "Display the current time." / "The time zone has been set to {p3}. " / "The time calibration has been set to {p2}. " / "The time has been set to {p1}." |
| 100 | Token错误 | "Invalid token." |
| 101 | 参数错误 | "P1 must be yyyymmddhhmmss or a 10 or 13 digit timestamp." / "P2 must be between 0~15. " / "P3 must be between -12~14. " |
| 200 | 一般错误 | 设备内部处理错误 |
| 999 | 内部错误 | "Failed to write config file!" |

## 执行流程

1. 无参数 → 返回当前时间(val=YYMMDDHHmmss)
2. 有参数 → 按顺序: p3(时区)→p2(校时规则)→p1(时间)
3. 14位时间: 本地时间按时区转UTC存储；10/13位时间戳: 直接设UTC
4. 时区值变化时保存配置文件 → 返回结果
