# askamrurl - 查询通话录音上报接口地址

查询当前设备已设置的通话录音上报接口地址（即`telrecordupload`命令上传录音文件的目标URL）。`setamrurl`的查询配套命令。无业务参数。无失败路径（除Token错误），即使URL未设置也返回code=0+val为空字符串。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `askamrurl` |
| token | string | HTTP必填 | 管理员Token；TCP接口无需token |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

## 接口格式

- **HTTP**: `GET http://<设备IP>/ctrl?token=<token>&cmd=askamrurl`
- **TCP**: `{"cmd":"askamrurl","tid":"<ID>"}\x11\x12`（末尾必须附加2字节二进制结束符`0x11 0x12`）

## 响应

subType=56。查询成功返回type=402/code=0；Token错误返回type=401/code=100。无code=101路径（无业务参数），无code=999路径（不写Flash）。

成功（已设置URL）：
```json
{"subType":56,"code":0,"val":"https://api.example.com/voice/upload","note":"telRecUrl queried.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645914}
```

成功（未设置URL，val为空字符串）：
```json
{"subType":56,"code":0,"val":"","note":"telRecUrl queried.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645915}
```

Token错误(code=100)：`note="Invalid token."`, type=401, 无val字段。

| 字段 | 类型 | 说明 |
|------|------|------|
| val | string | 当前URL原始字符串，未设置时为空串`""`。URL中的`&`等特殊字符按JSON编码自动处理，不会带额外引号或转义 |
| note | string | 固定 `"telRecUrl queried."` |

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | 查询成功（val可能为空串） | 402 |
| 100 | Token错误 | 401 |

## 备注

- val=""表示从未设置或之前执行过`setamrurl p1=clear`，需用`setamrurl`设置
- 仅保存当前URL，每次`setamrurl`覆盖旧值，无历史记录
- 纯读取不消耗Flash写入次数，可频繁调用
- 上传录音前应先调用本命令预检URL，避免触发上传失败（消息696）
- 相关命令：setamrurl(设置/清除URL)、telrecordupload(触发上传到URL)
