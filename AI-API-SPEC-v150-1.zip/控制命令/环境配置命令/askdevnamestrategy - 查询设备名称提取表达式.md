# askdevnamestrategy - 查询设备名称提取表达式

查询设备当前的devName提取表达式（devNameStrategy），devNameStrategy决定设备如何从通信数据中提取设备名称devName。无业务参数，只读。修改用 `setdevnamestrategy`（修改后需重启生效）。若tokenStrategy引用devName，重启后token可能也会变。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `askdevnamestrategy` |
| token | string | HTTP必填 | 管理员Token；TCP接口无需token |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

## 接口格式

- **HTTP**: `GET http://<设备IP>/ctrl?token=<token>&cmd=askdevnamestrategy`
- **TCP**: `{"cmd":"askdevnamestrategy","tid":"<ID>"}\x11\x12`

## 响应

subType=68。查询成功返回type=402/code=0；Token错误返回type=401/code=100。

val为当前devName提取表达式字符串，**可能为空串**（表示未设置自定义表达式，使用设备默认devName提取方式）。note固定为 `"devNameStrategy queried."`。

```json
{"subType":68,"code":0,"val":"你的devName表达式内容","note":"devNameStrategy queried.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645914}
```

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | 查询成功 | 402 |
| 100 | Token错误 | 401 |

## 备注

- val为空串=未设置自定义表达式，使用默认devName提取方式（正常现象）
- setdevnamestrategy设置后用本命令二次查询可验证表达式已正确写入
- 与askdevidstrategy结构完全相同，区别仅在作用对象：本命令查询devName（设备名称），askdevidstrategy查询devId（设备唯一标识）
