# setamrurl - 设置通话录音上报接口地址

设置或清除通话录音文件的上报接口地址（即`telrecordupload`命令上传AMR文件的目标URL）。配置持久化保存到Flash，重启后仍有效；设置后立即生效，下次`telrecordupload`就用新URL。支持`http://`/`https://`/`smtp://`三种协议，**明确不支持`tcp://`**，**不支持多URL**。

**与setinf关键区别**：setamrurl支持`clear`关键字清空（也支持空串清空），但不支持`tcp://`和多URL；setinf支持`tcp://`和多URL，但不识别`clear`（清空必须用空串）。setamrurl作用于通话录音上报接口；setinf作用于主通信接口。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `setamrurl` |
| token | string | HTTP必填 | 管理员Token；TCP接口无需token |
| p1 | string | 是 | 目标URL。特殊值`clear`（忽略大小写）或trim后空串=清空；正常URL须满足校验规则 |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

## 接口格式

- **HTTP**: `GET http://<设备IP>/ctrl?token=<token>&cmd=setamrurl&p1=<URL或clear>`
- **TCP**: `{"cmd":"setamrurl","p1":"<URL或clear>","tid":"<ID>"}\x11\x12`

> TCP消息末尾必须附加2字节二进制结束符`0x11 0x12`（非字符串）。

## 参数校验顺序

1. **p1存在性**：p1未传 → code=101/note=`Missing required parameter: p1 (URL)`/val=`""`
2. **清除判断**：p1 trim后为空串**或**等于`clear`（忽略大小写，如`CLEAR`/`Clear`/`cLeAr`都识别）→ 清空URL
3. **URL格式校验**（非清除模式）：
   - 长度必须**严格>10**字符 → 失败：code=101
   - 前缀（忽略大小写）必须是`http://`/`https://`/`smtp://`之一 → 失败：code=101/note=`Invalid URL: must start with 'http://', 'https://' or 'smtp://' and length > 10. (tcp:// not supported)`/val回显原入参
4. **保存**：失败 → code=999/note=`Failed to write config file!`/val=回显新URL

## 响应

subType=55。参数错误→type=401（code=101）；成功或写盘失败→type=402（code=0或999）。Token错误返回type=401/code=100/note=`Invalid token.`。

设置成功：
```json
{"subType":55,"code":0,"val":"https://api.example.com/upload","note":"telRecUrl updated.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645914}
```

清除成功：val=`"cleared"`/note=`telRecUrl cleared.`

错误响应val：缺参=`""`；URL非法=回显原入参；保存失败=回显新URL。

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | 设置/清除成功 | 402 |
| 100 | Token错误 | 401 |
| 101 | 缺p1；URL长度≤10；前缀非http/https/smtp；使用了`tcp://` | 401 |
| 999 | 配置文件写盘失败 | 402 |

## 备注

- 不支持`ftp://`/`tcp://`：FTP需搭建HTTP网关代理接收后再转发
- 代码只硬性要求长度>10，但建议URL≤1500字符避免内存压力
- 特殊字符（空格/中文/`&`/`#`）建议URL编码，如空格→`%20`
- HTTPS证书校验能力有限，自签名证书可能上传失败，建议用主流CA证书
- 清除URL只影响后续上报，已存在的录音文件不删除，重新设置后仍可上传历史录音
- 上传录音失败（消息696）：URL已设但服务端不可达，需检查防火墙/证书
- 相关命令：askamrurl（查询当前URL）、telrecordupload（触发上传到setamrurl配置的URL）
