# setallmsgcode - 批量设置消息号上报开关

批量设置设备哪些消息号允许上报到云端/用户接口。设备共**31个标准消息号**，本命令精确控制allowTypes集合。支持两种操作模式：**REPLACE**（默认，增量调整）和**SET**（全量重写）。**任一token非法→整个请求被拒绝**（原子性）。

**两种模式核心区别**（最重要）：

| 维度 | REPLACE模式（默认） | SET模式（p3=1/set） |
|------|------|------|
| 触发 | p3缺失/`0`/`replace` | p3=`1`/`set` |
| 作用范围 | **仅影响**p1中消息号，其他保持原状 | p1按p2处理，其他**所有消息反向处理** |
| p2=on时 | 把p1的号**加入**allowTypes | allowTypes**=p1**（仅p1上报） |
| p2=off时 | 把p1的号**从**allowTypes移除 | allowTypes**=全集-p1**（p1外都上报） |

> 示例（初始allowTypes={100,101}，p1={501,601}）：REPLACE+on→{100,101,501,601}；REPLACE+off→{100,101}不变；SET+on→{501,601}；SET+off→全集-{501,601}。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `setallmsgcode` |
| token | string | HTTP必填 | 管理员Token；TCP接口无需token |
| p1 | string | 是 | 逗号分隔的消息号列表。每token须为31个标准消息号之一，详见"p1校验规则"和"31个标准消息号" |
| p2 | string | 是 | 开关值：`on`/`true`/`1`=启用，`off`/`false`/`0`=禁用（忽略大小写） |
| p3 | string | 否 | 操作模式：缺失/空/`0`/`replace`=REPLACE；`1`/`set`=SET；其他=非法 |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

## 接口格式

- **HTTP**: `GET http://<设备IP>/ctrl?token=<token>&cmd=setallmsgcode&p1=<code1,code2,...>&p2=<on/off>&p3=<0/replace/1/set>`
- **TCP**: `{"cmd":"setallmsgcode","p1":"<codes>","p2":"<switch>","p3":"<mode>","tid":"<ID>"}\x11\x12`

> TCP消息末尾必须附加2字节二进制结束符`0x11 0x12`（非字符串）。

## 参数校验顺序

1. **p1存在性**：p1未传 → code=101/note=`Missing required parameter: p1 (msgCode list)`
2. **p1非空**：p1 trim后为空 → code=101/note=`p1 must not be empty`
3. **p2存在性**：p2未传 → code=101/note=`Missing required parameter: p2`
4. **p2合法性**：非`on/off/true/false/1/0`（忽略大小写）→ code=101/note=`p2 must be 'on', 'off', 'true', 'false', '1' or '0'`/val回显原入参
5. **p3合法性**：非`缺失/空/0/replace/1/set`（忽略大小写）→ code=101/note=`p3 must be '0'/'replace' (replace mode) or '1'/'set' (set mode)`/val回显原入参
6. **p1逐token校验**：按逗号分割，每token做trim，任一非法→整体拒绝：
   - 非纯数字或带`+`/`-`前缀 → note=`Invalid token '<X>': must be a number (no +/- sign)`
   - 数值不在0~65535（uint16_t）范围 → note=`Token '<X>' out of uint16_t range`
   - 不在31个标准消息号中 → note=`Token '<X>' is not a valid message code in CLASS_SUB_TYPE_ALL`
   - 整体trim后无合法token → note=`p1 contains no valid msg codes`
7. **保存**：失败 → code=999/note=`Failed to write config file!`

## 31个标准消息号清单

p1中每个号必须取自下表，否则返回code=101：

| 号 | 常量 | 含义 | 号 | 常量 | 含义 |
|---|---|---|---|---|---|
| 100 | WIFI_CONNECTED | WiFi已连接 | 209 | SIM_ERR | SIM卡异常 |
| 101 | SIM1_CONNECTED | SIM1已连接 | 301 | SLOT_FAULTS | 卡槽故障 |
| 102 | SIM2_CONNECTED | SIM2已连接 | 401 | ACK_RECEIVED | 命令收到应答 |
| 201 | SIM_PUSH | SIM卡插/拔 | 402 | ACK_PROCESSED | 命令处理完成应答 |
| 202 | SIM_INIT | SIM初始化完成 | 501 | SMS_NEW | 新短信到达 |
| 203 | SIM_SIMIDS | ICCID/IMSI已读 | 502 | SMS_SEND_OK | 短信外发成功 |
| 204 | SIM_RDY | SIM卡就绪 | 503 | SMS_DELIVERY_REPORT | 短信外发送达报告 |
| 205 | SIM_POP | SIM卡移除事件 | 601 | TEL_IN_RING | 来电响铃 |
| 602 | TEL_IN_CONNECTED | 来电接通 | 642 | TEL_REMOTE_DTMF | 对端DTMF按键 |
| 603 | TEL_IN_END | 来电结束 | 683 | TELCTRL_PLAY_AMR_OK | AMR开始播放 |
| 620 | TEL_OUT_DIAL | 外拨响铃 | 685 | TELCTRL_PLAY_AMR_DONE | AMR播放完成 |
| 621 | TEL_OUT_RING | 外拨响铃 | 687 | TELCTRL_PLAY_TTS_OK | TTS开始播放 |
| 622 | TEL_OUT_CONNECTED | 外拨接通 | 689 | TELCTRL_PLAY_TTS_DONE | TTS播放完成 |
| 623 | TEL_OUT_END | 外拨结束 | 695 | TEL_RECORD_UPD_OK | 录音上报成功 |
| 641 | TEL_LOCAL_DTMF | 本端DTMF按键 | 696 | TEL_RECORD_UPD_FAILED | 录音上报失败 |
| 998 | PING | 心跳消息 | | | |

共**31个**。注意209(SIM_ERR)合法；500/103/1000等不在表中都拒绝。

## 响应

subType=57。参数错误→type=401（code=101）；成功或写盘失败→type=402（code=0或999）。Token错误返回type=401/code=100。

成功：`val`为受影响消息号数量（字符串形式，重复号自动去重后计数）。

REPLACE+启用2个：
```json
{"subType":57,"code":0,"val":"2","note":"Batch replace enabled 2 msg codes.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645914}
```

SET+禁用3个：note=`Batch set disabled 3 msg codes.`

note格式：`Batch <replace|set> <enabled|disabled> <N> msg codes.`（4段：模式+开/关+数量）

错误响应val：缺参/保存失败=`""`；p2/p3非法=回显原入参；token非法=回显p1原入参。

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | 批量设置成功 | 402 |
| 100 | Token错误 | 401 |
| 101 | 缺p1/p2；p2/p3非法；token非数字/带±/超uint16范围/非标准号；p1集合空 | 401 |
| 999 | 配置文件写盘失败 | 402 |

## 备注

- **恢复"全部启用"**：因p1不能为空，用`SET+p2=off+p1=任意一个号`让allowTypes=全集-{该号}，再REPLACE+on补回
- **全部禁用**：用`SET+p2=off+p1=全集31个号`，allowTypes=空（含心跳998都不上报，客户端将完全收不到设备消息，慎用）
- p1中token允许含空格（如`501, 601`），每token自动trim
- 重复号自动去重，val数量是去重后值
- 配置立即生效并持久化，无需重启
- p3默认REPLACE是为向后兼容（早期版本只支持增量操作）
- 设置成功但消息仍未上报：该消息当前未触发或服务端未订阅，用askallmsgcode确认allowTypes
- 误用SET模式会覆盖原配置丢失消息，建议修改前先`askallmsgcode`查询
- 相关命令：askallmsgcode（查询当前所有消息号上报开关）
