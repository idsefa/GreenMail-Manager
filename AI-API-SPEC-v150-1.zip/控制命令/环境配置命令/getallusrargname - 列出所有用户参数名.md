# getallusrargname - 列出所有用户参数名

列出设备当前保存的所有用户参数名（un字段），按ASCII字典序排序。仅返回参数名列表，不返回参数值。属于用户参数CRUD四命令之一（详见askusrargname）。无业务参数。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `getallusrargname` |
| token | string | HTTP必填 | 管理员Token；TCP接口无需token |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

## 接口格式

- **HTTP**: `GET http://<设备IP>/ctrl?token=<token>&cmd=getallusrargname`
- **TCP**: `{"cmd":"getallusrargname","tid":"<ID>"}\x11\x12`（末尾必须附加2字节二进制结束符`0x11 0x12`）

## 响应

subType=78。查询成功（含空列表）返回type=402/code=0；Token错误返回type=401/code=100；内部接口异常返回type=402/code=999（极罕见）。

成功（有参数）：
```json
{"subType":78,"code":0,"val":"[\"apn\",\"password\",\"server_url\"]","note":"3 usrArg names queried.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645914}
```

成功（无参数）：`val="[]"`, `note="0 usrArg names queried."`
内部异常(code=999,type=402): `val=""`, `note="g_userPub.infs invalid"`
Token错(code=100,type=401): `note="Invalid token."`, 无val

| 字段 | 类型 | 说明 |
|------|------|------|
| val | string | JSON数组字符串，元素为参数名（按un字典序排序）。无参数时`"[]"` |
| note | string | 格式`"N usrArg names queried."`（N=参数数量） |

## val字段结构

val为JSON数组字符串（需二次JSON.parse），如`["apn","password","server_url"]`。

- **排序**：按un的ASCII字典序（区分大小写，大写A-Z=65-90排在小写a-z=97-122之前，如`"Apple"`排在`"apple"`前），非"添加顺序"
- **包含禁用参数**：不区分en状态，返回所有un非空的参数（含en="0"）
- **转义规则**（参数名含特殊字符时）：先转义`\`→`\\`再转义`"`→`\"`，避免二次替换。如`my"key`→`"my\"key"`，`a\b\c`→`"a\\b\\c"`

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | 操作成功（可能为空列表） | 402 |
| 100 | Token错误 | 401 |
| 999 | 内部接口未就绪（极罕见，设备初始化异常） | 402 |

## 备注

- val是JSON数组字符串，需二次JSON.parse才能遍历，用标准JSON解析器不要手写正则
- 空列表`[]`也是成功（code=0），非错误
- code=999：等待设备启动完成（约10秒）后重试，持续报错尝试`restart`
- 受设备内存限制无硬编码上限，建议保持几十条以内（参数过多可能OOM）
- 标准流程：getallusrargname列名→askusrargname逐条查详情
- 永不暴露`us`字段（接口层透明保留的内部字段）
- 相关命令：askusrargname、setusrargname、delusrargname
