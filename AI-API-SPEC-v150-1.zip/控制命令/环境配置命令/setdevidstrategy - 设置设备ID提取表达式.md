# setdevidstrategy - 设置设备ID提取表达式

设置设备devId提取表达式（devIdStrategy），devId是设备唯一标识符，此表达式决定设备如何从通信数据中提取devId。

**关键设计**：
- **修改后需重启才生效**——保存成功后必须发送 `restart` 命令（devId策略在启动时加载计算）
- **若tokenStrategy引用了devId，重启后token也会变化**，修改前建议先用 `asktokenstrategy` 检查依赖关系并提前算好新token

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `setdevidstrategy` |
| token | string | HTTP必填 | 管理员Token；TCP接口无需token |
| p1 | string | 是 | devId提取表达式（非空、无换行） |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

**p1校验**：①非空（不能为空串）②无换行（不能含 `\n` 或 `\r`，防止破坏配置文件）。无硬性长度上限，建议简洁。

## 接口格式

- **HTTP**: `GET http://<设备IP>/ctrl?token=<token>&cmd=setdevidstrategy&p1=<表达式>`
- **TCP**: `{"cmd":"setdevidstrategy","p1":"<表达式>","tid":"<ID>"}\x11\x12`

## 响应

subType=65。设置成功返回type=402/code=0；参数错误返回type=401/code=101；Token错误返回type=401/code=100；配置保存失败返回type=402/code=999。

成功val固定为 `"ok"`（不是新表达式内容），note含重启和token变化警告。

成功：
```json
{"subType":65,"code":0,"val":"ok","note":"devIdStrategy saved, takes effect after reboot (send 'restart' cmd). WARNING: if tokenStrategy references devId, the token will also change after reboot!","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645914}
```

缺p1(code=101)：`note="p1 (devId strategy expression) is required"`
p1为空串(code=101)：`note="p1 must be non-empty"`
p1含换行(code=101,val回显原入参)：`note="p1 must not contain newline characters"`
保存失败(code=999)：val=`""`，note=`"Failed to write config file!"`

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | 设置成功（需重启生效） | 402 |
| 100 | Token错误 | 401 |
| 101 | 参数错误(缺p1；p1为空；p1含换行) | 401 |
| 999 | 配置写入失败（文件系统异常） | 402 |

## 备注

- 设置成功后必须发 `restart` 才能用新表达式重新提取devId
- 修改devId是否影响token取决于tokenStrategy是否引用devId；引用则重启后token变化需用新token
- val为 `"ok"` 不是表达式内容，查询表达式用 `askdevidstrategy`
- code=999：检查存储空间，重启后重试
- 设置成功但devId没变：未重启，发 `restart` 命令
- 重启后token失效：tokenStrategy引用了devId，用新devId重新计算token
