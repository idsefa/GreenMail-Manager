# chpwdadmin - 修改管理员密码

修改管理员密码。需管理员Token（最高权限）。须同时提供旧密码(p1)和新密码(p2)。修改后所有旧Token立即失效，需用新密码重新计算。默认密码`admin`（可通过factreset恢复出厂重置）。

## 参数

| 参数 | 必填 | 类型 | 说明 |
|------|------|------|------|
| token | 是(HTTP) | 字符 | 管理员Token，HTTP接口必填；TCP接口无需token |
| cmd | 是 | 字符 | `chpwdadmin` |
| p1 | 是 | 字符 | 当前管理员密码（旧密码），须与设备存储完全一致 |
| p2 | 是 | 字符 | 新管理员密码，4~64字符，建议含大小写+数字+特殊字符 |
| tid | 否 | 字符 | 事务追踪ID，响应中原样返回 |

## 格式

**HTTP**: `http://192.168.7.170/ctrl?token=3f4bffa77257d243875d0a5a80635934&cmd=chpwdadmin&p1=admin&p2=NewAdminPass123`

**TCP**: `{"cmd":"chpwdadmin","p1":"admin","p2":"NewPwd888","tid":"1704038400001"}\x11\x12`
（TCP末尾须附加2字节结束符`0x11 0x12`）

## 处理流程（按验证顺序）

1.（HTTP接口）Token无效 → code:100, note:"Invalid token."
2. 缺p1或p2 → code:101, note:"Missing required parameter(s): p1 (old password) or p2 (new password)."
3. p2长度<4 → code:200, note:"New password (p2) cannot be less than 4 characters."
4. p1旧密码错误 → code:200, note:"p1 is invalid password."
5. p1==p2 → code:200, note:"New password (p2) cannot be the same as old password (p1)."
6. 保存成功 → code:0, type:402, note:"Admin password has been changed."
7. 保存失败 → code:999, note:"Failed to write config file!"

## 响应码

| code | 常量 | 说明 |
|------|------|------|
| 0 | OK | 成功（type:402） |
| 100 | TOKEN_ERR | Token验证失败 |
| 101 | ARG_FMT_ERR | 缺p1或p2 |
| 200 | GENERAL_ERR | 密码验证失败/密码太短/新旧相同 |
| 999 | UNKNOWN_ERR | 配置文件保存失败 |

异步响应type：401=收到命令（处理中或错误）；402=执行完成（最终结果）。

## 与chpwduser对比

| | chpwdadmin | chpwduser |
|---|---|---|
| 修改对象 | 管理员密码 | 用户密码 |
| 需旧密码 | 是（验证身份） | 否（管理员直接重置） |
| 参数 | p1旧+p2新 | p1新 |
| 执行权限 | 管理员Token | 管理员Token |
