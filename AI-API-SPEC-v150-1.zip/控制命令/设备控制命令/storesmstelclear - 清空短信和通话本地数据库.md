# storesmstelclear

**不可逆**。清空本地短信/通话数据库所有记录文件，自动重建空数据库，成功后**5秒自动重启**。仅清本地数据，不影响SIM卡短信，不修改storesmstelen存储开关。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | `storesmstelclear` |
| p1 | string | 是 | `sms`=仅短信库、`tel`=仅通话库、`all`=同时清空两者。不区分大小写 |
| token | string | HTTP必填 | 管理员Token，HTTP接口必填；TCP接口无需token |
| tid | string | 否 | 事务追踪ID，响应原样返回 |

## 接口格式

- **HTTP**: `http://<ip>/ctrl?token=<token>&cmd=storesmstelclear&p1=<sms|tel|all>`
- **TCP**: `{"cmd":"storesmstelclear","p1":"sms","tid":"1234"}\x11\x12`（末尾0x11 0x12结束符）

## 响应

subType=54（Token错误时无此字段）。

**成功(type=402, code=0)**:
含全部字段(type,subType=54,code=0,val,note,devId,netCh,msgTs)。
- p1=sms: val=`sms:{N}`, note="SMS database cleared ({N} files), reboot after 5 seconds"
- p1=tel: val=`tel:{N}`, note="TEL database cleared ({N} files), reboot after 5 seconds"
- p1=all: val=`sms:{N};tel:{M}`, note含两者统计及reboot提示
- N或M=0时仍返回code=0（原库为空）

**参数错误(type=401, code=101)**:
含type,subType=54,code=101,val="",note,netCh,msgTs（无devId）。
- p1缺失: note="p1 is required. Valid values: sms, tel, all"
- p1无效: note="p1 must be 'sms', 'tel' or 'all'"

**Token错误(type=401, code=100)**:
仅含type,code,note。note="Invalid token."

## 响应字段

| 字段 | 类型 | 说明 |
|------|------|------|
| type | number | 401=处理中/错误；402=执行完成 |
| subType | number | 固定54（Token错误时无此字段） |
| code | number | 0=成功；100=Token无效；101=参数缺失或无效 |
| val | string | 成功时:`sms:{N}`/`tel:{N}`/`sms:{N};tel:{M}`。失败时空 |
| note | string | 英文描述，含文件数及重启提示 |
| devId | string | 设备标识（仅code=0时存在） |
| netCh | number | 网络通道（Token错误时无此字段） |
| msgTs | number | Unix时间戳（Token错误时无此字段） |

## 执行流程

1. 验证p1→缺失或无效返回code=101(type=401)
2. 按p1清空对应数据库，记录删除文件数
3. 重建空数据库
4. 返回code=0(type=402)，val含统计
5. 5秒后自动重启

## 命令对比

| | storesmstelclear | storesmstelen | factreset |
|--|-----------------|---------------|-----------|
| 功能 | 清空本地数据库 | 设置存储开关 | 恢复出厂设置 |
| 数据影响 | 删除指定数据库已有数据 | 不删除数据，仅控制新数据是否保存 | 删除所有配置和数据 |
| 自动重启 | 是(5秒后) | 否(需手动重启) | 是 |
| 可逆性 | 不可逆 | 可逆 | 不可逆 |
| 影响范围 | 仅短信和/或通话数据库 | 仅存储开关配置 | 全部数据和配置 |

## 注意事项

- 不可逆，清空前建议querysms/querytel确认
- 成功后5秒自动重启以重新初始化数据库，约5秒+启动时间后恢复查询
- 清空后自动重建，不影响storesmstelen开关状态
- 仅清本地库，不影响SIM卡短信
- 完全停止数据存储：先用storesmstelen关闭开关再清空；仅清历史数据继续存储：直接清空
- Token错误可通过管理页面重置

## 相关命令

- storesmstelen/storesmsen/storetelen：存储开关控制
- querysms/querytel：查询本地记录
- restart/factreset：重启/恢复出厂
