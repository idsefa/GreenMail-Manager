# askhttplog - 查询单条HTTP日志摘要

查询单条HTTP请求日志的**摘要信息**。payload截断到≤2048字节，url/resp原样返回（resp不超过255B）；字段内的 `|` 会被替换为 `` ` ``（反引号）。

**HTTP请求日志子系统**：设备发起HTTP请求 → 成功记入ok日志文件 / 失败记入err日志文件。相关命令：setreqlog(开关)、askreqlog(查询开关)、askhttplogcnt(统计条数)、askhttplog(本命令,查摘要)、clearhttplog(清空)。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `askhttplog` |
| token | string | HTTP必填 | 管理员Token；TCP接口无需token |
| p1 | string | 是 | 日志类型，取值 `ok` 或 `err`（忽略大小写） |
| p2 | number | 是 | 日志索引（非负整数），idx=0是最新 |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

**p2规则**：必须是纯非负整数字符串。允许"0"/"1"/"12"；拒绝"-1"(带负号)/"+5"(带正号)/"1.5"(小数)/"abc"(非数字)。

## 接口格式

- **HTTP**: `GET http://<设备IP>/ctrl?token=<token>&cmd=askhttplog&p1=<ok/err>&p2=<idx>`
- **TCP**: `{"cmd":"askhttplog","p1":"<ok/err>","p2":"<idx>","tid":"<ID>"}\x11\x12`

## 摘要格式

val字段为单行字符串，以 `|` 分隔7段：
```
yyyy-MM-dd HH:mm:ss|code|channel|method/conType|url|p:payload(≤2048)|r:resp
```

| 段 | 字段 | 说明 |
|---|---|---|
| 1 | 时间戳 | 设备本地时间，格式 `yyyy-MM-dd HH:mm:ss` |
| 2 | HTTP code | HTTP响应码(整数) |
| 3 | channel | 网络通道号 |
| 4 | method/conType | HTTP方法+内容类型，斜杠分隔，如 `GET/JSON` |
| 5 | url | 请求URL，原样返回(不截断) |
| 6 | p: | 请求payload，截断到≤2048字节 |
| 7 | r: | 响应正文，原样返回(不超过255B) |

示例：`2026-07-30 14:25:31|200|0|POST/JSON|http://api.example.com/upload|p:{"devId":"c3dd382801","ts":1773640}|r:{"code":0,"msg":"ok"}`

> payload截断到≤2048字节；url/resp原样返回。字段内的 `|` 会被替换为 `` ` ``（反引号）。idx是倒序索引（最新记录排在文件最前），idx=0永远最新。

## 响应

subType=74。命中返回type=402/code=0；索引越界返回type=402/code=200(非错误，是遍历终止信号)；参数错误返回type=401/code=101；Token错误返回type=401/code=100。

命中(code=0)：
```json
{"subType":74,"code":0,"val":"2026-07-30 14:25:31|200|0|POST/JSON|http://api.example.com/upload|p:{\"devId\":\"c3dd382801\",\"ts\":1773640}|r:{\"code\":0,\"msg\":\"ok\"}","note":"httpLog queried.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773640684}
```

越界(code=200)：
```json
{"subType":74,"code":200,"val":"","note":"no such log entry","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773640684}
```

缺参(code=101)：`note="p1 (ok/err) and p2 (idx) are both required"`
p1类型错(code=101,val回显原入参)：`note="p1 must be ok or err"`
p2带符号(code=101,val回显原入参)：`note="p2 must be a non-negative integer (no sign allowed)"`
Token错(code=100)：`note="Invalid token."`

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | 命中 | 402 |
| 100 | Token错误 | 401 |
| 101 | 参数错误(缺p1/p2;p1非ok/err;p2非非负整数) | 401 |
| 200 | 索引越界(idx>实际记录数-1) | 402 |

## 备注

- code=200是正常的"无对应记录"响应，非系统错误，遍历时应立即停止增加idx
- 字段名固定用 `err` 不用 `failed`（与askhttplogcnt返回的JSON字段名保持一致）
- 摘要时间戳为设备本地时间(受now命令和时区影响)，需UTC结合stat的devTz换算
- payload截断到≤2048字节；url/resp原样返回（resp不超过255B）
- 设备已自动把url/payload/resp中的 `|` 替换为 `` ` ``（反引号），解析时按 `|` 分隔恰好7段
- 遍历全部日志：先用askhttplogcnt获取总数N，遍历范围[0,N-1]
- 排查故障先查 `p1=err&p2=0`（最新失败请求）
- 总是返回code=200时：日志未开启或已清空，先用askreqlog查开关
