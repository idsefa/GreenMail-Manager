# askhttplogcnt - 查询HTTP日志条数

查询设备HTTP请求日志中ok日志和err日志各自的记录条数。无需业务参数。

**HTTP请求日志子系统**：设备发起HTTP请求 → 成功记入ok日志文件 / 失败记入err日志文件。相关命令：setreqlog(开关)、askreqlog(查询开关)、askhttplogcnt(本命令,统计条数)、askhttplog(查摘要)、clearhttplog(清空)。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `askhttplogcnt` |
| token | string | HTTP必填 | 管理员Token；TCP接口无需token |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

## 接口格式

- **HTTP**: `GET http://<设备IP>/ctrl?token=<token>&cmd=askhttplogcnt`
- **TCP**: `{"cmd":"askhttplogcnt","tid":"<ID>"}\x11\x12`

## 响应

subType=73。查询成功返回type=402/code=0；Token错误返回type=401/code=100。命令只读无副作用，即使日志文件不存在也返回0而非错误。

成功：`val`为JSON字符串 `{"ok":N,"err":N}`（需二次JSON.parse），note固定为 `"httpLog count queried."`

```json
{"subType":73,"code":0,"val":"{\"ok\":12,\"err\":3}","note":"httpLog count queried.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773640684}
```

| val字段 | 类型 | 说明 |
|---------|------|------|
| ok | 整数 | ok日志(成功请求日志)条数，≥0 |
| err | 整数 | err日志(失败请求日志)条数，≥0 |

> JSON字段名是 `err` 不是 `failed`，固定用 `err`。

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | 查询成功(无论条数多少) | 402 |
| 100 | Token错误 | 401 |

## 备注

- 计数原理：扫描日志文件统计条数，文件不存在或为空返回0
- 日志开关关闭后条数仍可能非零：①关闭前已有日志文件未删除(仅在开关1→0时自动删除) ②查询的是上次打开期间积累的日志，可用clearhttplog手动清空
- 日志条数受本地存储空间限制，文件过大时按内部策略循环覆盖旧记录
- 用途：翻阅日志前先查条数作为askhttplog遍历上界；err数量持续增长说明HTTP上报通道有问题
- 配合askhttplog：先获取n_ok/n_err，再从idx=0开始遍历
