# setreqlog - 设置HTTP请求日志开关

分别打开/关闭设备HTTP请求日志的两个独立开关位：ok日志（成功请求）和err日志（失败请求）。**两参必填**，不接受单独缺省。

**HTTP请求日志子系统**：设备发起HTTP请求 → 成功记入ok日志文件 / 失败记入err日志文件。本命令是子系统"总闸"。相关命令：askreqlog(查询)、askhttplogcnt(统计条数)、askhttplog(查摘要)、clearhttplog(清空)。

## 关键设计行为

- **1→0删文件副作用**：某开关从 `1`(开)变为 `0`(关)且保存成功时，设备自动删除对应的日志文件。再次设置 `0`（已为0）不会删文件。note会附加 `(ok log file removed)` 或 `(err log file removed)`。
- **两次独立保存非原子**：ok开关与err开关是两次独立保存操作。部分成功（仅一方save成功）时返回 code=999，val和note如实反映哪个已生效、哪个失败；已生效的开关位持续生效（重启后保留）。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `setreqlog` |
| token | string | HTTP必填 | 管理员Token；TCP接口无需token |
| p1 | string | 是 | ok日志开关，取值 `"0"`(关) 或 `"1"`(开) |
| p2 | string | 是 | err日志开关，取值 `"0"`(关) 或 `"1"`(开) |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

**校验**：p1/p2仅接受字符串 `"0"` 或 `"1"`，其他值（如 `"true"`/`"on"`/`2`）返回code=101。

## 接口格式

- **HTTP**: `GET http://<设备IP>/ctrl?token=<token>&cmd=setreqlog&p1=<0/1>&p2=<0/1>`
- **TCP**: `{"cmd":"setreqlog","p1":"<0/1>","p2":"<0/1>","tid":"<ID>"}\x11\x12`

## 响应

subType=71。完全成功返回type=402/code=0；部分成功或全部失败返回type=402/code=999；参数错误返回type=401/code=101；Token错误返回type=401/code=100。

val为逗号分隔字符串 `"<okEn>,<errEn>"`，部分成功时反映真实生效状态（已生效方=新值，未生效方=旧值）；全部失败时val为空串。note会明确说明副作用和保存结果。

完全成功（无副作用）：
```json
{"subType":71,"code":0,"val":"1,0","note":"reqLog updated.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773640684}
```

完全成功（两开关都1→0，删两文件）：`val="0,0"`，note=`"(ok log file removed) (err log file removed)"`

部分成功（ok开关已生效err保存失败，且含删文件副作用）：`code=999`，`val="0,1"`(ok=新值0已生效，err=旧值1未生效)，`note="ok switch saved, but err switch save failed! (ok log file removed)"`

全部失败：`code=999`，`val=""`，`note="Failed to write config file!"`

缺参(code=101)：`note="p1 (ok switch) and p2 (err switch) are both required"`
p1非法(code=101,val="2")：`note="p1 must be 0 or 1"`
Token错(code=100)：`note="Invalid token."`

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | 完全成功（两次save均成功） | 402 |
| 100 | Token错误 | 401 |
| 101 | 参数错误(缺p1/p2；非"0"/"1") | 401 |
| 999 | 部分成功或全部失败（本地存储写入失败） | 402 |

## 备注

- **code=999不一定是彻底失败**，必须读note区分：note含 `Failed to write config file!`=全部失败可重试（建议先释放存储）；note含 `switch saved, but ... save failed!`=部分成功不要直接重试，应用askreqlog确认状态
- 部分成功后val反映已生效方新值+未生效方旧值，可用askreqlog二次确认真实状态
- 设置前必查askreqlog：避免误触发1→0删文件副作用；只想修改一个开关时把另一个原样传入（必填）
- 删文件副作用不可关闭，是设计行为；想保留旧日志请先askhttplog抓取备份再关开关
- 设置立即生效，写入Flash重启后仍有效
- ok日志=记录HTTP成功请求摘要，err日志=记录HTTP失败请求摘要
- code=999排查：①stat查内存 ②clearhttplog all清空日志释放空间 ③重启后重试
- 生产环境建议关err日志节省存储或定期clearhttplog all；调试环境ok和err都打开配合askhttplog排查
- ok日志(成功)=响应码正常的HTTP请求；err日志(失败)=连接失败/超时/HTTP错误码等
