# storesmstelen - 设置/查询短信和通话存储开关

组合命令=同时执行storesmsen+storetelen。设置或查询各卡槽短信存储和通话记录存储开关（两者状态相同）。**设置后须restart重启才生效**。如需短信/通话状态不同，须分别用storesmsen和storetelen。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | `storesmstelen` |
| p1 | number | 否 | 卡槽号：`0`=所有、`1`=卡槽1、`2`=卡槽2。省略→查询模式 |
| p2 | string | 否 | 开关（同时用于短信和通话）：`on`/`1`/`true`=开、`off`/`0`/`false`=关。省略→查询模式 |
| token | string | HTTP必填 | 管理员Token，HTTP接口必填；TCP接口无需token |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

> p1和p2须同时提供或同时省略。仅提供其中一个→自动进入查询模式。

## 接口格式

- HTTP查询: `GET /ctrl?token=<t>&cmd=storesmstelen`
- HTTP设置: `GET /ctrl?token=<t>&cmd=storesmstelen&p1=<slot>&p2=<switch>`
- TCP: `{"cmd":"storesmstelen","p1":1,"p2":"on","tid":"1234"}\x11\x12`（末尾附加0x11 0x12）

## 响应

subType固定=34。type: 401=已收到(处理中或前置错误如Token无效/参数格式错误)；402=执行完成并返回结果。

### 响应码

| code | 含义 | 触发条件 |
|------|------|----------|
| 0 | 成功 | 查询返回当前状态；设置成功，提示需重启 |
| 100 | Token错误 | token无效或已过期 |
| 101 | 参数格式错误 | p1非0/1/2，或p2非on/off/true/false/1/0 |
| 999 | 配置保存失败 | 文件写入失败（存储空间不足或文件系统错误） |

### 响应示例

查询(code=0, type=402):
```json
{"type":402,"subType":34,"code":0,"val":"1s:on,1t:on;2s:off,2t:off","note":"Slot 1 SMS storage ON, TEL storage ON; Slot 2 SMS storage OFF, TEL storage OFF","devId":"c3dd382801","netCh":0,"msgTs":1773644058}
```

设置单卡槽(code=0, type=402):
```json
{"type":402,"subType":34,"code":0,"val":"1:on","note":"Slot 1 SMS/TEL storage has been changed, restart required.","devId":"c3dd382801","netCh":0,"msgTs":1773644075}
```

设置全部卡槽(code=0, type=402):
```json
{"type":402,"subType":34,"code":0,"val":"1:on;2:on","note":"All slot SMS/TEL storage has been changed, restart required.","devId":"c3dd382801","netCh":0,"msgTs":1773644085}
```

参数错误(type=401):
```json
{"type":401,"subType":34,"code":101,"val":"","note":"p1 (slotId) must be 0, 1 or 2; p2 must be 'on' or 'off'","netCh":0,"msgTs":1773644134}
```

Token错误(type=401):
```json
{"type":401,"code":100,"note":"Invalid token."}
```

保存失败(type=402):
```json
{"type":402,"subType":34,"code":999,"val":"","note":"Failed to write config file!","devId":"c3dd382801","netCh":0,"msgTs":1773644200}
```

### val字段格式

**查询模式**: `{卡槽}s:{状态},{卡槽}t:{状态}` — 同一卡槽`,`分隔，不同卡槽`;`分隔
- `s`=SMS短信存储, `t`=TEL通话存储
- 示例: `1s:on,1t:on;2s:off,2t:off` = 卡槽1短信开+通话开；卡槽2短信关+通话关

**设置模式**: `{卡槽}:{状态}` — 不同卡槽`;`分隔（不含s/t标识，因两者状态相同）
- 示例: `1:on;2:on`

### 响应字段

| 字段 | 类型 | 说明 |
|------|------|------|
| type | number | 401=处理中或前置错误；402=执行完成 |
| subType | number | 固定34 |
| code | number | 返回码(见上) |
| val | string | 状态值(格式见上) |
| note | string | 结果描述(英文) |
| devId | string | 设备标识 |
| netCh | number | 网络通道 |
| msgTs | number | Unix时间戳 |

## 处理流程

1. p1和p2都存在→设置模式；任一缺失→查询模式
2. **查询**: 返回各卡槽短信(s)和通话(t)状态(code=0,type=402)
3. **设置**:
   - 校验参数：p1非0/1/2或p2无效→code=101(type=401)
   - 同时修改短信和通话配置(p1=0时设置全部卡槽)
   - 保存文件：失败→code=999；成功→code=0，提示需重启
   - **须restart重启设备新配置才生效**

## 注意

- 设备2个卡槽
- 短信库上限100条，通话记录上限50条，超出覆盖最旧
- 关闭存储：新记录不保存，已保存的不受影响
- 参数缺失(查询,code=0) ≠ 参数格式错误(code=101)
- 相关：storesmsen(单独短信)、storetelen(单独通话)、querysms、querytel、restart
