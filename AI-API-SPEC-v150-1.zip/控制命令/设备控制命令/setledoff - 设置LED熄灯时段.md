# setledoff - 设置LED熄灯时段

设置设备LED熄灯时段。时段内设备状态指示灯熄灭不亮。配置持久化保存（写入Flash），立即生效，重启后仍有效。修改查询用 `askledoff`。

**时间语义**：起始时间>结束时间（如 `2230-0700`）为跨午夜时段（当晚起始持续到次日结束）；起始时间≤结束时间（如 `0900-1800`）为当天内时段。取消熄灯功能设起始=结束（如 `0000-0000`）。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `setledoff` |
| token | string | HTTP必填 | 管理员Token；TCP接口无需token |
| p1 | string | 是 | 起始时间HHMM（4位纯数字） |
| p2 | string | 是 | 结束时间HHMM（4位纯数字） |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

## 接口格式

- **HTTP**: `GET http://<设备IP>/ctrl?token=<token>&cmd=setledoff&p1=<起始HHMM>&p2=<结束HHMM>`
- **TCP**: `{"cmd":"setledoff","p1":"<起始HHMM>","p2":"<结束HHMM>","tid":"<ID>"}\x11\x12`

## HHMM校验规则

| 校验 | 规则 | 失败note |
|------|------|---------|
| 两参齐全 | p1和p2都存在 | `p1 (start HHMM) and p2 (end HHMM) are both required` |
| 4位纯数字 | p1/p2各为4位数字（必须补零，如7点=`0700`非`700`） | `p1/p2 must be 4-digit HHMM strings`（val=`"p1,p2"`回显原入参） |
| 范围合法 | HH∈00~23，MM∈00~59 | `Invalid HHMM range (HH<=23, MM<=59)`（val=`"p1,p2"`回显原入参） |

| HHMM值 | 合法 | 原因 |
|--------|:----:|------|
| `2230`/`0700`/`0000`/`2359` | 是 | 在范围内 |
| `2400` | 否 | HH>23 |
| `1260` | 否 | MM>59 |
| `123` | 否 | 非4位 |
| `12:30` | 否 | 含非数字字符 |

## 响应

subType=69。设置成功返回type=402/code=0；参数错误返回type=401/code=101；Token错误返回type=401/code=100；配置保存失败返回type=402/code=999。

成功val为 `"起始HHMM-结束HHMM"`，note固定为 `"ledOff updated."`。

成功：
```json
{"subType":69,"code":0,"val":"2230-0700","note":"ledOff updated.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645914}
```

保存失败(code=999)：val=`""`，note=`"Failed to write config file!"`

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | 设置成功（已写入Flash，立即生效） | 402 |
| 100 | Token错误 | 401 |
| 101 | 参数错误(缺p1/p2；非4位数字；HH>23或MM>59) | 401 |
| 999 | 配置写入失败（文件系统异常） | 402 |

## 备注

- HHMM必须补零为4位，如7点5分写 `0705`
- 配置立即生效无需重启，重启后仍有效
- 设置成功但LED仍亮：时段未覆盖当前时间，用stat查看devTime确认设备时间正确
- code=999：检查存储空间，重启后重试
- 设置后用 `askledoff` 验证已正确保存
