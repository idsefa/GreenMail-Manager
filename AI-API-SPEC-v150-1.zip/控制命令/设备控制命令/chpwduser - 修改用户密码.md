# chpwduser - 修改用户密码

管理员直接重置用户密码（无需验证旧密码，因管理员具有重置权限，属"密码重置"场景）。用户密码用于生成用户级Token，修改后旧Token立即失效，需用新密码重新获取Token。用户无法自行修改密码，只能由管理员通过此命令操作。必须使用管理员Token（用户Token无权执行）。妥善保管新密码，避免泄露。

## 执行逻辑

1.（HTTP接口）验证Token → 无效：code=100
2. 检查p1 → 缺失：code=101
3. p1长度<4字节 → code=200
4. 保存新密码 → 成功：code=0,type=402 | 失败：code=999

## 参数

| 参数 | 必填 | 说明 |
| --- | --- | --- |
| token | 是(HTTP) | 管理员Token，HTTP接口必填；TCP接口无需token |
| cmd | 是 | `chpwduser` |
| p1 | 是 | 新用户密码，≥4字节（多字节字符按字节计数），无上限，建议含大小写字母、数字、特殊字符 |
| tid | 否 | 事务追踪ID，响应中原样返回，用于关联请求与响应 |

## 接口格式

- HTTP: `http://<ip>/ctrl?token=<adminToken>&cmd=chpwduser&p1=<新密码>`
- TCP: `{"cmd":"chpwduser","p1":"<新密码>","tid":"<tid>"}\x11\x12`（末尾附0x11 0x12结束符）

## 响应

异步机制：type=401（命令处理中或处理前错误），type=402（执行完成最终结果）

| code | type | 触发条件 | note |
| --- | --- | --- | --- |
| 0 | 402 | 密码修改成功 | User password has been changed. |
| 100 | 401 | Token无效或已过期 | Invalid token. |
| 101 | 401 | 缺少必填参数p1 | Missing required parameter: p1 (new password) |
| 200 | 401 | p1长度<4字节 | New password cannot be less than 4 characters. |
| 999 | 402 | 配置文件保存失败 | Failed to write config file! |

## 与chpwdadmin对比

| 特性 | chpwdadmin | chpwduser |
| --- | --- | --- |
| 修改对象 | 管理员密码 | 用户密码 |
| 需要旧密码 | 是（p1旧密码验证身份） | 否（管理员直接重置） |
| 参数 | p1=旧密码, p2=新密码 | p1=新密码 |
| 新旧不能相同 | 是 | 不适用 |
| 执行权限 | 管理员Token | 管理员Token |
