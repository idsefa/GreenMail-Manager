## soundposend - 停止寻音定位

与 soundposstart 配套，关闭寻音定位，立即停止声光提示。

### 停止机制：取消1秒循环定时器 → 白色LED恢复正常 → 停止蜂鸣器

### 命令格式

**HTTP：** `GET /ctrl?token=<管理员Token>&cmd=soundposend`

**TCP：** `{"cmd":"soundposend","tid":"<可选，原样返回>"}\x11\x12`（末尾2字节0x11 0x12）

### 参数
| 参数 | 类型 | 说明 |
|------|------|------|
| token | 字符型 | 管理员Token（仅HTTP） |
| cmd | 字符型 | 固定值 `soundposend` |
| tid | 字符型 | 可选。事务追踪ID，携带时响应中原样返回 |

### 响应（异步：401=已收到/处理前错误，402=执行完成返回结果）

**成功(402)：**
```json
{"subType":42,"code":0,"val":"","note":"Sound Positioning deactivated.","devId":"<设备ID>","type":402,"netCh":0,"msgTs":<Unix时间戳>}
```

**失败(401，token无效)：**
```json
{"type":401,"code":100,"note":"Invalid token."}
```

**响应字段：** type(401=接收/错误,402=执行完成), subType(42=停止寻音定位响应), code(0=成功,100=token无效), note(结果描述), devId(设备ID), val(扩展值,通常为空), netCh(网络通道), msgTs(Unix时间戳)

### 行为特性
- 未开启寻音定位时调用安全返回code:0，不报错
- 设备重启后寻音定位自动关闭，无需手动执行soundposend；如需继续寻音定位需重新发送soundposstart
- 支持远程执行（WiFi/移动网络）
- 寻音定位运行时每秒消耗CPU和电池电量，应找到设备后立即关闭
- 网络不可用时可物理重启设备停止寻音定位
- 状态不持久化（重启后默认关闭）

### 故障排查
- 命令发出后仍在运行：检查网络连接、token是否正确、返回code是否为0
- 无法远程关闭：确认设备网络/IP正确，尝试其他网络接口，或物理重启设备
