# stat - 获取开发板当前状态

查询设备全部运行状态：设备信息、WiFi状态、卡槽状态、系统时间。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `stat` |
| token | string | HTTP必填 | 管理员Token，HTTP接口必填；TCP接口无需token |
| tid | string | 否 | 事务追踪ID，携带时原样返回，用于关联请求与响应 |

## 接口格式

- **HTTP**: `http://<ip>/ctrl?token=<token>&cmd=stat`
- **TCP**: `{"cmd":"stat","tid":"1234"}\x11\x12`（末尾附0x11 0x12结束符）

## 响应机制

subType固定46。stat正常返回type=402（type含义见字段表）。

## 响应示例

**成功(type=402)**:
```json
{"type":402,"subType":46,"code":0,"devId":"c3dd382801","hwVer":"X31v126","netCh":0,"dailyRst":4,"pingIntvl":110,"ackMax":8000,"msgTs":1773643845,"wifi":{"mode":"ON","ssid":"lzwifi","ip":"192.168.5.254","dbm":99,"txMode":1,"txdbm":5},"simNet":[true,false],"usrPLMN":["","46001"],"slotInfo":{"slot1_sta":"OK","slot2_sta":"NS","sim1_dbm":"99","sim1_plmn":"46011","sim1_iccId":"89861121045720357738","sim1_imsi":"460110221127196","sim1_msIsdn":"18164522178","sim1_scName":"湖州电信","sim2_dbm":"0","sim2_plmn":"0"},"devTime":"260316145045","devTz":8,"uptime":623,"mem":72}
```

**失败(type=401)**:
```json
{"type":401,"code":101,"note":"Invalid arguments."}
```

## 响应字段

### 基本信息字段

| 字段 | 类型 | 说明 |
|------|------|------|
| type | number | 401=处理中或处理前错误；402=执行完成 |
| subType | number | 固定值46 |
| code | number | 0=成功，其他=失败 |
| devId | string | 设备唯一ID，十六进制字符串（源自MAC地址，长度可变） |
| hwVer | string | 固件版本号 |
| netCh | number | 推送通道。0=WiFi，1=SIM卡1，2=SIM卡2 |
| dailyRst | number | 每日重启时间（小时）。有效值0~23；25=关闭 |
| pingIntvl | number | 心跳周期（秒）。默认110，范围5~600 |
| ackMax | number | 应答超时（毫秒）。默认8000，范围1000~65535 |
| msgTs | number | 消息Unix秒级时间戳。用途：时效性判断、延迟排查、日志追溯 |

### WiFi状态（wifi对象）

| 字段 | 类型 | 说明 |
|------|------|------|
| mode | string | `ON`=已连接，`OFF`=已关闭，`AP`=AP热点 |
| ssid | string | WiFi名称（URL编码）。未连接时为空串 |
| ip | string | IP地址。未连接时为"0.0.0.0" |
| dbm | number | 信号强度百分比，0~99，越高越好。未连接时为0 |
| txMode | number | 发射功率模式。0=手动，1=自动。**仅WiFi已连接时返回** |
| txdbm | number | 发射功率百分比，0~99。**仅WiFi已连接时返回** |

### 卡槽联网配置（simNet数组）

| 字段 | 类型 | 说明 |
|------|------|------|
| simNet | bool[] | 各卡槽联网开关。true=允许，false=不允许。索引0=卡槽1，1=卡槽2 |

### 用户指定PLMN（usrPLMN数组）

| 字段 | 类型 | 说明 |
|------|------|------|
| usrPLMN | string[] | 各卡槽手动指定PLMN代码。空串=未指定（自动选择）。**仅至少一个卡槽设置了PLMN时返回** |

### 卡槽状态（slotInfo对象）

| 字段 | 类型 | 说明 |
|------|------|------|
| slot[1\|2]_sta | string | 卡槽状态，见下方状态表 |
| sim[1\|2]_dbm | string | SIM信号强度百分比，0~100，越高越好 |
| sim[1\|2]_plmn | string | 注册的运营商PLMN代码 |
| sim[1\|2]_iccId | string | SIM卡ICCID（20位） |
| sim[1\|2]_imsi | string | SIM卡IMSI（15位） |
| sim[1\|2]_msIsdn | string | 电话号码 |
| sim[1\|2]_scName | string | 运营商名称 |

> SIM详细信息（dbm、plmn、iccId、imsi、msIsdn、scName）仅在卡槽状态为OK或NS时返回。

### 时间和系统字段

| 字段 | 类型 | 说明 |
|------|------|------|
| devTime | string | 设备时间，YYMMDDHHmmss（如260316145045=2026-03-16 14:50:45） |
| devTz | number | 时区，-12~+14（东八区=+8） |
| uptime | number | 开机时长（分钟） |
| mem | number | 剩余内存百分比（当前剩余/开机最大可用×100），0~100。持续下降可能内存泄漏；<20建议重启 |

## 卡槽状态值（slot[1|2]_sta）

流转：POWOFF→(开机/插卡)POWON→NOSIM/NS；NS→OK/PIN/LT；任意→POWOFF(关机)。POWON为内部过渡态，不在响应中返回。

| 值 | 说明 |
|----|------|
| POWOFF | 关机。主动关闭或未启动 |
| NOSIM | 未检测到SIM卡。未插入或接触不良 |
| NS | 搜网中。过渡状态，通常数秒至数十秒变OK/其他。持续NS：查欠费/信号/用slotrst重启卡槽 |
| PIN | 需PIN/PUK码解锁 |
| LT | 限制服务。欠费/SIM锁定/区域限制等 |
| OK | 正常工作，已注册网络 |

## 常见PLMN代码

| PLMN | 运营商 | 制式 |
|------|--------|------|
| 46000/46002/46007 | 中国移动 | GSM/TD-SCDMA/TDD-LTE |
| 46001/46006/46009 | 中国联通 | GSM/WCDMA/FDD-LTE |
| 46003/46005/46011 | 中国电信 | CDMA/FDD-LTE |
