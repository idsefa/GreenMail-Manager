# clearhttplog - 清空HTTP日志

直接删除（不是清空内容）设备本地HTTP请求日志文件。可选清空ok日志、err日志，或两者全部。文件在下一次有新日志时自动重建。**幂等**：文件不存在也返回code=0。**操作不可恢复**，无回收站。

**HTTP请求日志子系统**：设备发起HTTP请求 → 成功记入ok日志文件 / 失败记入err日志文件。相关命令：setreqlog(开关)、askreqlog(查询开关)、askhttplogcnt(统计条数)、askhttplog(查摘要)、clearhttplog(本命令,清空)。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `clearhttplog` |
| token | string | HTTP必填 | 管理员Token；TCP接口无需token |
| p1 | string | 是 | 清空范围，取值 `ok`/`err`/`all`（忽略大小写） |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

**p1取值**：`ok`=删ok日志文件；`err`=删err日志文件；`all`=同时删两个文件。字段名固定为 `err`（不是 `failed`）。大小写混合如 `OK`/`Ok`/`ALL` 均接受。

## 接口格式

- **HTTP**: `GET http://<设备IP>/ctrl?token=<token>&cmd=clearhttplog&p1=<ok/err/all>`
- **TCP**: `{"cmd":"clearhttplog","p1":"<ok/err/all>","tid":"<ID>"}\x11\x12`

## 响应

subType=75。清空成功返回type=402/code=0（幂等，文件不存在也算成功）；参数错误返回type=401/code=101；Token错误返回type=401/code=100。**不会返回200/999**。

成功val固定为 `"ok"`，note格式 `"<scope> httpLog cleared."`（scope ∈ {ok,err,all}，回显实际p1）。

成功(all)：
```json
{"subType":75,"code":0,"val":"ok","note":"all httpLog cleared.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773640684}
```

缺p1(code=101)：`note="p1 is required (ok/err/all)"`
p1非法(code=101,val="failed")：`note="p1 must be ok/err/all"`（传 `failed` 会被拒绝，须用 `err`）
Token错(code=100)：`note="Invalid token."`

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | 清空成功(文件已删或本就不存在) | 402 |
| 100 | Token错误 | 401 |
| 101 | 参数错误(缺p1 或 p1∉{ok,err,all}) | 401 |

## 备注

- **与setreqlog区别**：clearhttplog 仅删文件不影响开关位（下次新请求仍记录）；setreqlog 1→0 关开关并副作用删文件且之后不再记录。仅想清旧记录继续记新日志用clearhttplog；想停止记录用setreqlog
- `p1=all` 时先删ok再删err，**非原子**：若第一个成功第二个失败（极少见）返回code=0（取最后一次结果），建议清空后用askhttplogcnt验证
- 不能按时间段选择性清空，只能整体删整个文件
- 删除是物理操作无回收站，重要日志请先用askhttplog抓取备份
- 清空后文件不会立即重建，需新HTTP请求且对应开关为开时才会创建并写入
- 清空后askhttplogcnt仍非零：期间产生新日志，检查askreqlog开关是否仍开
- 清空后存储空间未释放：本地存储延迟回收，重启触发文件系统整理
- 建议生产环境定期执行 `clearhttplog all` 释放存储；排查err问题时可仅清ok保留err：`clearhttplog p1=ok`
