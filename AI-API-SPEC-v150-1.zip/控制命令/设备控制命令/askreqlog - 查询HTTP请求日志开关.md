# askreqlog - 查询HTTP请求日志开关

查询设备HTTP请求日志两个开关位状态：ok日志开关与err日志开关。无副作用，可频繁调用。是 `setreqlog` 的配套查询命令，共用subType范围（71/72），共同管理HTTP日志子系统开关位。

**HTTP请求日志子系统**：设备发起HTTP请求 → 成功记入ok日志文件 / 失败记入err日志文件。相关命令：setreqlog(开关)、askreqlog(本命令,查询开关)、askhttplogcnt(统计条数)、askhttplog(查摘要)、clearhttplog(清空)。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `askreqlog` |
| token | string | HTTP必填 | 管理员Token；TCP接口无需token |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

## 接口格式

- **HTTP**: `GET http://<设备IP>/ctrl?token=<token>&cmd=askreqlog`
- **TCP**: `{"cmd":"askreqlog","tid":"<ID>"}\x11\x12`

## 响应

subType=72。查询成功返回type=402/code=0；Token错误返回type=401/code=100。除Token错误外不会返回101/200/999。

val为逗号分隔的开关位字符串 `"<okEn>,<errEn>"`（顺序固定：前ok后err；`1`=开，`0`=关），note固定为 `"reqLog queried."`。

```json
{"subType":72,"code":0,"val":"1,0","note":"reqLog queried.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773640684}
```

| val值 | ok开关 | err开关 | 含义 |
|-------|:------:|:------:|------|
| `1,1` | 1 | 1 | 都记录 |
| `1,0` | 1 | 0 | 仅记录成功请求 |
| `0,1` | 0 | 1 | 仅记录失败请求 |
| `0,0` | 0 | 0 | 完全关闭HTTP日志 |

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | 查询成功 | 402 |
| 100 | Token错误 | 401 |

## 备注

- val解析必须按逗号分割：首字段为ok开关，次字段为err开关（顺序固定）
- 仅读内存两个布尔值并拼接，无磁盘IO
- 执行 `setreqlog` 前必查：避免误触发1→0删文件副作用
- setreqlog返回code=999(部分成功)后用本命令二次确认真实状态；val反映的是内存中真实开关位状态（已生效方=新值，未生效方=旧值）
- TCP接口无响应：检查消息末尾是否附加 `\x11\x12` 二进制结束符
