# askledoff - 查询LED熄灯时段

查询设备当前LED熄灯时段。熄灯时段内设备状态指示灯熄灭不亮。修改需用 `setledoff` 命令。无副作用，只读。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `askledoff` |
| token | string | HTTP必填 | 管理员Token；TCP接口无需token |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

## 接口格式

- **HTTP**: `GET http://<设备IP>/ctrl?token=<token>&cmd=askledoff`
- **TCP**: `{"cmd":"askledoff","tid":"<ID>"}\x11\x12`

## 响应

subType=70。查询成功返回type=402/code=0；Token错误返回type=401/code=100。

val为熄灯时段字符串，固定格式 `起始HHMM-结束HHMM`（9字符，无冒号无空格，如 `2230-0700`）。`0000-0000` 表示未设置有效时段，此时LED始终按正常状态显示。

```json
{"subType":70,"code":0,"val":"2230-0700","note":"ledOff queried.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645914}
```

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | 查询成功 | 402 |
| 100 | Token错误 | 401 |

## 备注

- 本接口val格式固定为 `HHMM-HHMM`（无冒号），不复用设备内部 `HH:MM - HH:MM` 显示格式；需带冒号显示请客户端自行转换
- val=`0000-0000` 时表示未设有效时段，LED始终按正常状态显示，需开熄灯用 `setledoff`
- 设置后用本命令二次查询可验证配置已正确保存
