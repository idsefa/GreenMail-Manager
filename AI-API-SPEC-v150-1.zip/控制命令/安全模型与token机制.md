## 安全模型与token机制

### 权限体系

二层权限：管理员、用户。三种接口验证方式：

| 接口 | 验证方式 | 权限范围 |
| ---- | ---- | ---- |
| HTTP控制命令 | 仅管理员token | 所有命令 |
| TCP控制命令 | 无需token | 所有命令 |
| 短信命令 | 管理员密码 或 用户密码 | pm99命令仅限管理员 |
| 后台WEB页面 | 仅管理员密码登录 | 配置系统参数 |

### 权限对比

| 功能 | 管理员 | 用户(短信) | 说明 |
| ---- | :--: | :--: | ---- |
| 登录后台WEB | Y | N | 仅管理员可进入设备管理后台 |
| 配置用户接口(TCP/HTTP) | Y | N | 设置与平台通信的接口参数 |
| 配置运行参数 | Y | N | 心跳间隔、每日重启时间等 |
| 修改管理员密码 | Y | N | 需验证旧密码 |
| 修改用户密码 | Y | N | 管理员可直接重置 |
| 恢复出厂设置 | Y | N | 重置所有配置、密码和token |
| 发送HTTP控制命令 | Y | N | 需管理员token |
| 发送TCP控制命令 | Y | Y | 无需token |
| 发送短信命令 | Y | Y | 使用对应密码验证 |
| 查询设备状态 | Y | Y | stat命令 |
| 管理WiFi热点 | Y | Y | addwf/delwf |
| 重启设备/卡槽 | Y | Y | restart/slotrst |
| 发送短信 | Y | Y | sendsms |
| 拨打电话 | Y | Y | teldial等通话命令 |
| OTA升级 | Y | Y | otanow |

### 账户信息

| 类型 | 用户名 | 默认密码 | 用途 |
| ---- | ------ | -------- | ---- |
| 管理员 | admin（固定） | admin | 后台登录、HTTP命令token计算 |
| 用户 | 无（仅密码） | 000000 | 仅短信命令验证，不适用于HTTP/TCP |

### token机制

HTTP控制命令必须携带管理员token，设备收到后先验证token，验证通过后才执行命令。TCP控制命令无需携带token，设备收到命令后立即执行。当前仅支持管理员token，不支持用户token。

**计算公式：**
```
token = MD5("admin|" + 密码).toLowerCase()
```
- 用户名和密码间用竖线`|`分隔（非斜杠或其他符号）
- 默认密码"admin"对应token：`3f4bffa77257d243875d0a5a80635934`

**获取方式：**
1. 后台WEB"密码管理"页面直接查看
2. 自行计算：拼接`admin|密码` → MD5哈希 → 转32位小写16进制

**代码示例：**

```python
# Python
import hashlib
def calc_admin_token(password):
    return hashlib.md5(f"admin|{password}".encode()).hexdigest()
# calc_admin_token("admin") → "3f4bffa77257d243875d0a5a80635934"
```

```javascript
// JavaScript/Node.js
const crypto = require('crypto');
function calcAdminToken(password) {
    return crypto.createHash('md5').update(`admin|${password}`).digest('hex');
}
```

```java
// Java
import java.security.MessageDigest;
public class TokenUtil {
    public static String calcAdminToken(String password) throws Exception {
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] digest = md.digest(("admin|" + password).getBytes());
        StringBuilder sb = new StringBuilder();
        for (byte b : digest) sb.append(String.format("%02x", b));
        return sb.toString();
    }
}
```

### 密码与token注意事项

**密码修改影响：**
| 场景 | 影响 | 处理方式 |
| ---- | ---- | ---- |
| 修改管理员密码 | token立即变化 | 重新计算或从后台获取新token |
| 修改用户密码 | 仅影响短信命令验证 | 不影响HTTP/TCP控制命令（HTTP仅影响token，TCP无token） |
| 恢复出厂设置 | 所有密码重置为默认 | 使用默认密码计算token |

**密码要求：**
- 最小长度≥4字符（管理员和用户相同）
- 建议≥8字符，包含字母、数字、特殊字符
- token有效期：永久有效，直到密码被修改

**安全建议：** 使用强密码（≥8位，含字母/数字/特殊字符，★★★）、定期更换（每3个月，★★）、避免硬编码token（★★★）、区分开发/测试/生产环境token（★★）、生产环境用HTTPS传输（★★★）

### 错误码

| code | 说明 | 解决方案 |
| :--: | ---- | ---- |
| 100 | token无效 | 检查token拼写、确认密码未修改、重新计算token |
| 101 | 参数格式错误 | 检查命令参数格式 |
| 200 | 一般性错误 | 查看返回的note字段了解详情 |

错误响应示例：`{"code":100, "note":"Invalid token."}`

### 常见问题

- **管理员token与用户密码区别**：管理员token用于HTTP控制命令验证；TCP控制命令无需token验证；用户密码仅用于短信命令验证
- **HTTP控制命令只支持管理员token**：HTTP接口通过管理员token验证身份；TCP接口无需token，收到命令后立即执行；需区分用户权限用短信命令
- **忘记管理员密码**：能登录WEB则直接修改；否则需串口或恢复出厂设置（清除所有配置）
- **计算token与后台不一致**：检查是否用`|`分隔、用户名为小写`admin`、MD5结果转小写16进制
- **验证token正确性**：`curl "http://设备IP/ctrl?token=TOKEN&cmd=ping"`，返回`{"code":0}`则正确
- **token泄露处理**：立即修改管理员密码，旧token自动失效
- **判断是否默认密码**：用默认密码算token测试，成功则为默认密码，建议尽快修改

### 故障排除

| 现象 | 可能原因 | 排查步骤 |
| ---- | ---- | ---- |
| 后台无法登录 | 密码错误或被修改 | 尝试默认密码admin/admin |
| token每次都变 | 密码策略自动变化 | 检查是否有自动改密机制 |
| 短信命令失败 | 用户密码错误 | 确认短信中的密码 |
| 密码修改失败 | 新密码太短 | 确保新密码≥4字符 |
