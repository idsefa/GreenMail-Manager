# askwfstore - 查询已保存的WiFi网络（别名: `askwifistore`）

查询开发板已保存的WiFi网络配置列表。最多20组用户添加的WiFi。

## 命令格式

**HTTP**: `GET http://<设备IP>/ctrl?token=<Token>&cmd=askwfstore`
**TCP**: `{"cmd":"askwfstore","tid":"<事务ID>"}\x11\x12`（末尾须附加`\x11\x12`）

## 参数

| 参数 | 必填 | 说明 |
|------|------|------|
| token | 是(HTTP) | 管理员Token，HTTP接口必填；TCP接口无需token |
| cmd | 是 | `askwfstore` 或别名 `askwifistore` |
| tid | 否 | 事务追踪ID，响应中原样返回 |

## 约束

- 最多20组用户添加的WiFi（不含工厂预设）；SSID自动转小写存储
- 密码脱敏：≤4位完整显示；>4位保留前2+后2位，中间`*`替换
- 工厂预设热点"Lzwifi"始终出现在结果中
- 列表按SSID字典序排列；满20个时最早添加的自动删除（当前连接除外）

## 返回码

| code | 含义 | type |
|------|------|------|
| 0 | 成功，返回WiFi列表（可空） | 402 |
| 100 | Token无效或过期 | 401 |

## 响应格式

成功: `{"subType":40, "code":0, "val":"<JSON数组字符串>", "note":"WIFI store queried.", "devId":"<设备ID>", "type":402, "netCh":0, "msgTs":<Unix时间戳>}`

- val有WiFi: `"[{\"ssid\":\"mywifi\",\"pwd\":\"ab**cd\"}]"`  无WiFi: `"[]"`
- Token错误: `{"type":401, "code":100, "note":"Invalid token."}`

## 响应字段

| 字段 | 说明 |
|------|------|
| subType | 40=WIFI_STORE |
| code | 返回码 |
| val | JSON数组**字符串**（需JSON.parse），含WiFi信息 |
| note | 操作结果描述 |
| devId | 设备唯一标识 |
| type | 401=处理前错误, 402=执行完成 |
| netCh | 网络通道标识 |
| msgTs | Unix时间戳 |

## val解析后结构

| 字段 | 类型 | 说明 |
|------|------|------|
| ssid | 字符串 | WiFi名称，已转小写 |
| pwd | 字符串 | 脱敏密码（≤4位完整；>4位保留前2+后2，中间`*`） |

脱敏示例: `1234`→`1234` | `12345`→`12*45` | `abcdefgh`→`ab****gh` | `mypassword123`→`my*********23`
