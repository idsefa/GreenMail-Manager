# delwf - 删除WiFi热点信息（别名: delwifi）

从开发板删除已保存的WiFi热点信息。

## 格式

**HTTP**: `GET /ctrl?token=<Token>&cmd=delwf&p1=<SSID>`

**TCP**: `{"cmd":"delwf","p1":"<SSID>","tid":"<事务ID>"}\x11\x12`（末尾须附加2字节结束符`\x11\x12`）

## 参数

| 参数 | 必填 | 说明 |
|------|------|------|
| token | 是(HTTP) | 管理员Token，HTTP接口必填；TCP接口无需token |
| cmd | 是 | `delwf` 或别名 `delwifi` |
| p1 | 是 | 要删除的WiFi SSID，自动转小写匹配。含下划线等特殊字符可正常删除 |
| tid | 否 | 事务追踪ID，响应中原样返回 |

## 约束

- 最多存储20组WiFi，仅支持2.4GHz，不支持5GHz
- 工厂预设热点"Lzwifi"无法删除
- 删除立即生效，无需重启
- 设备根据信号强度自动选择最佳已保存热点连接

## 处理流程

1. p1空/缺失 → code:101
2. p1转小写 → 查找热点
3. 不存在 → code:0（视为已删除）
4. 存在 → 删除配置 → 保存文件
5. 保存失败 → code:200
6. 保存成功 → code:0
7. 若删的是当前连接 → 断开 → 扫描其他已保存热点 → 连接信号最好者；无可用则未连接

## 返回码

| code | 含义 | 触发条件 |
|------|------|----------|
| 0 | 成功 | 热点已删除或不存在 |
| 100 | Token错误 | Token无效或过期 |
| 101 | 参数错误 | p1为空或未提供 |
| 200 | 通用错误 | 配置文件写入失败 |

## 响应

type: 401=命令处理中或处理前错误, 402=命令执行完成。subType=7。

**标准格式**（code:0/200 val为SSID; code:101 val为空）:
```json
{"subType":7,"code":<code>,"val":"<SSID>|","note":"<描述>","devId":"<设备ID>","type":401|402,"netCh":0,"msgTs":<Unix时间戳>}
```
- code:0 note="WIFI hotspot '\<名称\>' has been deleted." type=402 val=SSID
- code:101(p1缺失) note="Missing required parameter: p1 (WiFi name)" type=401 val=""
- code:101(p1为空) note="p1 (WiFi name) must not be empty" type=401 val=""
- code:200 note="Failed to write config file!" type=402 val=SSID

**Token错误**(仅含3字段):
```json
{"type":401,"code":100,"note":"Invalid token."}
```

## 附注

- 建议先用askwfstore确认WiFi名称后再删除，使用askwfstore返回的准确名称；保留至少一个备用WiFi
- 定期清理不再使用的WiFi热点，保持配置整洁
- 删除所有WiFi导致断网时，用addwf添加新WiFi恢复联网；删除后也可用addwf重新添加已删WiFi
- code:200时检查设备存储空间或重启后重试
