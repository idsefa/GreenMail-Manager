# wf - 控制/查询WiFi状态（别名: `wifi`）

## 命令格式

**HTTP**: `GET http://<设备IP>/ctrl?token=<Token>&cmd=wf[&p1=<模式>]`
**TCP**: `{"cmd":"wf","p1":"<模式>","tid":"<事务ID>"}\x11\x12`（末尾须附加结束符`\x11\x12`）

## 参数

| 参数 | 必填 | 说明 |
|------|------|------|
| token | 是(HTTP) | 管理员Token，HTTP接口必填；TCP接口无需token |
| cmd | 是 | `wf` 或别名 `wifi` |
| p1 | 否 | `on`\|`off`\|`ap`，不区分大小写；省略=查询 |
| tid | 否 | 事务追踪ID，响应中原样返回 |

## 处理逻辑

### 查询模式（无p1）
- ON已连接 → val含SSID, IP, 信号强度(dbm: RSSI→百分比0-100%，值越高信号越好)
- ON未连接+有配置热点 → 最近连接的热点名称
- ON未连接+无配置热点 → "No hotspot is configured"
- OFF → "WIFI is OFF"
- AP → "WIFI is AP"
- 正在连接中查询可能返回空SSID，建议等待后重试

### p1=on
- 已ON+有配置热点 → "already ON"
- 已ON+无配置热点 → "already ON,but no hotspot is configured"
- 非ON → 开启WiFi(STA客户端模式)，连接到已配置的热点

### p1=ap
- 已AP → "already AP"
- 非AP → 切换AP模式

### p1=off
- 已OFF → "already OFF"
- 非OFF → 检查是否允许关闭（见保护机制）

### p1值非法 → code:101

### 关闭WiFi保护机制
以下任一条件成立即拒绝关闭(code:200)：
1. 访问来源为内网地址（如192.168.x.x）— 直接拒绝，不检查TCP/HTTP/卡槽
2. 外网+未配置TCP服务器且非HTTP模式
3. 外网+已配置TCP服务器+无卡槽允许联网
4. 外网+HTTP模式+无卡槽允许联网

允许关闭: 外网+(已配置TCP或HTTP模式)+至少一个卡槽允许联网

**关闭延迟**: 成功响应后延迟5秒再真正关闭WiFi硬件（期间设备仍可接收和响应其他命令）

**通信模式影响**: TCP模式→WiFi关闭后可自动切换到蜂窝网络，推荐此模式操作；HTTP模式→WiFi关闭后设备立即断网（可通过短信恢复）

**短信不受限**: 短信命令走蜂窝网络，不受上述保护机制限制

## 返回码

| code | 含义 | 触发条件 | note |
|------|------|----------|------|
| 0 | 成功 | - | (各场景不同) |
| 100 | Token错误 | Token无效或过期 | "Invalid token." |
| 101 | 参数错误 | p1非on/off/ap | "p1 must be 'on', 'off' or 'ap'" |
| 200 | 操作不允许 | WiFi是唯一有效联网通道 | "The only valid networking channel, it is not allowed to close." |

## 响应字段

| 字段 | 类型 | 说明 |
|------|------|------|
| type | number | 401=处理中或处理前错误；402=执行完成 |
| subType | number | 固定值28 |
| code | number | 返回码，见上表 |
| val | string | 查询模式返回状态信息；控制模式通常为空 |
| note | string | 结果描述 |
| devId | string | 设备唯一ID |
| netCh | number | 网络通道（0=主通道） |
| msgTs | number | Unix时间戳 |
| tid | string | 可选，请求中携带时原样返回 |

## 响应格式

**查询**（note均为`"WIFI status queried."`）:
- 已连接: `val:"WIFI is ON, connected to <SSID>, IP:<IP>, dbm:<%>"`
- 未配置热点: `val:"WIFI is ON, No hotspot is configured."`
- ON未连接+有配置热点(正在连接): `val:"WIFI is ON, The recently connected hotspot is <SSID>"`（连接中SSID可能为空，等待后重试）
- OFF: `val:"WIFI is OFF"`
- AP: `val:"WIFI is AP"`

**控制成功**:
- 开启: `note:"WIFI has been turned ON"`
- 关闭: `note:"WIFI has been turned OFF."`
- AP: `note:"WIFI has been turned AP"`

**已是目标状态**:
- 已ON: `note:"WIFI is already ON"`
- 已ON无热点: `note:"WIFI is already ON,but no hotspot is configured."`
- 已OFF: `note:"WIFI is already OFF"`
- 已AP: `note:"WIFI is already AP"`

## WiFi模式

| 模式 | 说明 | 场景 |
|------|------|------|
| ON(STA) | 客户端模式，连接指定WiFi热点。状态: 扫描→连接→已连接⇄断开重连 | 正常联网 |
| OFF | WiFi关闭 | 节能、仅用蜂窝网络 |
| AP | 热点模式，SSID=设备ID，无密码，自动启动Web服务器，默认IP:`192.168.4.1`。状态: 创建热点→等待连接→设备已连接 | 初始配置、Web管理 |

状态转换: ON↔OFF, ON↔AP, OFF↔AP

## 持久化

所有模式变更(on/off/ap)自动保存，重启恢复为保存的状态。

## LED

WiFi LED指示灯反映当前WiFi状态：

| WiFi状态 | LED表现 | 说明 |
|----------|---------|------|
| OFF | 灯灭 | WiFi已关闭 |
| ON + 扫描中 | 蓝灯闪烁 | 正在搜索WiFi热点 |
| ON + 连接中 | 绿灯闪烁 | 正在连接WiFi热点或建立TCP连接 |
| ON + 已连接 | 绿灯常亮 | WiFi已正常连接，TCP通信正常 |
| AP | 橙色常亮 | AP热点模式，其他设备可连接本设备热点 |

> AP模式下可通过 http://192.168.4.1/ap 访问WiFi管理器页面配置WiFi热点。

## 恢复方式

关WiFi后重开:
- 短信: `*#wf#000000#on` 到设备
- LED屏幕第2屏: 长按Sel进入设置，短按Ok切换WiFi状态为ON，长按Sel退出
- 恢复出厂设置

AP模式恢复:
- LED屏幕第2屏 (同上操作)
- Web: 连接AP热点后访问 http://192.168.4.1/ap WiFi管理器，添加可用WiFi热点后保存重启
- 短信: `*#wf#000000#on`

未配置热点: 使用`addwf`命令添加

## 示例

**HTTP查询WiFi状态**:
- 请求: `GET http://<设备IP>/ctrl?token=<Token>&cmd=wf`
- 响应: `{code:0, val:"WIFI is ON, connected to MyWiFi, IP:192.168.7.170, dbm:85%", note:"WIFI status queried."}`

**TCP关闭WiFi**（展示tid原样返回）:
- 发送: `{"cmd":"wf","p1":"off","tid":"1234"}\x11\x12`
- 响应: `{code:0, tid:"1234", note:"WIFI has been turned OFF."}`

**被拒绝关闭**:
- 响应: `{code:200, note:"The only valid networking channel, it is not allowed to close."}`
