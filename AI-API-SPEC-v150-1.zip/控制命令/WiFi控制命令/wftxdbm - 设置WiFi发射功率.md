# wftxdbm - 设置/查询WiFi发射功率

别名：`wifitxdbm`。设置或查询WiFi发射功率模式和数值。无p1→查询模式；有p1→设置模式。设置立即生效，配置持久化（code=999时重启后丢失）。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | `wftxdbm` 或别名 `wifitxdbm` |
| token | string | HTTP必填 | 管理员Token，HTTP接口必填；TCP接口无需token |
| p1 | number | 否 | 功率模式：`1`=自动（默认）、`0`=手动。省略→查询模式 |
| p2 | number | 条件 | 发射功率百分比（0~99）。p1=0时必填；p1=1时忽略 |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

## 接口格式

- **HTTP查询**: `GET /ctrl?token=<token>&cmd=wftxdbm`
- **HTTP设置自动**: `GET /ctrl?token=<token>&cmd=wftxdbm&p1=1`
- **HTTP设置手动**: `GET /ctrl?token=<token>&cmd=wftxdbm&p1=0&p2=<0-99>`
- **TCP**: `{"cmd":"wftxdbm","p1":<模式>,"p2":<功率>,"tid":"<id>"}\x11\x12`（末尾附加0x11 0x12）

## 功率模式

| 模式 | p1 | 说明 |
|------|-----|------|
| 自动 | 1 | 默认。根据RSSI自动调整功率。首次调整：连接AP后3秒；定期检查：每30秒 |
| 手动 | 0 | 用户指定固定功率(0-99)，需同时提供p2 |

## 功率百分比参考

| 范围 | 场景 | 说明 |
|------|------|------|
| 0-5 | 超近距离 | 同房间<3米 |
| 6-15 | 近距离 | 信号极佳 |
| 16-30 | 近-中距离 | 隔1-2堵墙 |
| 31-50 | 中等距离 | 隔2-3堵墙 |
| 51-75 | 较远距离 | 信号弱 |
| 76-99 | 最大功率 | 信号很弱/远距离 |

## 响应

**查询成功-自动(type=402)**:
```json
{"subType":29,"code":0,"val":"1,75","note":"auto mode. val is 75%","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645911}
```

**查询成功-手动(type=402)**:
```json
{"subType":29,"code":0,"val":"0,50","note":"user mode. val is 50%","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645911}
```

> 自动模式查询返回当前实际功率（动态变化）；手动模式返回用户设置的固定值。

**设置成功-自动(type=402)**:
```json
{"subType":29,"code":0,"val":"1,75","note":"wifi tx mode/dbm has been changed.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645927}
```
> 自动模式设置响应中的功率值为**设置前保存的手动模式值**（若提供了p2则为p2值）。设备实际发射功率会立即从最大功率开始，随后根据信号强度自动调整。当前实际功率需通过查询命令获取。

**设置成功-手动(type=402)**:
```json
{"subType":29,"code":0,"val":"0,50","note":"wifi tx mode/dbm has been changed.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645938}
```

**参数格式错误(type=401, code=101)**:
```json
{"subType":29,"code":101,"val":"","note":"p1 must be 0(user) or 1(auto), p2 must be 0-99","devId":"c3dd382801","type":401,"netCh":0,"msgTs":1773645956}
```

**p1值无效(type=401, code=101)**:
```json
{"subType":29,"code":101,"val":"","note":"p1 must be 0(user) or 1(auto)","devId":"c3dd382801","type":401,"netCh":0,"msgTs":1773645955}
```
> p1传入有效数字但非0或1（如p1=2），且p2合法时，返回此错误。

**p2超出范围(type=401, code=101)**:
```json
{"subType":29,"code":101,"val":"","note":"p2 must be a percentage (0-99)","devId":"c3dd382801","type":401,"netCh":0,"msgTs":1773645953}
```

**配置保存失败(type=402, code=999)**:
```json
{"subType":29,"code":999,"val":"0,100","note":"Failed to write config file! Settings will be lost after reboot.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1773645970}
```

**Token错误(type=401, code=100)**:
```json
{"type":401, "code":100, "note":"Invalid token."}
```
> Token验证在命令解析之前执行（仅HTTP接口），因此不包含subType、devId、netCh、msgTs等字段。TCP接口不进行token验证。

## 响应字段

| 字段 | 类型 | 说明 |
|------|------|------|
| type | number | 401=处理中或处理前错误；402=执行完成 |
| subType | number | 固定值29 |
| code | number | 返回码，见下表 |
| val | string | 格式：`"模式,功率值"`。模式：1=自动、0=手动；功率：0-99 |
| note | string | 结果描述 |
| devId | string | 设备唯一ID |
| netCh | number | 网络通道（0=主通道） |
| msgTs | number | Unix时间戳 |

## 返回码

| code | 含义 | note内容 | 说明 |
|------|------|----------|------|
| 0 | 成功 | 查询：`auto/user mode. val is XX%`；设置：`wifi tx mode/dbm has been changed.` | 查询返回当前值，设置返回新模式和功率 |
| 101 | 参数错误 | `p1 must be 0(user) or 1(auto), p2 must be 0-99` / `p1 must be 0(user) or 1(auto)` / `p2 must be a percentage (0-99)` | p1非0/1，或p2非0-99 |
| 999 | 配置保存失败 | `Failed to write config file! Settings will be lost after reboot.` | 值有效但写入存储失败，重启后丢失 |

## 注意事项

- 设置立即生效，配置自动保存；重启后设置丢失→检查设置时返回码是否为0
- 断线重连：自动模式从最大功率重新调整；手动模式恢复用户设置值
- code=999→配置保存失败，重启后丢失，检查存储空间
- 手动模式(p1=0)未提供p2→code=101；p2超出0-99→code=101
- 实际功率采用向下取整策略，可能低于设置百分比（不符→切换自动模式）
- 功率过低→通信距离缩短/丢包/延迟增大（通信变差→切换自动或提高功率）
- 自动模式功率不调整→检查WiFi是否已连接AP
- 设备发热严重→切换自动模式或降低功率

## 相关命令

| 命令 | 说明 |
|------|------|
| askwftxdbm（别名askwifitxdbm） | 短信查询WiFi发射功率 |
| askwfstore | 查询已保存的WiFi网络 |
| wf | 开关WiFi功能 |
