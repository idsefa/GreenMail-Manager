# telamrplay - 通话中播放AMR音频

## 概述
- **功能**: 卡槽通话中时，向对方播放已上传的AMR音频文件（预录制，非实时TTS）
- **前置条件**: ①卡槽在通话中 ②AMR文件已通过AMR上传接口上传到设备
- **异步**: 命令立即返回，播放结果通过683/685事件通知推送
- **互斥**: AMR与TTS互斥（播放AMR自动停止TTS，反之亦然）；录音中禁止播放；AMR播放中/准备中拒绝重复请求

## 请求格式

**HTTP**: `GET /ctrl?token=<管理员Token>&cmd=telamrplay&p1=<卡槽号>&p2=<文件名>`

**TCP**: `{"cmd":"telamrplay","p1":<卡槽号>,"p2":"<文件名>","tid":"<追踪ID>"}\x11\x12`

TCP消息末尾必须附加结束符 `0x11 0x12`。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| token | string | HTTP必填 | 管理员Token，HTTP接口必填；TCP接口无需token |
| cmd | string | 是 | 固定 `telamrplay` |
| p1 | number | 是 | 卡槽号，仅 `1` 或 `2` |
| p2 | string | 是 | AMR文件名（见下方规则） |
| tid | string | 否 | 事务追踪ID，响应原样返回 |

## AMR文件名规则

- 扩展名必须小写 `.amr`
- 文件名主体（去掉`.amr`）仅允许 `[0-9a-zA-Z_-]`
- 不允许路径分隔符 `/` `\`
- 文件名主体不能为空（`.amr` 非法）
- 总长度1~64字符

| 文件名 | 合法 | 说明 |
|--------|------|------|
| `welcome.amr` | Y | 标准 |
| `greeting_01.amr` | Y | 下划线+数字 |
| `voice-prompt.amr` | Y | 含中划线 |
| `Welcome.amr` | N | 扩展名大写 |
| `音频.amr` | N | 中文 |
| `my file.amr` | N | 含空格 |
| `.amr` | N | 主体为空 |

## 前置条件检查（按序）

| # | 检查 | 失败→type=401 |
|---|------|---------------|
| 1 | p1有效数字(1或2) | code=101, note="Missing or invalid p1 (slotId): must be a number (1 or 2)", val="" |
| 2 | 无效卡槽号(非1/2) | code=101, note="Invalid slot ID: {p1}", val="" |
| 3 | 卡槽已就绪 | code=200, note="Card slot {p1} is not ready yet.", val="" |
| 4 | 处于通话中 | code=200, note="No call in progress, AMR playback failed.", val="" |
| 5 | 未在录音 | code=200, note="Recording in progress, AMR playback failed.", val="" |
| 6 | AMR播放状态空闲 | code=200, note="AMR player is busy.", val="" |
| 7 | p2文件名合法 | code=101, note="Invalid filename", val=原始文件名(如`"bad file.amr"`) |

全部通过→设置播放状态为"准备播放"，返回成功。若TTS正在播放，系统后台自动停止TTS后再播放AMR（异步，命令立即返回）。

## 响应消息

公共字段: `type`、`subType`(固定52)、`code`、`val`、`note`、`netCh`、`msgTs`、`devId`

**type=401**: 命令已接收/校验失败（见上方检查表）
**type=402**: 命令执行完成（4G模块播放成功或失败都通过此类型推送）

### 401 成功（播放排队）
```json
{"type":401,"subType":52,"code":0,"val":"welcome.amr","note":"amr play pending...","devId":"c3dd382801","netCh":0,"msgTs":1704067200}
```

### 402 播放成功
```json
{"type":402,"subType":52,"code":0,"val":"welcome.amr","note":"AMR play OK","devId":"c3dd382801","netCh":0,"msgTs":1704067200}
```

### 402 播放失败（4G模块错误）
```json
{"type":402,"subType":52,"code":200,"val":"welcome.amr","note":"AMR play ERR","devId":"c3dd382801","netCh":0,"msgTs":1704067200}
```

| 字段 | 说明 |
|------|------|
| code | 0=成功，101=参数错误，200=业务错误 |
| val | 成功=AMR文件名，失败通常=""(文件名错误时=原始文件名) |
| note | 结果描述 |
| devId | 设备ID |
| netCh | 网络通道号 |
| msgTs | Unix时间戳(秒) |

## 事件通知

| 事件 | 说明 | 触发 |
|------|------|------|
| 683 | AMR播放成功 | 音频开始播放时推送 |
| 685 | AMR播放结束 | 播放完毕或被停止时推送 |

683=已开始播放，685=播放已结束（自然播完或手动停止）。

## 播放状态机

```
空闲 → 准备播放 → [等待TTS停止 →] 播放中 → 播放结束上报 → 已停止 → 空闲
```

| 当前状态 | 触发 | →目标状态 | 附加说明 |
|----------|------|-----------|----------|
| 空闲 | telamrplay(校验通过) | 准备播放 | 返回401 code=0 |
| 准备播放 | TTS正在播放 | 等待TTS停止 | 自动停止TTS |
| 准备播放 | 无TTS | 播放中 | 推送683 |
| 等待TTS停止 | TTS停止 | 播放中 | 推送683 |
| 准备播放 | telamrstop | 空闲 | 取消排队 |
| 等待TTS停止 | telamrstop | 空闲 | 取消排队 |
| 播放中 | 自然完成 | 播放结束上报 | 收到4G模块播放完成URC |
| 播放中 | telamrstop | 停止中 | 等待停止确认 |
| 停止中 | 收到停止确认 | 播放结束上报 | |
| 播放结束上报 | 上报完成 | 已停止 | 推送685 |
| 已停止 | 清理完成 | 空闲 | |

## AMR vs TTS 对比

| | AMR (telamrplay) | TTS (telstarttts) |
|---|---|---|
| 来源 | 预上传AMR文件 | 文本实时转语音 |
| 质量 | 原始录音质量 | 取决于TTS引擎 |
| 长度 | 取决于文件大小 | 文本长度限制 |
| 准备 | 需提前上传 | 无需准备 |
| 互斥 | 播放时自动停止TTS | 播放时自动停止AMR |
| 场景 | 固定语音/音乐 | 动态文本内容 |

## IVR流程

拨号(teldial) → 接通(事件622) → 播放AMR(telamrplay) → 播放结束(685) → 等待按键(642) → 根据按键播对应AMR → ...

## FAQ/故障排除

| 场景 | 处理 |
|------|------|
| 上传AMR文件 | AMR上传接口(HTTP文件上传)，存于4G模块UFS，`uploadamrlist`查看 |
| AMR与TTS互斥 | 等待685后再发telstarttts |
| 录音中禁止播放 | 先`telstoprecord` |
| 判断播放完毕 | 收到685事件 |
| 连续播放 | 等685再播下一个，不可并发 |
| AMR播放器忙 | 等685或`telamrstop` |
| 参数格式错误 | p1须1/2，p2须符合文件名规则 |
| 无通话 | 先确保通话接通 |
| 卡槽未就绪 | 等待启动完成 |
| 对方听不到 | 检查AMR文件内容和4G模块音量设置 |
| 文件名正确但播放失败 | `uploadamrlist`确认文件存在，必要时重新上传 |

## 最佳实践

- 提前上传AMR文件，`uploadamrlist`确认，建议文件名格式`menu_01.amr`
- 等685事件后再发下一个播放命令，避免频繁发送（播放中会返回busy）
- 提前停止用`telamrstop`
- AMR后播TTS，等685后再发`telstarttts`
