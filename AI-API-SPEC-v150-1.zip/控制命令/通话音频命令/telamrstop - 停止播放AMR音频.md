# telamrstop - 停止播放AMR音频

停止正在播放或排队等待的AMR音频。根据AMR状态自动选方式：准备阶段直接取消；播放中发停止指令。**停止AMR不会挂断电话**。

前置条件：卡槽已就绪 + AMR处于播放相关状态(准备中/播放中/停止中)。

## 请求

**HTTP**: `GET /ctrl?token=<管理员Token>&cmd=telamrstop&p1=<卡槽号>`

**TCP**: `{"cmd":"telamrstop","p1":<卡槽号>,"tid":"<追踪ID>"}\x11\x12`（末尾必须有`0x11 0x12`）

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| token | 字符型 | HTTP是 | 管理员Token，HTTP接口必填；TCP接口无需token |
| cmd | 字符型 | 是 | 固定`telamrstop` |
| p1 | 数值型 | 是 | 卡槽号，1或2 |
| tid | 字符型 | 否 | 事务追踪ID，响应原样返回 |

## 前置校验（顺序执行，首个失败即返回）

| # | 检查 | 失败→type=401 |
|---|------|--------------|
| 1 | p1是否为1或2 | code=101, note="Missing or invalid p1 (slotId): must be a number (1 or 2)" 或 "Invalid p1 (slotId): must be 1 or 2" |
| 2 | 卡槽已就绪? | code=200, note="Card slot X is not ready yet." |
| 3 | AMR非空闲? | code=200, note="AMR is not playing, no need to stop." |

## AMR状态处理

| AMR状态 | 处理 | 返回note |
|---------|------|---------|
| 准备播放(排队中) | 直接取消排队，原telamrplay收到异步错误(subType=52,code=200,"AMR play cancelled by user stop") | 402 code=0 "AMR play cancelled (was pending)." |
| 等待TTS停止中 | 直接取消，不再等待TTS停止 | 同上 |
| 播放中 | 向4G模块发停止指令，确认后推685事件 | 401 code=0 "amr play stopping..." → 402 code=0 val=文件名 "AMR stop OK" |
| 停止中/已停止 | 无需重复操作 | 401 code=0 "AMR already stopping/stopped." |
| 空闲 | 返回错误 | 前置校验拦截 |

4G模块返回错误时：402 code=200 val=文件名 "AMR stop ERR"

## 响应字段

所有响应包含：`type`(401=接收/校验,402=完成)、`subType`(固定53)、`code`(0=成功,101=参数错,200=业务错)、`val`(通常空,停止完成时为文件名)、`note`、`devId`、`netCh`、`msgTs`(Unix秒)

## 时序

**取消排队AMR**: telamrplay→401 code=0 "amr play pending..." → telamrstop→取消→402 code=0 "AMR play cancelled" + 原402 subType=52 code=200 "AMR play cancelled by user stop"

**停止播放AMR**: telamrstop→401 code=0 "amr play stopping..." → 4G模块停止确认→402 subType=53 code=0 "AMR stop OK" + 685事件(AMR播放结束)

## 命令对比

| 特性 | telamrstop | telhangup | telstoptts |
|------|------------|-----------|------------|
| 功能 | 停止AMR播放 | 挂断通话 | 停止TTS播放 |
| 目标 | AMR文件 | 整个通话 | 文本转语音 |
| 通话状态 | 保持 | 立即结束 | 保持 |
| 可否挂断 | 否 | 是 | 是(p2=1) |
| 空闲时 | 返回错误 | 正常执行 | 返回成功 |

## FAQ与故障

| 场景 | 说明 |
|------|------|
| 停止后通话断开? | 不会，仅停音频。需挂断用telhangup |
| 停止耗时 | 通常1-2秒，等685事件确认 |
| 停止后播TTS | 可立即发telstarttts |
| 停止后播新AMR | 需等完全停止(685或402)后再发telamrplay |
| AMR未停止 | 4G模块延迟，等几秒重试或用telhangup |
| 停止后电话被挂断 | 非本命令导致，检查其他操作 |

## 最佳实践

- 使用场景：提前结束AMR(如用户按键中断) / AMR播放中切换TTS / 取消排队中AMR
- 停止AMR→等685事件→播TTS或新AMR，未确认前不发新播放命令
- 需继续通话用telamrstop，通话结束用telhangup(自动停所有音频)
- 区分"AMR未在播放"(code=200)与"停止成功"(code=0)
