# AMRUpload - AMR音频上传接口

## 基本信息

- **路径**: `POST /AMRUpload`
- **类型**: HTTP文件上传接口（非控制命令），使用`multipart/form-data`编码
- **认证**: 无需token，直接POST（区别于`ctrl?cmd=...`格式的控制命令）
- **并发**: 同一时间仅允许一个上传任务，并发返回HTTP 400
- **处理模式**: 异步。HTTP 200仅表示文件已接收（阶段1完成），最终结果通过type=402异步推送
- **存储位置**: 4G模块存储，上传后可通过`telamrplay`在通话中播放
- **同名文件**: 上传会**覆盖**旧文件。**禁止在AMR播放过程中上传同名文件**（会导致播放异常）
- **网络中断**: 设备自动清理临时数据，无需手动干预
- **内容校验**: 接口仅校验文件名格式，不校验文件实际内容。非AMR格式文件若重命名为`.amr`可上传成功，但4G模块播放时会失败

## 请求格式

```http
POST /AMRUpload HTTP/1.1
Host: <设备IP>
Content-Type: multipart/form-data; boundary=<自定义分隔符>

--<分隔符>
Content-Disposition: form-data; name="file"; filename="<文件名.amr>"
Content-Type: audio/amr

<AMR二进制数据>
--<分隔符>--
```

- `name`字段名无硬性要求，设备从multipart数据中自动提取文件名和内容
- **`file`字段为必填**，通过multipart提交AMR文件数据
- 文件名通过`Content-Disposition`的`filename`字段传递
- 分隔符规则(RFC 2046)：消息体中用`--`+boundary值，末尾分隔符额外加`--`
- curl示例：`curl -X POST -F "file=@greeting.amr" http://<设备IP>/AMRUpload`

## 文件名规则（不符合则上传被拒绝）

| 规则 | 说明 |
|------|------|
| 扩展名 | 必须小写`.amr`（不支持`.AMR`或大小写混合） |
| 文件名主体 | 去掉`.amr`后，仅允许`0-9 a-z A-Z - _`，最多60字符 |
| 总长度 | 去引号后5~64字符（含`.amr`），最短如`a.amr` |
| 路径分隔符 | 不允许`/`或`\` |
| 引号 | 被双引号包裹时自动去除 |

非法示例：`file.AMR`(扩展名非小写)、`my file.amr`(含空格)、`hello.amr.amr`(主体含`.`)、`中文.amr`(非ASCII)、`.amr`(主体为空)、`path/to/file.amr`(含路径分隔符)

## 文件大小限制

| 项目 | 限制 |
|------|------|
| AMR文件内容 | ≤100KB（102,400字节） |
| HTTP请求体（含multipart开销） | ≤101KB（103,424字节） |

## 上传流程（两阶段）

前置校验（任一不通过返回HTTP 400）：并发检查 → 文件名校验 → 请求体大小检查 → 设备存储空间检查

| 阶段 | 进度范围 | 内容 |
|------|----------|------|
| 阶段1：上传 | 5%→50% | 接收客户端文件数据。完成返回HTTP 200 |
| 阶段2：数据处理 | 50%→100% | 内部处理并写入4G模块存储。推送type=402结果 |

- 进度每变化5%上报一次（type=401），0%不上报
- 阶段1进度基于Content-Length估算，结束时可能略低于50%，阶段2补齐
- 两阶段间可能短暂无进度上报（通常几秒内）
- 进度超过30秒无变化可能异常，可检查设备状态后重试

## HTTP响应

**HTTP 200（文件已接收）**：
```json
{"status":"received","filename":"greeting.amr","size":10240}
```

**HTTP 400（上传未启动，统一响应）**：
```json
{"error":"Upload not started"}
```
所有拒绝场景均返回此响应体，不区分具体原因。原因包括：并发上传、文件名不合法、文件过大、设备存储空间不足、请求格式错误。

## 异步推送消息

公共字段：`type`、`subType`、`code`、`val`、`note`、`devId`、`netCh`、`msgTs`

### 进度推送（type=401，subType=49）

阶段1：
```json
{"type":401,"subType":49,"code":0,"val":"30","note":"upload:30720","devId":"...","netCh":0,"msgTs":...}
```
- `val`: 进度百分比字符串（"5"~"50"）
- `note`: `"upload:<已接收字节数>"`

阶段2：
```json
{"type":401,"subType":49,"code":0,"val":"75","note":"process:51200/102400","devId":"...","netCh":0,"msgTs":...}
```
- `val`: 进度百分比字符串（"50"~"100"）
- `note`: `"process:<已处理字节数>/<总字节数>"`

### 最终结果推送（type=402，subType=49）

成功（code=0）：
```json
{"type":402,"subType":49,"code":0,"val":"greeting.amr","note":"ok","devId":"...","netCh":0,"msgTs":...}
```

失败（code=200）：
```json
{"type":402,"subType":49,"code":200,"val":"greeting.amr","note":"UFS insufficient","devId":"...","netCh":0,"msgTs":...}
```
```json
{"type":402,"subType":49,"code":200,"val":"greeting.amr","note":"Write to UFS failed","devId":"...","netCh":0,"msgTs":...}
```
- `note`常见错误：`"UFS insufficient"`（4G模块存储空间不足）、`"Write to UFS failed"`（数据处理失败）

### 推送字段说明

| 字段 | 说明 |
|------|------|
| type | 401=进度更新，402=最终结果 |
| subType | 固定49 |
| code | 0=成功/进度正常，200=失败 |
| val | type=401时为进度百分比字符串；type=402时为文件名 |
| note | 进度时为`"upload:<字节数>"`或`"process:<已处理>/<总大小>"`；最终结果为`"ok"`或错误描述 |
| devId | 设备ID |
| netCh | 网络通道号 |
| msgTs | Unix时间戳（秒） |

## 返回码

| code | 含义 |
|------|------|
| 0 | 成功（401=进度正常，402=上传完成） |
| 200 | 失败（见note字段） |

本接口为HTTP接口（非控制命令），不使用其他返回码（如100 Token错误、101 参数错误），此类错误通过HTTP 400状态码直接返回。

## 失败场景

| 场景 | HTTP码 | type=402 | 原因/处理 |
|------|--------|----------|-----------|
| 并发上传 | 400 | 无 | 已有上传进行中，等待type=402后重试 |
| 文件名不合法 | 400 | 无 | 检查命名规则 |
| 文件过大 | 400 | 无 | 超100KB，压缩/裁剪后重试 |
| 设备存储空间不足 | 400 | 无 | 清理后重试 |
| 4G模块存储空间不足 | 200 | note="UFS insufficient" | 用`uploadamrremove`清理 |
| 数据处理失败 | 200 | note="Write to UFS failed" | 检查4G模块状态/重启重试 |
| 上传中断 | — | 无 | 设备自动清理临时数据 |
| 长时间未收到type=402 | 200 | 无 | HTTP 200后数据处理异常，检查4G模块状态/重启重试 |

时序说明：HTTP 400=阶段1即失败（上传未启动），无异步推送；HTTP 200后失败=阶段2失败，通过type=402推送详情。

## AMR音频制作

4G模块使用AMR-NB格式（3GPP TS 26.071标准）：采样率固定8000Hz，仅单声道。所有4G模块均兼容。

**FFmpeg转换命令**：
```bash
ffmpeg -i input.wav -ar 8000 -ab 12.2k -ac 1 output.amr
```
- `-ar 8000`：AMR-NB标准采样率
- `-ac 1`：单声道
- `-ab <比特率>`：见下表，推荐12.2k（MR122最高质量）
- 截取前N秒：加`-t N`参数
- 支持输入格式：wav、mp3、ogg、flac等

### AMR-NB比特率对照（100KB文件限制下）

| 模式 | 比特率 | ffmpeg参数 | 每10秒约文件大小 | 100KB可录时长 |
|------|--------|-----------|----------------|--------------|
| MR475 | 4.75kbps | `-ab 4.75k` | ~5.9KB | ~170秒(2分50秒) |
| MR515 | 5.15kbps | `-ab 5.15k` | ~6.4KB | ~157秒(2分37秒) |
| MR59 | 5.90kbps | `-ab 5.9k` | ~7.3KB | ~136秒(2分16秒) |
| MR67 | 6.70kbps | `-ab 6.7k` | ~8.3KB | ~120秒(2分00秒) |
| MR74 | 7.40kbps | `-ab 7.4k` | ~9.3KB | ~107秒(1分47秒) |
| MR795 | 7.95kbps | `-ab 7.95k` | ~9.8KB | ~102秒(1分42秒) |
| MR102 | 10.2kbps | `-ab 10.2k` | ~12.7KB | ~78秒(1分18秒) |
| MR122 | 12.2kbps | `-ab 12.2k`（推荐） | ~15.1KB | ~66秒(1分06秒) |

注：理论估算值，实际含AMR文件头6字节及帧封装开销。降低比特率可获得更长录音时间。转换后请检查文件大小不超过100KB。

## 文件生命周期

- 上传后存储在4G模块中，通过`telamrplay`在通话中播放
- 上传同名文件会覆盖旧文件
- 禁止在AMR播放过程中上传同名文件
- 查询文件：`uploadamrlist`；删除文件：`uploadamrremove`

## 关联命令

| 命令 | 用途 |
|------|------|
| uploadamrlist | 列出已上传文件、查看剩余空间 |
| uploadamrremove p1=文件名 | 删除指定文件、释放空间 |
| telamrplay p1=卡槽 p2=文件名 | 通话中播放AMR音频 |
| telamrstop | 停止AMR播放，保持通话 |

## 完整使用流程

1. `POST /AMRUpload` 上传AMR文件
2. 等待 type=402 (code=0) 确认成功
3. `uploadamrlist` 确认文件存在
4. `teldial` 拨打电话，等待622事件（通话接通）
5. `telamrplay p2=<文件名>` 播放音频
6. 等待685事件（播放结束）
