# telstarttts - 通话中播放TTS语音

## 功能
通话中(ANSWERING状态)向对方播放TTS语音。前置条件：卡槽必须处于通话中状态，否则返回错误。新TTS命令自动停止正在播放的旧TTS。TTS文本自动按标点符号智能分段。

## 执行流程
1. 校验p1→缺失/非数字→code=101, note="Missing or invalid p1 (slotId): must be a number (1 or 2)"
2. 校验p1范围→超出→code=101, note="Invalid slot ID: X"
3. 校验卡槽就绪→未就绪→code=200, note="Card slot X is not ready yet."
4. 校验通话状态→无通话→code=200, note="No call in progress, TTS playback failed."
5. 校验p2内容→为空→code=101, note="No playable TTS text content."
6. 解析p3/p4/p5→停止旧TTS→添加播放队列→返回成功

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| token | 字符型 | 是(HTTP) | 管理员Token，HTTP接口必填；TCP接口无需token |
| cmd | 字符型 | 是 | `telstarttts` |
| p1 | 数值型 | 是 | 卡槽号：`1`或`2` |
| p2 | 字符型 | 是 | TTS内容，不能为空，自动按标点分段；HTTP需UTF-8 URL编码 |
| p3 | 数值型 | 否 | 播放轮数，≥0，`0`=无限循环(默认) |
| p4 | 数值型 | 否 | 轮间暂停秒数，≥0(建议≤60)，默认`1` |
| p5 | 数值型 | 否 | 播完动作：`0`=保持通话(默认)，`1`=挂断 |
| tid | 字符型 | 否 | 事务追踪ID，响应中原样返回 |

## TTS文本限制
- 单条总长：建议≤4096字节(约2000汉字)
- 自动分段：按标点分段，每段≤274逻辑字节(约130汉字/260英文字符)
- 支持中英文混合，自动转UCS2编码

## 格式
HTTP: `http://<ip>/ctrl?token=<token>&cmd=telstarttts&p1=<slot>&p2=<text>&p3=<count>&p4=<interval>&p5=<action>`

TCP(末尾附加`0x11 0x12`，中文UTF-8):
```json
{"cmd":"telstarttts","p1":1,"p2":"TTS内容","p3":2,"p4":1,"p5":0,"tid":"1234"}\x11\x12
```

## 响应
公共字段：`type`、`subType`(固定=26)、`code`、`val`(通常为空)、`note`、`netCh`、`msgTs`:Unix时间戳(秒)、`devId`
- type=401：命令已接收/参数校验失败 | type=402：命令执行完成(仅成功)

| 场景 | type | code | note |
|------|------|------|------|
| 启动成功 | 401 | 0 | `telstarttts has been processed...` |
| p1缺失/格式错误 | 401 | 101 | `Missing or invalid p1 (slotId): must be a number (1 or 2)` |
| p1超出范围 | 401 | 101 | `Invalid slot ID: X` |
| 无通话进行中 | 401 | 200 | `No call in progress, TTS playback failed.` |
| p2为空 | 401 | 101 | `No playable TTS text content.` |
| 卡槽未就绪 | 401 | 200 | `Card slot X is not ready yet.` |

## 实践要点
- 适当使用标点提高自然度，每句≤50汉字，单次TTS建议≤200字
- p3=0无限循环需telstoptts或挂断停止；p4建议1-3秒，过短可能语音密集堆积
- 新telstarttts自动停旧TTS，连续播放需等前一个完成；可用telstoptts主动停止
- HTTP中文必须UTF-8 URL编码，编码错误(如GBK)导致中文不播放；浏览器地址栏直接输入可自动编码
