# uploadamrlist - 列出AMR音频文件

## 基本信息
- 命令: `uploadamrlist`
- 功能: 查询设备存储中所有通过AMR上传功能写入的音频文件列表及剩余可用空间
- 异步命令: type=401=命令已接收，完整文件列表通过type=402异步推送
- 范围: 仅AMR上传文件，不含通话录音等其他文件

## 请求格式

**HTTP**: `GET /ctrl?token=<管理员Token>&cmd=uploadamrlist`

**TCP**: `{"cmd":"uploadamrlist","tid":"1234"}\x11\x12`（tid可选，末尾2字节结束符0x11 0x12）

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| token | 字符型 | HTTP必填 | 管理员Token，HTTP接口必填；TCP接口无需token |
| cmd | 字符型 | 是 | 固定值`uploadamrlist` |
| tid | 字符型 | 否 | 事务追踪ID，响应原样返回 |

## 响应

### type=401 命令已接收
```json
{"type":401,"subType":50,"code":0,"val":"","note":"listing amr files","netCh":0,"msgTs":1704067200}
```

### type=402 异步结果推送
含额外字段: `files`、`totalFree`（有tid时含`tid`）

**成功(有文件)**: code=0, files非空, totalFree=剩余字节数
```json
{"type":402,"subType":50,"code":0,"files":[{"fname":"greeting.amr","fsize":10240}],"totalFree":524288,"tid":"1234","netCh":0,"msgTs":1704067200}
```

**成功(无文件)**: code=0, files=[], totalFree=剩余字节数
```json
{"type":402,"subType":50,"code":0,"files":[],"totalFree":1048576,"tid":"1234","netCh":0,"msgTs":1704067200}
```

**失败**: code=200, files=[], totalFree=-1
```json
{"type":402,"subType":50,"code":200,"files":[],"totalFree":-1,"tid":"1234","netCh":0,"msgTs":1704067200}
```

## HTTP协议差异

HTTP响应中，`files`数组被平铺为`fname`/`fsize`平行字段，数值均为字符串类型：

| 文件数 | fname | fsize | 示例 |
|-------|-------|-------|------|
| 0个 | 不存在 | 不存在 | - |
| 1个 | string | string | `"fname":"a.amr","fsize":"10240"` |
| 多个 | string[] | string[] | `"fname":["a.amr","b.amr"],"fsize":["10240","5120"]` |

`totalFree`、`code`、`subType`等数值字段同样为字符串类型。客户端解析时需兼容string与string[]两种类型。

## 字段说明

| 字段 | 类型 | 说明 |
|------|------|------|
| type | int | 401=命令已接收，402=执行完成 |
| subType | int | 固定50 |
| code | int | 0=成功，100=Token错误，200=查询失败 |
| val | string | type=401时为空 |
| note | string | 操作描述，如"listing amr files" |
| files | array | 文件列表(type=402)，元素含fname(string,原始文件名)和fsize(int,字节数)。HTTP响应中被平铺为fname/fsize，见"HTTP协议差异" |
| totalFree | int | 剩余空间(字节)，查询失败时-1(type=402) |
| tid | string | 仅请求携带时返回 |
| netCh | int | 网络通道号 |
| msgTs | long | Unix时间戳(秒) |

## 返回码

| code | 含义 | 说明 |
|------|------|------|
| 0 | 成功 | 结果在files数组 |
| 100 | Token错误 | 检查管理员Token |
| 200 | 查询失败 | 存储访问异常可重试；totalFree=-1表示空间查询也失败 |

## 处理流程
1. 接收命令→返回type=401
2. 查询剩余空间(失败→totalFree=-1)
3. 扫描全部文件(失败→返回type=402 code=200 空列表)
4. 过滤AMR上传文件→还原原始文件名→提取大小
5. 推送type=402

## 文件名规则
用户始终使用原始文件名操作，设备内部自动管理标识，查询时自动还原原始文件名。

## 故障排除

| 场景 | 处理 |
|------|------|
| 查询结果为空 | 确认有AMR上传文件；code=200为存储异常需重试 |
| totalFree=-1 | 空间查询失败，files可能仍有效(code=0时)，建议重试 |
| 未收到type=402 | 通信模块未就绪，等待初始化后重试 |
| code=200 files为空 | 存储访问超时/异常，重试 |
| Token错误 | 使用正确管理员Token |

## 最佳实践
- 定期查询文件列表了解设备音频存储情况
- 删除前先`uploadamrlist`确认文件存在，再用`uploadamrremove`删除
- 关注totalFree，空间不足时及时清理
- 建议携带tid关联请求响应
