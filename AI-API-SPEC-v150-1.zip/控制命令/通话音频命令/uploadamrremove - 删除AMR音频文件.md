# uploadamrremove - 删除AMR音频文件

删除设备AMR上传音频文件。配合`uploadamrlist`先查后删。**不可逆**。异步命令：参数校验失败→type=402直接返回；校验通过→type=401已接收→type=402异步推送结果。

## 请求

HTTP: `GET /ctrl?token=<管理员Token>&cmd=uploadamrremove&p1=<文件名>`

TCP: `{"cmd":"uploadamrremove","p1":"<文件名>","tid":"<追踪ID>"}\x11\x12`（末尾结束符0x11 0x12）

## 参数

| 参数 | 必填 | 说明 |
|------|------|------|
| token | 是(HTTP) | 管理员Token，HTTP接口必填；TCP接口无需token |
| cmd | 是 | 固定`uploadamrremove` |
| p1 | 是 | 要删除的音频文件名，须符合命名规则 |
| tid | 否 | 事务追踪ID，响应原样返回 |

## p1文件名校验规则

1. 非空
2. 去引号后长度5~64字符（含`.amr`），最短`a.amr`
3. 不含`/`或`\`
4. 扩展名必须小写`.amr`
5. 去掉`.amr`后主体非空
6. 主体仅含`0-9a-zA-Z-_`

双引号包裹时自动去引号。

合法: `greeting.amr` `alarm_01.amr` `notify-tone.amr` `Sound2024.amr`
非法: `file.AMR`(扩展名非小写) `my file.amr`(空格) `hello.amr.amr`(主体含`.`) `中文.amr`(非ASCII) `.amr`(主体空) `path/to/file.amr`(含路径分隔符)

## 响应

subType固定=51。基础字段: `type` `subType` `code` `val`(文件名) `note` `netCh`(网络通道号) `msgTs`(Unix秒)。请求携带`tid`时响应原样返回。

### 参数校验失败(type=402，同步直接返回)

| 场景 | code | val | note |
|------|------|-----|------|
| p1为空/不存在 | 101 | "" | Invalid filename |
| p1格式非法 | 101 | 传入的p1值 | Invalid filename |

### 命令接收确认(type=401)

code=0, val=文件名, note="deleting amr file"

### 异步删除结果(type=402)

| 场景 | code | val | note |
|------|------|-----|------|
| 删除成功 | 0 | 文件名 | ok |
| 删除失败 | 200 | 文件名 | Delete failed |

## 返回码

| code | 含义 |
|------|------|
| 0 | 成功(401=已接收，402=删除成功) |
| 100 | Token错误 |
| 101 | 文件名格式错误 |
| 200 | 删除失败(文件不存在/存储异常，可检查设备状态或重启后重试) |

## 注意

- 每次只删一个文件，多文件逐个发，建议等上一条type=402后再发下一条
- 删前先`uploadamrlist`确认文件存在
- 删不存在的文件: 正常接收(401)但异步返回失败(402 code=200)
- 删除操作异步执行，通常几秒内完成
- 未收到type=402: 设备可能未就绪，等待初始化后重试
- 建议携带`tid`便于多命令追踪
- 推荐 小写字母+数字+下划线 命名规范，定期清理释放存储空间
