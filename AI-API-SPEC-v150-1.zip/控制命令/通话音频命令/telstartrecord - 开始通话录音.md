# telstartrecord - 开始通话录音

通话中开始录音，AMR格式，可自动上报服务器。
前提：通话已接通且录音空闲；需先配置录音上传URL
限制：最大60秒；同卡槽同时只能一个录音任务
自动停止：达p2设定时长/60秒上限/通话结束(对方或本机挂断)

## 校验流程与响应(按序)
异步响应机制：401=命令立即响应(含成功和所有错误)；402=命令执行完成后的异步推送(如录音完成事件通知)
本命令所有立即响应均为type=401, subType=43。公共字段：type/subType/code/val/note/netCh(网络通道号)/msgTs(Unix时间戳秒)

| 序 | 校验项 | code | note | val |
|---|--------|------|------|-----|
| 1 | 未配置录音上传URL | 200 | No defined recording upload URL. | "" |
| 2 | p1缺失 | 101 | Missing required parameter: p1 (slotId) | "" |
| 3 | p1无效(非1/2) | 101 | Invalid slot ID: {p1} | "" |
| 4 | 卡槽未就绪 | 200 | Card slot {p1} is not ready yet. | "" |
| 5 | 无通话进行中 | 200 | No call in progress, recording failed. | "" |
| 6 | 已在录音中 | 200 | Recording is already in progress. | "" |
| 7 | p2≤0 | 101 | Invalid record duration <= 0 is not allowed. | "" |
| 8 | p2>60 | 101 | Record duration exceeds max: 60 seconds. | "" |
| 9 | ✅通过，开始录音 | 0 | telstartrecord has been processed... | 录音文件名 |

code含义：0=成功；101=参数格式错误；200=前置条件不满足

## 参数
| 参数 | 必填 | 说明 |
|------|------|------|
| token | 是(HTTP) | 管理员Token，HTTP接口必填；TCP接口无需token |
| cmd | 是 | telstartrecord |
| p1 | 是 | 卡槽号：1或2 |
| p2 | 否 | 录音时长(秒)，有效1~60，默认设备配置值 |
| p3 | 否 | 录音文件名。省略自动生成：s{slotId}{direction}{timestamp}.amr(direction:0=呼出,1=呼入) |
| p4 | 否 | 录音结束立即上报。默认设备配置。1/on/true=上报；0/off/false=不上报 |
| tid | 否 | 事务追踪ID，响应中原样返回 |

## 格式
HTTP: `http://<ip>/ctrl?token=<t>&cmd=telstartrecord&p1=<slot>[&p2=<dur>][&p3=<file>][&p4=<upload>][&tid=<id>]`
TCP(末尾须附加0x11 0x12): `{"cmd":"telstartrecord","p1":1,"p2":30,"p3":"f.amr","p4":1,"tid":"t"}\x11\x12`

## 文件名自动生成
格式：s{slotId}{direction}{timestamp}.amr
- slotId: 卡槽号(1/2)
- direction: 0=呼出, 1=呼入
- timestamp: 通话开始时间戳
示例：s101704067200.amr → 卡槽1,呼出,时间戳1704067200

## 故障排除
| 现象 | 原因 | 方案 |
|------|------|------|
| No defined recording upload URL | 未配置录音上传地址 | 先配置录音上传URL后再使用 |
| No call in progress | 当前无通话或通话未接通 | 确保电话已接通后再发送命令 |
| Record duration exceeds max | p2参数超过60秒 | 将p2调整为1~60之间的值 |
| No active call record found | 系统未找到活动通话记录 | 确认通话已建立，可能需重新拨打 |
| 录音文件未生成 | 存储空间不足或硬件故障 | 检查存储，必要时重启设备 |
| Card slot not ready | 卡槽模块未初始化 | 等待约30秒或用slotrst重启卡槽 |
| Recording already in progress | 当前卡槽已在录音 | 先用telstoprecord停止 |
