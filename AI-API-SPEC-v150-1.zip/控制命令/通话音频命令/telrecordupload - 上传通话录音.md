# telrecordupload - 上传通话录音

将指定通话录音文件上传到已配置的录音上报URL（telRecUrl，经setamrurl设置；仅AMR格式）。异步命令：仅发起上传请求，立即返回（code=0只表示命令已接收），实际上传后台进行，结果经695（成功）/696（失败）事件推送获取——需在设备配置中启用这两类事件上报。

前置条件：①已配置录音上传URL（http://、https://或smtp://）②设备有可用网络连接（WiFi或SIM卡流量）③录音文件存在于设备录音缓存中。
典型场景：通话存档（客服/业务确认/合规）、证据保全（重要通话备份/纠纷依据/法律证据）、内容回顾（会议记录/订单复查/培训材料）、异地备份（云端存储/多服务器分发/灾难恢复）。

## 参数
| 参数 | 必填 | 说明 |
|------|------|------|
| token | HTTP必填 | 管理员Token，身份验证；TCP接口无需 |
| cmd | 是 | 固定值 telrecordupload |
| p1 | 是 | 录音文件名 |
| tid | 否 | 事务追踪ID，响应中原样返回，用于关联请求与响应 |

## 格式
HTTP: `http://192.168.7.170/ctrl?token=3f4bffa77257d243875d0a5a80635934&cmd=telrecordupload&p1=rec001.amr`
TCP（消息末尾须附加2字节二进制结束符0x11 0x12，非字符串）: `{"cmd":"telrecordupload", "p1":"rec001.amr", "tid":"1234"}\x11\x12`

## 校验与执行流程
响应机制：401=命令立即响应（含成功与所有错误）；402=命令执行完成后的异步推送。本命令所有立即响应均为type=401、subType=45。响应公共字段：type/subType/code/val/note/netCh(网络通道号)/msgTs(Unix秒)。

同步立即响应（按序）：
| 序 | 校验 | code | note | val |
|---|------|------|------|-----|
| 1 | p1缺失 | 101 | "" | "" |
| 2 | ✅通过，命令已接收，转入异步上传 | 0 | telrecordupload has been processed... | "" |

code含义：0=成功（文件异步上传中）；100=Token错误；101=缺少必填参数；200=通用错误（看后续推送的失败消息获取具体原因）。

立即响应JSON示例：
成功：`{"type":401,"subType":45,"code":0,"val":"","note":"telrecordupload has been processed...","netCh":0,"msgTs":1704067200}`
缺p1：`{"type":401,"subType":45,"code":101,"val":"","note":"","netCh":0,"msgTs":1704067200}`

异步执行（按序检查，任一失败推送失败消息）：
1. 录音文件不存在 → 推送"文件未找到"
2. 录音URL未配置 → 推送"URL未配置"
3. URL格式无效（须以http/https/smtp开头）→ 推送"URL格式错误"
4. 录音不在缓存 → 推送"录音已过期"。录音存于设备临时缓存，设备重启或缓存被清理后录音信息丢失——即使物理文件存在，系统也无法确定其属于哪通电话，会删除该文件并报"upload file has expired"
5. 文件大小0字节 → 自动重试（回到第1步文件存在检查），最多5次、每次间隔约2秒；用尽仍失败 → 推送"文件无效"。其他失败情况不自动重试，需手动重发命令
6. 文件有效 → 执行上传；成功推送695事件（录音文件上传成功通知），失败推送696事件（上传失败通知）

## 录音文件名
- telstartrecord录音时指定了文件名→用指定名；未指定→系统自动生成不重复默认名
- 获取途径：telstartrecord命令返回值、通话记录上报消息（401事件）
- 仅支持AMR格式(.amr)；文件大小≈1KB/秒（30分钟录音约1.8MB）
- 录音停止时若设备配置了自动上报（通常在telstartrecord或teldial命令中经参数配置），系统自动生成并发送telrecordupload

## 录音上传URL模板变量（telRecUrl）
URL中可用`{{变量名}}`模板引用本次通话/设备数据，上传前自动替换为实际值。两类写法：简单变量`{{phNum}}`、`{{telStartTs}}`；带函数`{{scName|$urlEncode()}}`、`{{telStartTs|$fmtTime('YYYY-MM-DD hh:mm:ss')}}`。

通话相关变量（本字段独有）：
| 变量 | 含义 | 示例值 |
|------|------|--------|
| phNum | 对端号码（匿名来电时为anonymous，不是空） | 13800138000 |
| telStartTs | 通话起始Unix秒 | 1647344540 |
| telConnectedTs | 接通Unix秒 | 1647344600 |
| telOutBoundRingTs | 外呼振铃Unix秒（主叫独有，被叫时为空） | 1647344550 |
| telKeyPressTs | 通话按键Unix秒 | 1647344650 |
| telEndTs | 通话结束Unix秒 | 1647344840 |
| telMediaId | 录音文件ID | rec001.amr |
| tid | 事务追踪ID | abc123 |
| note | 备注（录音上报场景通常为空） | - |

公共变量（精选常用）：devId=设备唯一ID；slot=卡槽号(1/2)；imsi/iccId/msIsdn=SIM卡信息；scName=运营商名称（含中文，建议加`|$urlEncode()`）；now=当前Unix秒（上传时刻，旧写法`{{NOW}}`同效）；`now|$fmtTime(...)`=当前格式化时间（旧写法`{{YYMDHMS}}`同效）；ip/ssid=WiFi连接信息（WiFi已连接时有效）；hwVer=硬件版本。完整公共变量清单（含LN/LR/ADMIN_*/WIFI_*/PRODUCT_*等）见 管道表达式/（3）系统参数/参数总览。

常用函数（精选）：`$urlEncode`=URL编码（中文/特殊字符）；`$concat`=字符串拼接，如`{{devId|$concat('-', '{{slot}}')}}`；`$md5`/`$sha256`=生成签名（服务端校验）；`$fmtTime`=时间戳转可读格式（旧函数$ts2yyyymmddhhmmss同效），如`{{telStartTs|$fmtTime('YYYY-MM-DD hh:mm:ss')}}`。完整清单见 管道表达式/（4）管道函数/函数总览。

完整范例（URL携带通话关键信息）：
`http://your-server.com:8080/AMReceived?devId={{devId}}&slot={{slot}}&imsi={{imsi}}&phNum={{phNum}}&telStartTs={{telStartTs}}&telEndTs={{telEndTs}}&telConnectedTs={{telConnectedTs}}&tid={{tid}}`

签名校验示例（对devId+phNum做MD5）：
`http://your-server.com:8080/AMReceived?devId={{devId}}&phNum={{phNum}}&sign={{devId|$concat('{{phNum}}')|$md5()}}`
函数参数（如`$concat('...')`中的内容）可嵌套引用通话相关变量——上例sign里的`'{{phNum}}'`求值时先替换为本次通话实际号码，再参与拼接与签名；同理`{{phNum|$concat('-','{{telStartTs}}')}}`→`13800138000-1647344540`（号码拼时间戳作归档编号）。嵌套层数有上限，见 管道表达式/（2）语法详解/计算顺序与限制。

重要注意事项：
- 引用不存在的变量替换为**空字符串**（不会保留`{{xxx}}`原文）
- 变量名仅允许字母/数字/下划线
- 含中文字段（如scName）及可能带+86前缀的phNum建议加`|$urlEncode()`

## 上传协议
| 协议 | URL格式 | 说明 |
|------|---------|------|
| HTTP | http://server/path | 普通HTTP上传，适用于内网环境 |
| HTTPS | https://server/path | 加密HTTP上传，推荐用于生产环境 |
| SMTP | smtp://server:port?user=xxx&pwd=xxx&from=xxx&to=xxx | 邮件方式上传，录音作为附件发送 |

SMTP示例：`smtp://smtp.example.com:587?user=device@example.com&pwd=yourpassword&to=admin@example.com&from=device@example.com`
SMTP必填：server:port（服务器地址和端口）、user（登录用户名）、pwd（登录密码）、to（收件人）、from（发件人）。
SMTP可选：cc/bcc=抄送/密送邮箱（多个用逗号分隔，默认空）；tls=TLS加密模式none/ssl/starttls（默认根据端口自动选择）；auth=认证模式plain/login/cram_md5（默认plain）；timeout=SMTP操作超时秒数（默认60）；retries=失败重试次数（默认1）。

## 服务器端HTTP接口规范（HTTP/HTTPS上传）
设备以multipart/form-data格式POST上传，表单字段名固定`media`；Content-Disposition含filename（录音文件名）与filelength（字节数）；Part Content-Type为application/octet-stream；Body为AMR音频二进制。请求示例：

```http
POST /upload/recording HTTP/1.1
Host: your-server.com:8080
Content-Type: multipart/form-data; boundary=!LvYouTiGf93TebY9z!
Content-Length: 12345

--!LvYouTiGf93TebY9z!
Content-Disposition: form-data; name="media"; filename="rec001.amr"; filelength=10240
Content-Type: application/octet-stream

[二进制文件内容...]
--!LvYouTiGf93TebY9z!--
```

服务器应返回JSON：
| 字段 | 类型 | 说明 |
|------|------|------|
| errcode | int | 错误码，0成功，非0失败 |
| errmsg | string | 错误信息，成功时为"success" |
| type | string | 文件类型，固定返回"amr" |
| media_id | string | 服务端分配的文件唯一标识（可选，建议返回） |
| created_at | long | 文件创建Unix秒 |

成功示例：`{"errcode":0,"errmsg":"success","type":"amr","media_id":"rec001_20240101_123456.amr","created_at":1704067200}`
失败示例：`{"errcode":400,"errmsg":"Invalid file type","type":"","media_id":"","created_at":0}`
常见errcode：0=成功；400=请求参数错误（无文件、文件类型错误等）；413=文件大小超出限制；500=服务器内部错误。
参考实现模式（正本含Node.js/Python/PHP/Java四段完整服务端示例，共性模式）：接收multipart字段media→校验扩展名.amr→保存文件→按上述JSON响应；错误分支返回errcode=400/500、type与media_id空串、created_at=0。

安全建议：限制上传文件大小（AMR约1KB/秒，一般30分钟录音约1.8MB）；校验文件扩展名.amr；URL加key参数简单认证（如`https://server/upload?key=your_secret_key`）；上传目录不设执行权限（防恶意文件执行）。
Nginx反向代理：需调大client_max_body_size（示例50M）；location反代至后端（示例proxy_pass http://127.0.0.1:8080，转发Host/X-Real-IP头）；proxy_connect/send/read_timeout示例均为300。

## 故障排除
| 现象 | 原因 | 方案 |
|------|------|------|
| 返回code=101 | p1参数缺失 | 提供有效录音文件名 |
| 返回code=100 | Token错误 | 核对管理员Token |
| 推送"文件未找到" | 录音文件不存在 | 核对文件名，确认录音已成功录制 |
| 推送"录音已过期" | 录音缓存已过期（设备可能已重启） | 旧录音无法上传 |
| 推送"URL未配置" | 未配置录音上传地址 | 先配置录音上传URL |
| 推送"URL格式错误" | URL格式不正确 | 确保以http/https/smtp开头 |
| 上传长时间无响应 | 网络连接问题 | 检查设备网络，确保可用 |
| 推送696上传失败 | 服务器端问题 | 查服务器日志、URL和权限配置 |
| code=0但服务器没收到文件 | 异步上传进行中 | 确认已启用695/696上报并等结果通知；检查设备网络与URL配置；或直接检查服务器是否收到 |

上传耗时取决于：文件大小（AMR约1KB/秒）、网络状况（WiFi通常比移动网络快）、服务器响应速度。
上传成功判定两种方式：①启用695/696事件收自动推送 ②直接检查服务器是否收到文件。

## 最佳实践
通话结束后尽快上传（避免缓存过期）；启用695/696事件上报监控上传状态；优先WiFi网络上传（省流量且更快）；生产环境用HTTPS；定期清理已上传录音释放存储；上传失败先查网络与服务器配置再重试；服务器端记录上传日志便于排查。

相关：setamrurl/askamrurl=配置/查询录音上传URL（telRecUrl）；telstartrecord=开始录音（录音文件名来源）；695/696=上传结果推送事件。
