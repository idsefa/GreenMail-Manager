# telstoptts - 停止播放TTS语音

## 功能
停止正在播放或等待播放的TTS语音及TTS队列，可选停止后挂断电话。
- 任何状态均可调用（含非通话状态）
- 无TTS时仍返回成功
- 停止正在播放的TTS + 清空等待播放的TTS队列

## 执行流程
1. 校验卡槽：无效→code=101, 未就绪→code=200
2. 检查TTS状态：
   - 有播放中TTS→停止并清空等待队列→**然后检查p2**，p2=1时挂断电话，否则保持通话
   - 仅等待中TTS→标记删除→返回成功(IDLE TTS removed)→**不检查p2**
   - 无TTS→返回成功(No TTS can be stopped)
- p2仅在通话中且有正在播放的TTS被停止时生效；其他情况静默忽略

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| token | 字符型 | 是(HTTP) | 管理员Token，HTTP接口必填；TCP接口无需token |
| cmd | 字符型 | 是 | `telstoptts` |
| p1 | 数值型 | 是 | 卡槽号，有效值：`1`或`2` |
| p2 | 数值型 | 否 | 停止后动作：`0`=保持通话(默认)，`1`=挂断电话；其他值静默忽略，等同于0 |
| tid | 字符型 | 否 | 事务追踪ID，原样返回 |

## 格式

HTTP: `http://<ip>/ctrl?token=<token>&cmd=telstoptts&p1=<slot>&p2=<action>`

TCP（末尾必须附加`0x11 0x12`）: `{"cmd":"telstoptts","p1":1,"p2":0,"tid":"1234"}\x11\x12`

## 响应

公共字段：`type`、`subType`(固定=27)、`code`(0=成功,101=参数格式错误,200=业务错误)、`val`(通常为空串)、`note`、`devId`、`netCh`(网络通道号)、`msgTs`(Unix秒级时间戳)
- type=401：命令已接收/处理中/参数或状态校验失败
- type=402：命令执行完成（仅成功时返回）

### 响应场景

| 场景 | type | code | note |
|------|------|------|------|
| 停止播放中的TTS | 401 | 0 | `telstoptts has been processed...` |
| 删除等待中的TTS | 402 | 0 | `IDLE TTS removed, no playing TTS found.` |
| 无TTS可停止 | 402 | 0 | `No TTS can be stopped.` |
| p1缺失或非数值 | 401 | 101 | `Missing or invalid p1 (slotId): must be a number (1 or 2)` |
| 卡槽未就绪 | 401 | 200 | `Card slot X is not ready yet.` |

## 与telhangup对比
- **telstoptts**：只停止TTS(p2=0保持通话/p2=1挂断)；需继续通话时用
- **telhangup**：挂断整个通话(TTS随通话停止)；结束通话时用

## 实践要点
- 用途：停止无限循环TTS(p3=0)、切换TTS内容、提前结束播报转人工
- 建议显式设p2=0避免误挂断
- TTS未停止可等几秒重试或直接用telhangup
