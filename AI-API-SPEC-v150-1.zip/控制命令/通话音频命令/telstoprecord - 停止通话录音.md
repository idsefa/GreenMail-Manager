# telstoprecord - 停止通话录音

## 功能
通话中手动停止录音，录音文件(AMR格式)自动保存到设备存储，可选立即上报服务器。
- 前提：通话状态=ANSWERING 且 录音状态=RECORDING
- 停止录音不挂断电话（挂断用`telhangup`），停止后可在通话中重新`telstartrecord`
- 录音达最大时长上限(60秒)或通话结束也会自动停止
- 长时间通话可分段录音(stop→start)，重要内容录完及时停止以节省存储

## 执行流程
1. 校验p1(卡槽号)→无效(code=101)；卡槽未就绪(未开机/未初始化)(code=200)
2. 检查通话=ANSWERING且录音=RECORDING→不满足(code=200)
3. 停止录音→保存AMR文件→返回成功(code=0)
4. 若p2=1则立即上传录音到服务器

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| token | 字符型 | 是(HTTP) | 管理员Token，HTTP接口必填；TCP接口无需token |
| cmd | 字符型 | 是 | `telstoprecord` |
| p1 | 数值型 | 是 | 卡槽号：`1`或`2` |
| p2 | 数值型/字符串型 | 否 | 立即上报开关。默认：设备配置或telstartrecord设置值。`1`/`on`/`true`=上报；`0`/`off`/`false`=不上报 |
| tid | 字符型 | 否 | 事务追踪ID，响应中原样返回 |

## 格式
HTTP: `http://<ip>/ctrl?token=<token>&cmd=telstoprecord&p1=<slot>&p2=<upload>`
TCP(末尾`0x11 0x12`): `{"cmd":"telstoprecord","p1":1,"p2":1,"tid":"1234"}\x11\x12`

## 响应
公共字段：`type`、`subType`(固定44)、`code`、`val`(通常为空)、`note`、`devId`(设备标识)、`netCh`(网络通道号)、`msgTs`(Unix秒时间戳)
- type=401: 命令已接收/校验失败
- type=402: 命令执行完成(仅成功)
- code: `0`=成功; `101`=参数错误; `200`=前置条件不满足

| 场景 | type | code | note |
|------|------|------|------|
| 成功(已处理) | 401 | 0 | telstoprecord has been processed... |
| 成功(完成) | 402 | 0 | tel record stop has been succeeded. |
| p1缺失 | 401 | 101 | Missing required parameter: p1 (slotId) |
| p1格式错误 | 401 | 101 | Invalid slotId format: X, expected number (1 or 2) |
| p1无效 | 401 | 101 | Invalid slot ID: X. Valid range: 1-2 |
| 卡槽未就绪 | 401 | 200 | Card slot X is not ready yet. |
| 无录音/非通话 | 401 | 200 | No recording in progress or call not in answering state. |
| 无活动通话记录 | 401 | 200 | No active call record found. |

## 录音生命周期
IDLE→(telstartrecord)→RECORD_PREPAIR→RECORDING→(telstoprecord)→STOP_PREPAIR→STOPED→(保存完成)→IDLE
RECORDING也可因达时长上限(≤60s)或通话结束自动→STOPED

## 运行时故障
| 故障 | 原因 | 解决 |
|------|------|------|
| 录音文件损坏 | 断电或存储异常 | 检查电源和存储状态，必要时重新录音 |
| 录音未上传 | 未配上报或网络异常 | 检查p2和网络，用`telrecordupload`手动上传 |
| 命令无响应 | 设备异常 | 检查设备状态/日志，必要时重启模块 |
