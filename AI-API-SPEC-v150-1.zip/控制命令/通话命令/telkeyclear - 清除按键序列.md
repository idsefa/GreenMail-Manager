# telkeyclear - 清除按键序列

清除通话中按键队列里尚未执行的DTMF按键序列。指定p2→仅清除匹配tid的按键序列；省略p2→清除该卡槽所有按键序列。正在执行中的按键正常完成后停止；尚未开始的立即标记为删除。

## 命令格式

**HTTP：** `http://{设备IP}/ctrl?token={管理员Token}&cmd=telkeyclear&p1={卡槽号}[&p2={按键序列tid}]`

**TCP：** `{"cmd":"telkeyclear", "p1":{卡槽号}[, "p2":"{按键序列tid}", "tid":"{请求ID}"]}\x11\x12`
TCP消息末尾必须附加2字节结束符 `0x11 0x12`。

**示例：**
- 清除卡槽1所有按键：`...&cmd=telkeyclear&p1=1`
- 清除卡槽2所有按键：`...&cmd=telkeyclear&p1=2`
- 清除指定tid：`...&cmd=telkeyclear&p1=1&p2=abc123`
- TCP：`{"cmd":"telkeyclear", "p1":1, "p2":"order001", "tid":"req123"}\x11\x12`

## 参数

| 参数 | 类型 | 必填 | 说明 |
| --- | --- | --- | --- |
| token | 字符型 | 是(HTTP) | 管理员Token，HTTP接口必填；TCP接口无需token |
| cmd | 字符型 | 是 | 固定值 `telkeyclear` |
| p1 | 数值型 | 是 | 卡槽号，有效值：1或2 |
| p2 | 字符型 | 否 | 要清除的按键序列tid，省略则清除该卡槽所有按键序列 |
| tid | 字符型 | 否 | 事务追踪ID，携带时在响应中原样返回 |

## 返回码

| 返回码 | 含义 |
| --- | --- |
| 0 | 成功 |
| 100 | Token错误 |
| 101 | 参数格式错误（缺失/无效卡槽号） |
| 200 | 业务错误（卡槽未就绪/无通话进行中） |
| 999 | 未知错误 |

## 响应

subType固定为22。type=401：命令已接收（含处理中）或参数/状态校验失败；type=402：命令执行完成（仅成功时）。

**成功（type=402, code=0）：**
```json
{"type":402,"subType":22,"code":0,"val":"","note":"telkeyclear has been succeeded.","devId":"c3dd382801","netCh":0,"msgTs":1704067200}
```

**参数格式错误（type=401, code=101）：**
```json
{"type":401,"subType":22,"code":101,"val":"","note":"Missing or invalid p1 (slotId): must be a number (1 or 2)"}
```

**无效卡槽号（type=401, code=101）：**
```json
{"type":401,"subType":22,"code":101,"val":"","note":"Invalid slot id: 3"}
```

**卡槽未就绪（type=401, code=200）：**
```json
{"type":401,"subType":22,"code":200,"val":"","note":"Card slot 1 is not ready yet."}
```

**无通话进行中（type=401, code=200）：**
```json
{"type":401,"subType":22,"code":200,"val":"","note":"No calls are available."}
```

**响应字段：** type(401/402) | subType(固定22) | code(返回码) | val(通常为空) | note(结果描述) | devId(设备ID) | netCh(网络通道号) | msgTs(Unix时间戳秒)

## 技术细节

- **清除规则**：正在执行的（已通过AT+VTS发送到4G模块）正常完成；等待/尚未开始的立即标记为删除
- **p2来源**：p2对应telkeypress命令中TCP接口指定的tid；HTTP发送的按键tid为空，只能通过省略p2清除所有按键
- **清除后可继续发送telkeypress**
- **通话挂断后系统自动清除该通话所有按键队列**
- **不影响通话**：仅清除未发送按键，已发送按键不撤销

## 典型用法

- **动态IVR导航**：telkeypress(p2=P1P2P3) → 菜单变化 → telkeyclear(清空) → telkeypress(p2=P1P4)
- **按tid精确清除**：TCP发key(tid=A) → TCP发key(tid=B) → telkeyclear(p2=B)，A继续执行
- **紧急取消**：telkeyclear(p1=槽号，清空所有) → 重新发送正确按键序列
