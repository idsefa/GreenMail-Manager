# storetelen - 设置/查询通话存储开关

设置或查询各卡槽的通话记录存储开关。开启后，该卡槽的通话记录（来电/去电/未接）保存到本地数据库，可通过querytel命令查询。**设置后需用restart命令重启设备才生效**。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `storetelen` |
| p1 | number | 否 | 卡槽号。`0`=所有卡槽、`1`=卡槽1、`2`=卡槽2。省略→查询模式 |
| p2 | string | 否 | 存储开关。`on`/`1`/`true`=开启、`off`/`0`/`false`=关闭。省略→查询模式 |
| token | string | HTTP必填 | 管理员Token，HTTP接口必填；TCP接口无需token |
| tid | string | 否 | 可选。事务追踪ID，携带时会在响应消息中原样返回，用于关联请求与响应 |

> p1和p2须同时提供或同时省略。仅提供其中一个时，设备自动进入查询模式。

## 接口格式

- **HTTP查询**: `http://<ip>/ctrl?token=<token>&cmd=storetelen`
- **HTTP设置**: `http://<ip>/ctrl?token=<token>&cmd=storetelen&p1=<slot>&p2=<switch>`
- **TCP**: `{"cmd":"storetelen","p1":1,"p2":"on","tid":"1234"}\x11\x12`（末尾附加0x11 0x12）

## 响应机制

type区分：401=设备已收到命令（处理中或处理前发现错误如Token无效/参数格式错误）；402=执行完成并返回结果。subType固定为33。

## 响应码

| code | 含义 | 触发条件 | note |
|------|------|----------|------|
| 0 | 成功 | 查询返回当前状态；设置成功，提示需重启 | 查询: "Slot X TEL storage ON/OFF;Slot Y TEL storage ON/OFF"；设置: "Slot/All slot ... TEL storage has been changed, restart required." |
| 100 | Token错误 | token无效或已过期 | "Invalid token." |
| 101 | 参数格式错误 | p1非0/1/2，或p2非on/off/true/false/1/0 | "p1 (slotId) must be 0, 1 or 2; p2 must be 'on' or 'off'" |
| 999 | 配置保存失败 | 文件写入失败（存储空间不足或文件系统错误） | "Failed to write config file!" |

## 响应示例

**查询(type=402)**:
```json
{"type":402,"subType":33,"code":0,"val":"1:on;2:off","note":"Slot 1 TEL storage ON;Slot 2 TEL storage OFF","devId":"c3dd382801","netCh":0,"msgTs":1773644002}
```

**设置单卡槽成功(type=402)**:
```json
{"type":402,"subType":33,"code":0,"val":"1:on","note":"Slot 1 TEL storage has been changed, restart required.","devId":"c3dd382801","netCh":0,"msgTs":1773644009}
```

**设置卡槽2成功(type=402)**:
```json
{"type":402,"subType":33,"code":0,"val":"2:off","note":"Slot 2 TEL storage has been changed, restart required.","devId":"c3dd382801","netCh":0,"msgTs":1773644015}
```

**设置所有卡槽成功(type=402)**:
```json
{"type":402,"subType":33,"code":0,"val":"1:on;2:on","note":"All slot TEL storage has been changed, restart required.","devId":"c3dd382801","netCh":0,"msgTs":1773644024}
```

**参数格式错误(type=401)**:
```json
{"type":401,"subType":33,"code":101,"val":"","note":"p1 (slotId) must be 0, 1 or 2; p2 must be 'on' or 'off'","netCh":0,"msgTs":1773644134}
```

**Token错误(type=401)**:
```json
{"type":401,"code":100,"note":"Invalid token."}
```

**配置保存失败(type=402)**:
```json
{"type":402,"subType":33,"code":999,"val":"","note":"Failed to write config file!","devId":"c3dd382801","netCh":0,"msgTs":1773644200}
```

## 响应字段

| 字段 | 类型 | 说明 |
|------|------|------|
| type | number | 401=处理中或处理前错误；402=执行完成 |
| subType | number | 固定值33 |
| code | number | 返回码（见上表） |
| val | string | 各卡槽开关状态，格式`{卡槽号}:{状态}`，多卡槽用`;`分隔 |
| note | string | 操作结果描述（英文） |
| devId | string | 设备唯一标识符 |
| netCh | number | 网络通道标识 |
| msgTs | number | Unix时间戳 |

## 处理流程

1. 判断模式：p1和p2都存在→设置模式；任一缺失→查询模式
2. **查询模式**：读取当前配置，返回各卡槽状态（code=0, type=402）
3. **设置模式**：
   - 校验参数：p1非0/1/2或p2无效→code=101（type=401）
   - 修改内存配置（p1=0时同时设置卡槽1和卡槽2）
   - 保存配置到文件：失败→code=999（type=402）；成功→code=0（type=402），提示需重启
   - **配置保存成功后，需使用restart命令重启设备，新配置才会生效**

## 注意事项

- 设备支持2个卡槽
- 通话记录库最大50条，超出自动覆盖最旧记录
- 存储开关是统一开关，不能单独控制来电/去电/未接类型
- 关闭存储后新通话不保存，但已保存的记录不受影响
- 参数缺失（查询模式，code=0, type=402）≠参数格式错误（code=101, type=401）
- 相关命令：querytel（查询通话记录）、restart（重启设备使配置生效）、storesmstelen（同时设置短信和通话存储开关）
