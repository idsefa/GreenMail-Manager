# telkeypress - 本地电话按键

通话中模拟本机DTMF按键（用于IVR语音导航等）。

## 按键字符

有效字符：`0-9`(数字), `A-D`(DTMF扩展, a-d自动转大写), `*#`(特殊键)
暂停符：`p`=1000ms, `P`=5000ms, `m`=100ms, `M`=500ms

规则：无效字符自动过滤；按暂停符分割逐段发送；连续段(不含暂停符)最长30字符，超长自动分割。

示例：`1`→发1 | `12345`→1,2,3,4,5 | `P1pp2`→等5s,1,等2s,2 | `123456#P1`→123456#,等5s,1 | `1P2pp3mM4`→1,等5s,2,等2s,3,等0.6s,4

## 命令格式

HTTP: `http://{IP}/ctrl?token={token}&cmd=telkeypress&p1={卡槽}&p2={按键}[&p3={音时长}]`
TCP: `{"cmd":"telkeypress","p1":{卡槽},"p2":"{按键}"}[, "p3":"{音时长}"][, "tid":"{ID}"]\x11\x12`
（TCP末尾必须附加0x11 0x12）

### 参数

| 参数 | 类型 | 必填 | 说明 |
|---|---|---|---|
| token | 字符 | 是(HTTP) | 管理员Token，HTTP接口必填；TCP接口无需token |
| cmd | 字符 | 是 | 固定`telkeypress` |
| p1 | 数值 | 是 | 卡槽号：1或2 |
| p2 | 字符 | 是 | 按键序列，无效字符自动过滤 |
| p3 | 数值 | 否 | 按键音时长(ms)，范围1-255，默认200 |
| tid | 字符 | 否 | 事务追踪ID，响应中原样返回 |

## 执行流程

p1校验(无效→code101) → 卡槽状态(未就绪→code200, 非通话→code200) → p2校验(无有效按键→code101) → 过滤无效字符 → 按暂停符分割 → 加入按键队列 → code0成功

## 返回码

| code | 含义 | note |
|---|---|---|
| 0 | 成功，按键已入队 | telkeypress has been processed... |
| 100 | Token错误 | Token无效或缺失 |
| 101 | 参数格式错误(缺失/格式不正确/无效p1, 无有效按键) | Missing or invalid p1... / Invalid slotId: X / No valid DTMF keys provided. |
| 200 | 业务错误(卡槽未就绪/无通话) | Card slot X is not ready yet. / No calls are available. |
| 999 | 未知错误 | 其他未分类的错误 |

## 响应

公共字段: type(401=已接收/处理中/校验失败, 402=执行完成仅成功), subType(固定25), code, val(通常为空字符串), note, devId, netCh, msgTs(Unix时间戳秒)

成功(402): `{"type":402,"subType":25,"code":0,"val":"","note":"telkeypress has been processed...","devId":"c3dd382801","netCh":0,"msgTs":1704067200}`
p1缺失/非数字(401,101): `{"type":401,"subType":25,"code":101,"note":"Missing or invalid p1 (slotId): must be a number (1 or 2)",...}`
p1超范围(401,101): `{"type":401,"subType":25,"code":101,"note":"Invalid slotId: 3",...}`
p2无有效按键(401,101): `{"type":401,"subType":25,"code":101,"note":"No valid DTMF keys provided.",...}`
卡槽未就绪(401,200): `{"type":401,"subType":25,"code":200,"note":"Card slot 1 is not ready yet.",...}`
无通话进行中(401,200): `{"type":401,"subType":25,"code":200,"note":"No calls are available.",...}`

（`...`表示其余公共字段同成功示例）

## 技术细节

- 多次调用追加队列按序执行; 用`telkeyclear`清除未执行按键
- DTMF与TTS播放互不干扰; 复杂导航分多次发送
- p3建议100-300ms(过短对方无法识别，过长影响总时间)
- 按键不生效排查: 确认通话中(已接通)、按键有效(0-9,A-D,*,#)、检查返回code
