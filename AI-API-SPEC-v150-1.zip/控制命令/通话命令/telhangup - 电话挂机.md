# telhangup - 电话挂机

控制指定卡槽立即挂断当前通话。拨号中/振铃中/通话中/无通话均可执行。挂机后自动异步清理TTS/录音/DTMF并推送6xx通知。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `telhangup` |
| p1 | number | 是 | 卡槽号(1或2)，缺失/非数字/超出范围→code=101 |
| token | string | 是(HTTP) | 管理员Token，HTTP接口必填；TCP接口无需token |
| tid | string | 否 | 事务追踪ID，响应中原样返回 |

## 接口格式

- HTTP: `http://<ip>/ctrl?token=<token>&cmd=telhangup&p1=<slot>`
- TCP: `{"cmd":"telhangup","p1":<slot>,"tid":"<tid>"}\x11\x12`（末尾0x11 0x12）

## 响应

异步命令，subType=24。type区分：401(已接收/处理中)、402(执行完成)。

| type | code | 触发条件 | note |
|------|------|----------|------|
| 401 | 0 | 命令已处理 | telhangup has been processed... |
| 401 | 101 | p1缺失或非数字 | Missing or invalid p1 (slotId): must be a number (1 or 2) |
| 401 | 101 | p1超出1-2范围 | Invalid slotId: X |
| 401 | 200 | 卡槽未就绪(模块未启动) | Card slot X is not ready yet. |
| 402 | 200 | 当前无通话(ATH失败) | Failed to hang up the call. |

响应字段：type、subType、code、val(通常为空；402/200时为"ERROR")、note、netCh(网络通道)、msgTs(Unix时间戳秒)。

## 处理流程

1. 校验p1(缺失/非数字→101) → 校验范围(非1/2→101) → 检查卡槽就绪(未就绪→200) → 发送ATH → 返回code=0
2. 异步清理(非同步操作，确保响应及时性)：停止TTS+清队列 → 停止录音(p11=1则自动上报，否则需手动telrecordupload) → 清除DTMF按键序列 → 重置电话状态IDLE
3. 推送6xx通知

## 6xx挂机通知

通话结束时(本地或对方挂机)推送。type区分方向：603(来电/被叫结束)、623(呼出/主叫结束)。
推送时机：本地主动挂机100-500ms内；对方挂断由运营商信令决定(已接通1-2s，未接通/拒接/无应答可能30-60s)；4G网络挂机信令传输延迟通常1-2s内。

| 字段 | 类型 | 说明 |
|------|------|------|
| devId | string | 设备ID |
| slot | number | 卡槽号(1或2) |
| type | number | 603=来电结束, 623=呼出结束 |
| netCh | number | 网络通道 |
| msgTs | number | 消息时间戳(秒) |
| imsi | string | SIM卡IMSI |
| iccId | string | SIM卡ICCID |
| msIsdn | string | 本机号码 |
| scName | string | 运营商 |
| phNum | string | 对方号码 |
| charset | string | 编码 |
| telStartTs | number | 开始时间戳(秒) |
| telOutBoundRingTs | number | 呼出振铃时间戳(秒)，仅type=623 |
| telConnectedTs | number | 接通时间戳(秒) |
| telEndTs | number | 结束时间戳(秒) |
| tid | string | 命令传入的事务ID(如有) |

## 注意

- 重复执行：ATH重复发送，无通话时返回type=402 code=200可安全忽略
- code=200(卡槽未就绪)时：等5-10s重试或先slotrst重启卡槽
- 建议携带tid追踪结果，等6xx消息后再做后续操作
- 外呼场景建议teldial设p3(通话时长限制)自动挂机
