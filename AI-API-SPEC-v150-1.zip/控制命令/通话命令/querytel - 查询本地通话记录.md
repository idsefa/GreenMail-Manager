# querytel - 查询本地通话记录

分页查询开发板本地通话库（最大50条，滚动覆盖最旧记录，按时间降序，最新在前）。**前提：需通过storetelen命令开启通话存储（默认关闭）。**

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `querytel` |
| p1 | number | 是 | 起始位置offset，从第N条开始返回（1-based编号）。offset<1时视为1（从第1条开始）。超过总记录数返回空results不报错 |
| p2 | number | 是 | 查询条数limit。有效值1~50（含边界） |
| p3 | number | 否 | 通话类型过滤。`0`=所有(默认)、`1`=来电(dir=0,含已接和漏接)、`2`=外呼(dir=1)、`3`=漏接(dir=0,conn=0)。非0/1/2/3值视为0，不报错 |
| p4 | string | 否 | 号码关键字（模糊匹配，区分大小写，部分匹配如"138"可匹配"13800138000"）。省略或空/空白字符串→不过滤 |
| p5 | number | 否 | 卡槽号过滤。`1`=仅卡槽一，`2`=仅卡槽二。省略/为空→不过滤所有卡槽。非法值→code=101。仅双卡版本有意义 |
| token | string | HTTP必填 | 管理员Token，HTTP接口必填；TCP接口无需token |
| tid | string | 否 | 事务追踪ID，原样返回用于关联请求与响应 |

## 接口格式

- **HTTP**: `http://<ip>/ctrl?token=<token>&cmd=querytel&p1=<offset>&p2=<limit>[&p3=<type>][&p4=<keyword>][&p5=<slotId>][&tid=<tid>]`
- **TCP**: `{"cmd":"querytel","p1":0,"p2":10,"p3":1,"p4":"138","p5":1,"tid":"1234"}\x11\x12`（末尾必须附加0x11 0x12）

## 响应机制

type区分：401=命令收到但参数错误，402=命令执行完成。subType固定31。

## 错误码

| code | 含义 | 触发条件 |
|------|------|----------|
| 0 | 成功 | 查询成功（含存储未开启返回空结果） |
| 100 | Token错误 | token无效或已过期 |
| 101 | 参数格式错误 | p1/p2缺失或p1<0或p2<1或p2>50；p5非法(非1或2) |
| 200 | 通用错误 | 内部处理错误（如JSON序列化失败） |

## 响应示例

**成功(type=402)**:
```json
{"subType":31,"code":0,"offset":"0","limit":"3","callType":0,"qkey":"","slotId":0,"results":[{"slot":1,"dir":0,"phNum":"053256894747","telStartTs":1751421911,"telEndTs":1751421941,"conn":1},{"slot":2,"dir":1,"phNum":"13855668899","telStartTs":1751267248,"telEndTs":1751267251,"conn":0},{"slot":1,"dir":0,"phNum":"8613316582441","telStartTs":1751266780,"telEndTs":1751266787,"conn":0}],"devId":"e51e9881265a3c8","type":402,"netCh":0,"msgTs":1751461200}
```

**参数缺失(type=401)**:
```json
{"subType":31,"code":101,"val":"","note":"Missing required parameter(s): p1 (offset) or p2 (limit)","type":401,"netCh":0,"msgTs":1751461200}
```

**p5 slotId非法(type=401)**:
```json
{"subType":31,"code":101,"val":"3","note":"slotId must be 1 or 2","type":401,"netCh":0,"msgTs":1751461200}
```

**参数超出范围(type=401)**:
```json
{"subType":31,"code":101,"val":"0,31","note":"Offset must be >= 0, limit <= 50","type":401,"netCh":0,"msgTs":1751461200}
```

**返回空结果(type=402,code=0，存储未开启/无匹配/offset超限)**:
```json
{"subType":31,"code":0,"offset":"0","limit":"10","callType":0,"qkey":"","slotId":0,"results":[],"devId":"e51e9881265a3c8","type":402,"netCh":0,"msgTs":1751461200}
```

## 响应字段

**响应头**:

| 字段 | 类型 | 说明 |
|------|------|------|
| subType | number | 固定值31 |
| code | number | 0=成功，101=参数错误 |
| offset | string | 当前起始位置（与p1一致，1-based） |
| limit | string | 当前条数限制（与p2一致） |
| callType | number | 查询通话类型（与p3一致） |
| qkey | string | 号码关键字（与p4一致） |
| slotId | number | 卡槽过滤条件：0=不过滤、1=仅卡槽一、2=仅卡槽二 |
| results | array | 通话记录数组 |
| devId | string | 设备唯一ID |
| type | number | 401=命令收到(错误)，402=执行完成 |
| netCh | number | 网络通道。0=WiFi，1=SIM1，2=SIM2 |
| msgTs | number | 消息时间戳（Unix秒） |

**通话记录(results数组元素)**:

| 字段 | 类型 | 说明 |
|------|------|------|
| slot | number | 卡槽号。1=卡槽一，2=卡槽二 |
| dir | number | 通话方向。0=来电(呼入)，1=外呼(呼出) |
| phNum | string | 通话号码。匿名来电="anonymous" |
| telStartTs | number | 通话开始时间戳（Unix秒） |
| telEndTs | number | 通话结束时间戳（Unix秒）。通话时长=telEndTs-telStartTs(秒) |
| conn | number | 是否接通。0=未接通（来电=漏接，外呼=对方未接），1=已接通 |

## 分页机制

offset/limit模式。**实际返回条数可能比limit多1条**：返回≤limit条→末尾无更多；返回=limit+1条→还有更多可继续查询。

## 处理流程

1. 存储未开启→返回空结果(code=0, type=402)
2. 参数校验→p1/p2缺失(code=101,note="Missing...")；p1<0或p2∉[1,50](code=101,note="Offset...")；p5非1或2(code=101,note="slotId...")→均type=401
3. 按时间降序查询通话库
4. p3筛选通话类型（非0/1/2/3→视为0）
5. p4筛选包含关键字的号码（模糊匹配，区分大小写）
6. p5筛选指定卡槽
7. 返回结果(code=0, type=402)


