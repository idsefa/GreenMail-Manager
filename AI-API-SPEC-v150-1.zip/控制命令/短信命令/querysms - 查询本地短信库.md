# querysms - 查询本地短信库

分页查询本地短信库。短信存储(storesmsen)**默认关闭**，开启后保存新短信；关闭后新短信不保存但历史仍可查。库最大100条(超出覆盖最旧)，按时间降序。单次最多返回50条。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | `querysms` |
| p1 | number | 是 | 起始位置offset(1-based)，从第N条开始返回，<1视为1。可超总数→空数组不报错 |
| p2 | number | 是 | limit(条数)，1~50 |
| p3 | string | 否 | 关键字过滤(模糊匹配,区分大小写)。省略/空/空白→不过滤 |
| p4 | number | 否 | 卡槽过滤:1=卡槽一,2=卡槽二。省略/空→不过滤。非法值→code=101。仅双卡版本有效 |
| token | string | HTTP必填 | 管理员Token，HTTP接口必填；TCP接口无需token |
| tid | string | 否 | 事务追踪ID，原样返回 |

## 接口

- HTTP: `GET /ctrl?token=<t>&cmd=querysms&p1=<offset>&p2=<limit>[&p3=<keyword>][&p4=<slotId>]`
- TCP: `{"cmd":"querysms","p1":0,"p2":10}\x11\x12`（末尾附加0x11 0x12）

## 响应

subType=30。type:401=处理前错误,402=执行完成(含成功和空结果)。

| code | 含义 | 触发条件 |
|------|------|----------|
| 0 | 成功 | 含空结果 |
| 100 | Token错误 | token无效/过期 |
| 101 | 参数错误 | p1/p2缺失或p1<0或p2∉[1,50];p4非法(非1或2,note="slotId must be 1 or 2") |
| 200 | 通用错误 | 内部错误(如JSON序列化失败) |

### 分页机制
实际返回条数可能比limit多1条，用于判断后续：≤limit→末尾；=limit+1→还有更多。

### 响应示例

**成功(type=402)**:
```json
{"subType":30,"code":0,"qkey":"","offset":"0","limit":"10","slotId":0,
 "results":[{"slot":1,"dir":0,"phNum":"10691021560051","smsBd":"【火山引擎】...","smsTs":1751453195},
            {"slot":1,"dir":0,"phNum":"10691009096368","smsBd":"【河北银行】...","smsTs":1751428444}],
 "devId":"e51e9881265a3c8","type":402,"netCh":0,"msgTs":1751460187}
```

**参数缺失(type=401)**: `{"subType":30,"code":101,"val":"","note":"Missing required parameter(s): p1 (offset) or p2 (limit)","type":401,...}`

**p4非法(type=401)**: `{"subType":30,"code":101,"val":"3","note":"slotId must be 1 or 2","type":401,...}`

**参数超范围(type=401)**: `{"subType":30,"code":101,"val":"0,21","note":"Offset must be >= 0, limit <= 50","type":401,...}`

**空结果(type=402)**: `{"subType":30,"code":0,"qkey":"","offset":"0","limit":"10","slotId":0,"results":[],"devId":"...","type":402,...}`

## 响应字段

| 字段 | 类型 | 说明 |
|------|------|------|
| type | number | 401=处理前错误;402=执行完成 |
| subType | number | 固定30 |
| code | number | 见上 |
| qkey | string | 查询关键字(=p3) |
| offset | string | 当前起始位置(=p1，1-based) |
| limit | string | 当前条数(=p2) |
| slotId | number | 卡槽过滤:0=不过滤,1=卡槽一,2=卡槽二 |
| note | string | 错误描述(英文) |
| val | string | 错误详情。参数超范围→"offset,limit"(如"0,21")；p4非法→非法值(如"3") |
| devId | string | 设备ID |
| netCh | number | 0=WiFi,1=SIM1,2=SIM2 |
| msgTs | number | Unix秒级时间戳 |

**results数组元素**:

| 字段 | 类型 | 说明 |
|------|------|------|
| slot | number | 1=卡槽一,2=卡槽二 |
| dir | number | 0=接收,1=发送 |
| phNum | string | 短信号码 |
| smsBd | string | 短信正文(可能含特殊字符,可能较长) |
| smsTs | number | 短信Unix秒级时间戳 |

## 处理流程

1. 校验→p1/p2缺失或p1<0或p2∉[1,50]→code=101(type=401)
2. p4非法(非1或2)→code=101(type=401,note="slotId must be 1 or 2")
3. 按时间降序查库
4. p3非空→模糊匹配过滤(区分大小写)
5. p4非空→卡槽过滤
6. 返回code=0(type=402)

## 注意

- p4仅双卡版本有意义，单卡传入无效但不报错
- 相关命令：storesmsen(存储开关)
