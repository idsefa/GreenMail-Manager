# storesmsen - 设置/查询短信存储开关

设置或查询各卡槽短信存储开关。开启后该卡槽收到/发送的短信保存到本地数据库(最大100条,超出覆盖最旧),可通过querysms查询。**设置后需用restart重启才生效**。关闭后新短信不保存,已保存的不受影响。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | `storesmsen` |
| p1 | number | 否 | 卡槽号:`0`=所有,`1`=卡槽1,`2`=卡槽2。省略→查询 |
| p2 | string | 否 | 开关:`on`/`1`/`true`=开,`off`/`0`/`false`=关(不区分大小写)。省略→查询 |
| token | string | HTTP必填 | 管理员Token，HTTP接口必填；TCP接口无需token |
| tid | string | 否 | 事务追踪ID,原样返回 |

> p1和p2建议同时提供或同时省略。仅提供其中一个→设备自动进入查询模式。

## 接口

- **HTTP查询**: `GET /ctrl?token=<t>&cmd=storesmsen`
- **HTTP设置**: `GET /ctrl?token=<t>&cmd=storesmsen&p1=<slot>&p2=<switch>`
- **TCP**: `{"cmd":"storesmsen","p1":1,"p2":"on","tid":"1234"}\x11\x12`

> TCP消息末尾须附加2字节结束符 `0x11 0x12`。

## 响应

subType=32。type:401=设备已收到命令(正常处理中或处理前错误如Token无效/参数格式错误);402=执行完成并返回结果。

| code | 含义 | 触发条件 | note |
|------|------|----------|------|
| 0 | 成功 | 查询→返回状态;设置→提示需重启 | 查询:`Slot X SMS storage ON/OFF`;设置:`Slot X/All slot SMS storage has been changed, restart required.` |
| 100 | Token错误 | token无效/过期。可通过管理页面重置 | `Invalid token.` |
| 101 | 参数格式错误 | p1∉{0,1,2}或p2非法 | `p1 (slotId) must be 0, 1 or 2; p2 must be 'on' or 'off'` |
| 999 | 配置保存失败 | 文件写入失败(存储空间不足或文件系统错误)。可尝试恢复出厂设置 | `Failed to write config file!` |

### 响应示例

**查询成功(type=402,code=0)**:
```json
{"type":402,"subType":32,"code":0,"val":"1:on;2:off","note":"Slot 1 SMS storage ON;Slot 2 SMS storage OFF","devId":"c3dd382801","netCh":0,"msgTs":1773643959}
```

**设置单卡槽成功(type=402,code=0)**: val=`"1:on"`, note=`"Slot 1 SMS storage has been changed, restart required."`

**设置所有卡槽成功(type=402,code=0)**: val=`"1:on;2:on"`, note=`"All slot SMS storage has been changed, restart required."`

**参数错误(type=401,code=101)**: val=`""`, note=`"p1 (slotId) must be 0, 1 or 2; p2 must be 'on' or 'off'"`

**Token错误(type=401,code=100)**: `{"type":401,"code":100,"note":"Invalid token."}`

**配置保存失败(type=402,code=999)**: val=`""`, note=`"Failed to write config file!"`

### 响应字段

> Token验证失败(code=100)仅返回type/code/note三个字段，其余响应返回全部字段。

| 字段 | 类型 | 说明 |
|------|------|------|
| type | number | 401/402 |
| subType | number | 固定32 |
| code | number | 返回码 |
| val | string | 成功时`{卡槽号}:{状态}`,多卡槽用`;`分隔;错误时为空 |
| note | string | 结果描述(英文) |
| devId | string | 设备ID |
| netCh | number | 网络通道 |
| msgTs | number | Unix时间戳 |

## 处理流程

1. p1和p2都存在→设置模式;任一缺失→查询模式(返回code=0,type=402)
2. 设置模式:校验参数→p1非法或p2无效→code=101(type=401)
3. p1=0时同时设置卡槽1和2
4. 修改内存配置→保存到文件→失败code=999(type=402)
5. 保存成功→code=0(type=402),提示需restart

## 注意

- 设备支持2个卡槽
- 参数缺失(查询,code=0,type=402) ≠ 参数格式错误(code=101,type=401)
- 查询结果与预期不符→确认是否已重启设备
- 相关命令:querysms(查询短信库)、restart(重启使配置生效)
