# sendsms - 控制SIM卡外发短信

通过指定卡槽的SIM卡向外发送短信。异步命令：先返回401(已收到/参数错误)，发送成功时推送402(成功中间消息，val携带送达ID)+502(成功报告，含送达ID)，失败时推送402(失败报告)。若已启用503消息（默认不启用），运营商确认送达结果后还会推送503（短信外发送达报告）。

## 参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| cmd | string | 是 | 固定值 `sendsms` |
| p1 | number | 是 | 卡槽号。有效值：1、2 |
| p2 | string | 是 | 接收方手机号。支持国内11位手机号或运营商短号，不能为空 |
| p3 | string | 是 | 短信内容。不能为空（前后空白字符会被自动去除）；建议≤70汉字（超出自动拆分为长短信） |
| token | string | HTTP必填 | 管理员Token，HTTP接口必填；TCP接口无需token |
| tid | string | 强烈建议 | 命令唯一标识。省略时502/402消息中不含tid字段，但仍会推送消息 |

## 接口格式

- **HTTP**: `http://<ip>/ctrl?token=<token>&cmd=sendsms&p1=<slot>&p2=<phone>&p3=<content>&tid=<tid>`
- **TCP**: `{"cmd":"sendsms","p1":1,"p2":"10086","p3":"查话费","tid":"1647344840"}\x11\x12`

> HTTP请求中p3含中文时必须UTF-8 URL编码（如`p3=%E6%9F%A5%E8%AF%9D%E8%B4%B9`），TCP接口无需编码。TCP消息末尾附加2字节结束符 `0x11 0x12`。

## 响应机制

type区分：401=设备已收到命令（处理中或处理前错误如Token无效/参数错误）；402=短信发送结果报告（code=0成功中间消息，val=送达ID；code=200失败报告）；502=短信外发成功报告（仅在发送成功时推送，smsSendMr=送达ID）；503=短信外发送达报告（**默认不启用**，运营商确认对方是否收到后推送，smsSendMr与502一致、smsSt为送达结果，详见503消息文档）。subType固定为16。

## 响应码

| code | 含义 | 触发条件 |
|------|------|----------|
| 0 | 已接收，发送中 | 参数正确，已加入发送队列 |
| 100 | Token错误 | token无效或已过期 |
| 101 | 参数格式错误 | p1非数字/非1或2、p2为空、p3为空。note含具体错误描述 |
| 200 | 一般性错误 | 卡槽无服务/模块未就绪/发送失败，具体见note字段 |

## 响应示例

**成功接收(type=401)**:
```json
{"subType":16,"code":0,"val":"","note":"sending...","devId":"c3dd382801","type":401,"netCh":0,"msgTs":1704038500,"tid":"1704038500"}
```

**参数错误(type=401)**:
```json
{"subType":16,"code":101,"val":"","note":"p1 (slotId) must be 1 or 2","devId":"c3dd382801","type":401,"netCh":0,"msgTs":1704038501,"tid":"1704038501"}
```
> note内容因具体错误而异，可能值：
> - `"Missing required parameter(s): p2 (phone number)"` — 仅列出实际缺失的参数
> - `"Missing required parameter(s): p1 (slotId), p3 (SMS body)"` — 多个参数缺失时逗号分隔
> - `"p1 (slotId) must be 1 or 2"`
> - `"p2 (phone number) must not be empty"`
> - `"p3 (SMS body) must not be empty"`
> - `"Invalid p1 (slotId): must be 1 or 2"`

**Token错误(type=401)**:
```json
{"type":401,"code":100,"note":"Invalid token."}
```

**卡槽无服务(type=401)**:
```json
{"subType":16,"code":200,"val":"","note":"slot no service!","devId":"c3dd382801","type":401,"netCh":0,"msgTs":1704038502,"tid":"1704038502"}
```

**发送队列加入失败(type=401)**:
```json
{"subType":16,"code":200,"val":"","note":"Failed to send SMS.","devId":"c3dd382801","type":401,"netCh":0,"msgTs":1704038503,"tid":"1704038503"}
```

## 响应字段

| 字段 | 说明 |
|------|------|
| type | 401=异步命令响应（设备已收到命令） |
| subType | 固定值16 |
| code | 0=成功，其他=错误 |
| note | 状态描述 |
| val | 附加值，通常为空 |
| devId | 设备唯一ID |
| netCh | 0:WiFi, 1:SIM1, 2:SIM2 |
| msgTs | 消息Unix时间戳 |
| tid | 与请求中的tid一致 |

## 502消息（短信外发成功报告）

短信发送成功后推送：

```json
{"devId":"c3dd382801","slot":1,"type":502,"netCh":0,"msgTs":1775819726,"imsi":"460115191424604","iccId":"89860323045722121668","msIsdn":"18042358983","scName":"湖州电信(卡)","phNum":"10086","smsBd":"查询余额","tid":"1647344840","charset":"utf8","devSmsTs":1704038400,"smsSendMr":[171]}
```

| 字段 | 说明 |
|------|------|
| type | 502=短信外发成功报告 |
| devId | 设备唯一ID |
| slot | 发送卡槽号（1或2） |
| netCh | 0:WiFi, 1:SIM1, 2:SIM2 |
| msgTs | 消息时间戳 |
| imsi | SIM卡IMSI号 |
| iccId | SIM卡ICCID号 |
| msIsdn | SIM卡手机号 |
| scName | SIM卡运营商名称 |
| phNum | 接收方手机号 |
| smsBd | 短信内容（前后空白字符已被自动去除） |
| tid | 与命令中的tid一致（省略tid时不包含此字段） |
| charset | 固定值"utf8" |
| devSmsTs | 短信实际发出时间（Unix时间戳）。**默认不启用**，需在设备后台"系统参数管理"中启用后才会出现 |
| smsSendMr | **短信外发送达ID**。单条短信1个（如`[171]`）；长短信每条子短信各1个（如`[171,172]`，顺序与发送顺序一致）。用于与503消息配对确认送达 |

## 402消息（短信发送结果报告）

短信发送完成后（无论成功或失败），设备会推送type=402消息。

**发送成功中间消息**（val携带送达ID）:
```json
{"subType":16,"code":0,"val":"171","note":"SMS has been sent.","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1775819726,"tid":"1647344840"}
```

**发送失败报告**:
```json
{"subType":16,"code":200,"val":"timeout","note":"SMS has been sent failed!","devId":"c3dd382801","type":402,"netCh":0,"msgTs":1775819795,"tid":"1647344840"}
```

| 字段 | 说明 |
|------|------|
| type | 402=命令执行结果报告 |
| subType | 固定值16 |
| code | 0=发送成功，200=发送失败 |
| val | **成功时为短信外发送达ID**（与502中smsSendMr一致；长短信为逗号分隔多ID如`"171,172"`，可与503配对）；失败时为失败原因：`timeout`(超时)、`cancel`(取消)、`unknow`(未知) |
| note | 成功时为`"SMS has been sent."`；失败时为`"SMS has been sent failed!"` |
| devId | 设备唯一ID |
| netCh | 0:WiFi, 1:SIM1, 2:SIM2 |
| msgTs | 消息时间戳 |
| tid | 与命令中的tid一致（省略tid时不包含此字段） |

## 503消息（短信外发送达报告）

502只代表短信已提交运营商，**不代表对方已收到**。确认对方是否真正收到需启用503消息（**默认不启用**）：

- 启用：设备管理后台→接口信息配置→接口消息设置→勾选"(503) 短信外发送达报告"；或`setallmsgcode`命令p1含503
- 启用后运营商确认投递结果时推送503，携带与502一致的送达ID(smsSendMr)与送达状态码(smsSt，0=已送达，其余为未送达/投递中，分区表见503消息文档)
- **长短信**在502中有多个送达ID（每条子短信一个），之后每条子短信各对应一条503，逐条配对核销后确认整条送达结果
- 详见《推送消息→短信消息→503 - 短信外发送达报告》

## 处理流程

1. 参数缺失检查：p1/p2/p3任一未提供→code=101, note仅列出实际缺失的参数如"Missing required parameter(s): p2 (phone number)"(type=401)
2. 参数值验证：p1非1或2→code=101, note="p1 (slotId) must be 1 or 2"；p2为空→code=101, note="p2 (phone number) must not be empty"；p3为空（含纯空白字符）→code=101, note="p3 (SMS body) must not be empty"(type=401)
3. 卡槽状态检查：无服务→code=200, note="slot no service!"(type=401)
4. 加入发送队列失败→code=200, note="Failed to send SMS."(type=401)
5. 加入发送队列成功→code=0, note="sending..."(type=401)
6. 短信发送成功→推送402(type=402, code=0)中间消息 + 502成功报告
7. 短信发送失败→推送402(type=402, code=200)失败报告

## 前置条件

- SIM卡已插入卡槽（`stat`命令查看）
- 卡槽已开机（未被`slotpwr`关闭）
- 4G模块已初始化完成（卡槽状态显示"正常"或"已联网"）

## 长短信

| 内容类型 | 单条限制 |
|----------|----------|
| 纯汉字 | 70个汉字 |
| 纯英文/数字 | 160字符(GSM 7-bit) |
| 中英文混合 | 按实际编码计算，可能少于70汉字 |

超出自动拆分，按多条计费，建议≤70汉字避免额外费用。接收方自动合并。无需额外配置。长短信的502中smsSendMr为数组（每条子短信一个送达ID），启用503后可逐条确认各子短信是否送达（详见503消息说明）。

## 注意事项

- 设备支持2个卡槽
- 始终携带tid参数以追踪发送结果
- 发送前用`stat`命令确认卡槽状态
- 批量发送间隔≥10秒，避免运营商限流
- 收到code=200时延迟3-5秒后重试
- HTTP中文参数必须UTF-8 URL编码
- 建议记录每次发送的tid和结果，便于问题排查
- 故障排除：code=100→检查token；code=101→检查具体note提示(参数缺失仅列实际缺失项/p1非1或2/p2为空/p3为空或纯空白字符)；code=200"slot no service!"→检查SIM/卡槽状态/开机；code=200"Failed to send SMS."→发送队列加入失败，检查AT模块状态；无502/402→检查上报接口配置；402 val="timeout"→检查信号并重试；发送成功对方未收到→检查SIM欠费/号码正确性；乱码→HTTP未UTF-8 URL编码
