# 203 - SIM卡IMSI上报

SIM卡初始化过程中IMSI读取成功时推送。**可能上报1次或2次**:扩展数据已就绪时仅1次(基础+扩展);未就绪时先报基础版,扩展数据就绪后再报扩展版。**203与204无必然顺序**。

## 参数

| 参数 | 类型 | 说明 |
|------|------|------|
| devId | string | 开发板唯一ID |
| type | number | 203 |
| slot | number | 卡槽号：1=卡槽1，2=卡槽2 |
| imsi | string | SIM卡IMSI(国际移动用户识别码)。全球唯一，补换卡后不变。格式：MCC(3位)+MNC(2-3位)+MSIN(9-10位)，共15位 |
| iccId | string | SIM卡ICCID(集成电路卡识别码)。全球唯一，补换卡后会变。19-20位 |
| msIsdn | string | 电话号码。需运营商发卡时预存否则可能为空(常见物联网卡)，解决：联系运营商写入/AT指令查询/用户手动配置。格式因卡而异，可能有/无国家码前缀(如+86) |
| scName | string | 运营商品牌名称，部分SIM卡可能无此信息 |
| dbm | number | 信号强度0~99，值越大越好。99=极好/满格；0=无信号/极弱。仅CSQ>0时存在，否则字段不存在。203中dbm可能不存在属正常 |
| plmn | string | 注册的运营商PLMN代码，如46000(移动)、46001(联通)、46003(电信)。203阶段可能未获取有效值，此时字段不存在 |
| netCh | number | 推送通道：0=WIFI，1=SIM1，2=SIM2 |
| msgTs | number | 推送时间戳(10位Unix秒级) |
| extended | object(JSON) / ext_前缀字段(KV/FORM) | **条件出现**。仅当SIM卡扩展数据加载完成时存在。JSON封装为`extended`嵌套对象;KV/FORM以`ext_`前缀平铺。详见下方"SIM卡扩展数据字段" |

## SIM卡扩展数据字段

**出现条件**:仅当SIM卡扩展数据加载完成时存在。基础版203不包含。

| 中文名 | JSON字段 | KV/FORM字段 | 类型/单位 | 说明 |
|-------|---------|-------------|----------|------|
| 联网开关 | simNet | ext_simNet | bool | 是否允许数据联网 |
| 套餐总流量 | trafficTotalMB | ext_trafficTotalMB | MB | 每月套餐总流量 |
| 已消耗流量 | trafficConsumedKB | ext_trafficConsumedKB | KB | 本月已消耗流量 |
| 流量比例下限 | ratioMin | ext_ratioMin | %(1~99) | 流量消耗策略比例下限 |
| 流量比例上限 | ratioMax | ext_ratioMax | %(1~99) | 流量消耗策略比例上限 |
| 目标流量比例 | ratioRndTarget | ext_ratioRndTarget | % | 当前目标比例(在ratioMin~ratioMax区间内随机生成) |
| 呼入接通次数 | callInCount | ext_callInCount | 次 | 累计接通呼入次数 |
| 呼入通话时长 | callInMinutes | ext_callInMinutes | 分钟 | 累计呼入通话分钟 |
| 呼出接通次数 | callOutCount | ext_callOutCount | 次 | 累计接通呼出次数 |
| 呼出通话时长 | callOutMinutes | ext_callOutMinutes | 分钟 | 累计呼出通话分钟 |
| 数据更新时间 | updateTs | ext_updateTs | Unix秒 | 最后更新时间(**0=设备出厂默认写入,非用户主动设置**) |

**封装规则**:JSON嵌套在`extended`对象内;KV/FORM以`ext_`前缀平铺。字段含义与readcard命令(subType=39)一致。

## JSON示例
```json
{"devId":"498060912345","type":203,"slot":1,"imsi":"46007337111234","iccId":"898607D3161990212345","msIsdn":"13206411822","scName":"中国移动","dbm":25,"plmn":"46000","netCh":0,"msgTs":1750044391}
```

**含SIM卡扩展数据示例(JSON)**:
```json
{"devId":"498060912345","type":203,"slot":1,"imsi":"46007337111234","iccId":"898607D3161990212345","msIsdn":"13206411822","scName":"中国移动","dbm":25,"plmn":"46000","netCh":0,"msgTs":1750044391,"extended":{"simNet":true,"trafficTotalMB":1024,"trafficConsumedKB":512000,"ratioMin":70,"ratioMax":85,"ratioRndTarget":78,"callInCount":10,"callInMinutes":30,"callOutCount":5,"callOutMinutes":15,"updateTs":1748265600}}
```

FORM格式：模拟HTML表单提交，字段同JSON(扩展字段以`ext_`前缀平铺,如`ext_simNet=1`)。

**HTTP GET 请求字符串示例(含SIM卡扩展数据)**:
```
GET /recv?devId=498060912345&type=203&slot=1&imsi=46007337111234&iccId=898607D3161990212345&msIsdn=13206411822&scName=%E4%B8%AD%E5%9B%BD%E7%A7%BB%E5%8A%A8&dbm=25&plmn=46000&netCh=0&msgTs=1750044391&ext_simNet=1&ext_trafficTotalMB=1024&ext_trafficConsumedKB=512000&ext_ratioMin=70&ext_ratioMax=85&ext_ratioRndTarget=78&ext_callInCount=10&ext_callInMinutes=30&ext_callOutCount=5&ext_callOutMinutes=15&ext_updateTs=1748265600
```

## 接口应答

- **HTTP**: 必须返回200，无数据要求。非200自动重试。
- **TCP**: 5秒内必须返回时间同步应答：
  - 方式1: `{"cmd":"now","p1":"20220330184700","tid":"1234"}\x11\x12`
  - 方式2(允许自主校准，需可访问Internet): `{"cmd":"now","p2":15,"p3":8}`

## IMSI与ICCID对比

| | IMSI | ICCID |
|---|------|-------|
| 全称 | 国际移动用户识别码 | 集成电路卡识别码 |
| 唯一性 | 全球唯一 | 全球唯一 |
| 补换卡后 | 不变 | 会变 |
| 用途 | 标识SIM卡身份 | 标识物理卡 |
| 长度 | 15位 | 19-20位 |

## IMSI号段(中国大陆MCC=460)

IMSI格式：MCC(3位)+MNC(2-3位)+MSIN(9-10位)
- 46000/46002/46007/46008: 中国移动
- 46001/46006/46009: 中国联通
- 46003/46005/46011: 中国电信
- 46015: 中国广电

## 与204消息关系

- 203=IMSI读取成功,SIM卡身份已确认;204=SIM卡完全就绪,可进行短信/电话操作
- **203可能上报1次或2次**(基础版+扩展版),扩展版含SIM卡扩展数据(联网/流量/通话统计)
- **203与204无必然先后顺序**,常见顺序:
  - `203(基础+扩展) → 204`(单次203场景)
  - `203(基础) → 204 → 203(扩展)`(双次203场景)
- 204消息**不包含**SIM卡扩展数据,如需扩展数据请监听203或用readcard命令查询
- 开发时**不应依赖**203/204的先后顺序,需用type字段独立处理每条消息

## 应用场景

- SIM卡身份识别：IMSI全球唯一且补换卡不变，适合长期追踪
- 运营商识别：IMSI前5-6位(MCC+MNC)判断运营商，用于智能路由/成本控制
- 用户绑定：IMSI与系统用户绑定，实现SIM卡级权限管理和计费
