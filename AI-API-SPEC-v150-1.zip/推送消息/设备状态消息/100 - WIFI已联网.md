# 消息100 - WIFI已联网

开发板启动后推送的第一个消息，标志WIFI连接建立成功。

## 参数

### 基本参数
- `devId` string - 设备唯一ID
- `type` number - 消息ID，固定100
- `hwVer` string - 硬件版本号（例：X31v107）
- `netCh` number - 推送通道：0=WIFI, 1=SIM1, 2=SIM2
- `msgTs` number - 推送时间戳（10位Unix秒级）

### WIFI连接参数
- `ssid` string - 连接的SSID
- `charset` string - SSID编码，固定`utf8`
- `ip` string - 本地IPv4地址
- `dbm` number - 信号质量百分比0~99，越大越好。=0表示无信号（原因：RSSI≤-100信号极弱 / RSSI≥0异常值 / 刚连接未获取）

### 设备信息（可选）
- `pingIntvl` number - 心跳间隔秒数，范围10~3600

### 卡槽状态快照（可选）
slot{N}_sta（N=1或2）供电状态：`POWOFF`(断电) / `NOSIM`(已供电无SIM) / `POWON`(已供电有SIM)

sim{N}_xxx（N=1或2）SIM详情，均为条件输出（100消息WiFi连接后立即发送，SIM可能未就绪故字段可能不存在）：
- `sim{N}_dbm` string - 信号强度（>0时输出）
- `sim{N}_plmn` string - PLMN代码（有效时输出）
- `sim{N}_iccId` / `sim{N}_imsi` / `sim{N}_msIsdn`(电话号码) / `sim{N}_scName`(短信卡名) string - 已从SIM读取时输出

sim{N}_sta（N=1或2）工作状态：`NS`(启动中) / `PIN`(需PIN/PUK) / `LT`(受限服务) / `OK`(正常)

### 断开原因（可选）
- `note` string - 上次WIFI断开原因，格式`错误码|错误描述;`（例：`3|AUTH_EXPIRE;`）。仅有过异常断开时输出。

## 消息格式
JSON：`{"devId":"498060912345","type":100,"hwVer":"X31v107","netCh":0,"msgTs":1750044391,"ssid":"mywifi","charset":"utf8","ip":"192.168.7.170","dbm":61,"pingIntvl":30,"slotInfo":{"slot1_sta":"POWON","sim1_dbm":"61","sim1_plmn":"46000","sim1_iccId":"898607D3161990212345","sim1_imsi":"46007337111234","sim1_sta":"OK"},"note":"3|AUTH_EXPIRE;"}`

FORM：HTML表单提交，参数名与JSON一致，无嵌套（slotInfo展开为slot1_sta/sim1_xxx等平级字段）。

## 接口应答

### HTTP
- 必须返回HTTP 200，非200则开发板尝试其他WIFI热点并重新推送100消息
- 响应体可选返回`now`命令同步时间（不返回则设备时间可能不准）：
  - `{"cmd":"now","p1":"yyyyMMddHHmmss","p2":校准规则,"p3":时区}`（HTTP无结束符\x11\x12）
  - p1: 14位时间字符串，可选
  - p2: 0~15（15=允许所有途径校准），可选
  - p3: -12~14（8=北京时间），可选
  - 省略p1仅设p2=15+p3时区（如`{"cmd":"now","p2":15,"p3":8}`），设备通过NTP自主校准（需可访问Internet）

### TCP
- **必须**返回时间同步或自主校准应答，5秒超时视为连接失败后重连WIFI重推；建议延迟≥100ms再发送（立即回应设备可能收不到）
- 方式1（推荐）：`{"cmd":"now","p1":"yyyyMMddHHmmss","tid":"xxx"}\x11\x12` → 设备回复：`{"code":0,"type":999,"netCh":0,"tid":"xxx"}\x11\x12`（tid可选）
- 方式2：`{"cmd":"now","p2":15,"p3":8}\x11\x12`（p2=15允许自主校准，p3=8时区+8，需可访问Internet）

## 故障排查
- 收不到100消息：检查WIFI配置（SSID/密码）、信号覆盖（dbm建议≥50）、设备日志
- 连接后断开：检查路由器设备数限制、IP冲突、note字段断开原因
- TCP应答超时：确保5秒内响应，否则用HTTP替代
